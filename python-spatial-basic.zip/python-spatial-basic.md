# Создание геометрических объектов

Для создания и работы с пространственными данными в Python существует библиотека `shapely` (https://shapely.readthedocs.io/en/stable/index.html).

> **NB** эта библиотека умеет работать только на плоскости

Каждый объект состоит из *внутреннего, внешнего и граничного* множеств (interior, boundary, and exterior sets of a feature), которые являются взаимоисключающими.

Основные типы объектов, реализованные в библиотеке:

1. **Point** (точка) - объект с нулевой размерностью, для которого внутреннее множество будет состоять из одной точки, граница - из нулевого количества точек, а внешнее множество представляет собой набор всех остальных возможных точек. Такие объекты относятся к классу `Point`.

2. **Curve** (кривая) - объект с размерностью 1, для которого внутреннее множество будет состоять из бесконечного количества точек вдоль линии, граница - из двух точек (начальной и конечной), а внешнее множество представляет собой набор всех остальных возможных точек. Такие объекты относятся к классам `Linestring` (разомкнутая кривая) и `LinearRing` (замкнутая кривая).

3. **Surface** (поверхность) - объект с размерностью 2, для которого внутреннее множество будет состоять из бесконечного множества точек, расположенных внутри, граница - из одной или нескольких кривых, а внешнее множество представляет собой набор всех остальных возможных точек, включая те, которые могут находиться в отверстиях поверхности. Такие объекты относятся к классу `Polygon`.


В библиотеке `shapely` наиболее применяемыми способами создания объектов являются:
- создание объектов из списка координат;
- создание объектов из словаря (dictionary `dict` [немного о словарях](https://pythonworld.ru/tipy-dannyx-v-python/slovari-dict-funkcii-i-metody-slovarej.html)), в данном случае фактически словари создаются на основе формата описания географических данных `geojson`;
- создание объектов из строки, то есть на основе описания в формате `wkt`

Установка библиотеки


```python
# pip install shapely
```

## Создание объектов из списка координат

### Точки


```python
from shapely.geometry import Point
```

Создадим точку из списка координат. Для этого нам достаточно всего одной пары координат.


```python
pin_itmo = Point ([59.944295,30.265266])
```

Проверим тип полученного объекта.


```python
print(f"Тип объекта: {type(pin_itmo)}")
```

    Тип объекта: <class 'shapely.geometry.point.Point'>


Кроме того, с помощью одного из [методов, реализованных в пакете для классов](https://shapely.readthedocs.io/en/stable/manual.html#general-attributes-and-methods), можно проверить тип геометрии объекта.



```python
print(f"Тип геометрии объекта: {pin_itmo.geom_type}")
```

    Тип геометрии объекта: Point



```python
pin_itmo
```




    
![svg](output_12_0.svg)
    



### Линии


```python
from shapely.geometry import LineString
```

Так как линия состоит из множества точек, а границей являются начальная и конечная точки линии, то для ее создания нужно как минимум две пары координат, заданных в виде [кортежа](https://younglinux.info/python/tuple) (`tuple`).

> Линия создается в том порядке, в котором координаты точек перечисляются в кортеже


```python
pointsList = [[59.929624, 30.268675], [59.936355, 30.257589]]
line = LineString (pointsList)
```


```python
print(f"Тип объекта: {type(line)}")
```

    Тип объекта: <class 'shapely.geometry.linestring.LineString'>



```python
print(f"Тип геометрии объекта: {line.geom_type}")
```

    Тип геометрии объекта: LineString



```python
line
```




    
![svg](output_19_0.svg)
    



Если нужно создать ломаную линию, то просто в список нужно внести не только координаты начальной и конечной точки, но и всех промежуточных поворотных точек.

> Линия может пересекать сама себя. 
Линия без самопересечений является простой (*simple*), а с самопересечениями - комплексной (*complex*).

![linestring.png](linestring.png)


```python
pointsList1 = [[59.929624, 30.268675], [59.936355, 30.257589], 
               [59.944295,30.265266], [59.943311, 30.268789]]
line1 = LineString (pointsList1)
```


```python
line1
```




    
![svg](output_22_0.svg)
    



Кроме того, линия может быть создана из нескольких точек или кортежа с парами координат.


```python
LineString([Point(59.929624, 30.268675), pin_itmo, (59.936355, 30.257589)])
```




    
![svg](output_24_0.svg)
    



Линии также могут быть замкнутыми. Для их создания используется класс `LinearRing`.

Главное отличие в создании между `LineString` и `LinearRing` в том, что для второго класса обязательно нужно в конце повторить координаты первой точки.

> Замкнутые линии не могут пересекать сами себя и касаться самих себя

![linearring.png](linearring.png)

> Важно помнить, что это все еще линия, то есть у нее нулевая площадь и ненулевая длина.


```python
from shapely.geometry import LinearRing
```


```python
pointsList2 = [[59.929624, 30.268675], [59.936355, 30.257589], 
               [59.944295,30.265266], [59.943311, 30.268789],
               [59.929624, 30.268675]]
line2 = LinearRing(pointsList2)
```


```python
line2
```




    
![svg](output_30_0.svg)
    



Однако для проверки валидности геометрии объекта, можно модифицировать его таким образом, чтобы при появлении самопересечений выдавалось предупреждение об этом.


```python
class LinearRing_2(LinearRing):
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if not self.is_valid:
            raise ValueError("Самопересечение")
```


```python
pointsList2 = [[59.929624, 30.268675], [59.943311, 30.268789], [59.936355, 30.257589], 
               [59.944295,30.265266],
               [59.929624, 30.268675]]
line2 = LinearRing_2(pointsList2)
```


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    Cell In [28], line 4
          1 pointsList2 = [[59.929624, 30.268675], [59.943311, 30.268789], [59.936355, 30.257589], 
          2                [59.944295,30.265266],
          3                [59.929624, 30.268675]]
    ----> 4 line2 = LinearRing_2(pointsList2)


    Cell In [23], line 6, in LinearRing_2.__init__(self, *args, **kwargs)
          4 super().__init__(*args, **kwargs)
          5 if not self.is_valid:
    ----> 6     raise ValueError("Самопересечение")


    ValueError: Самопересечение



```python
line2
```




    
![svg](output_34_0.svg)
    



### Полигоны


```python
from shapely.geometry import Polygon
```

При создании полигонов в качестве параметров сначала подается список или кортеж с координатами, а потом неупорядоченная последовательность кольцевых последовательностей, определяющих внутренние границы или "отверстия" объекта.

> Отверстия внутри полигона могут касаться его внешних границ только в одной точке, не могут иметь между собой общие границы и не могут пересекаться.
> Такие случаи приводят к созданию некорректных полигонов.

> **!** `shapely` не предотвращает создание некорректных объектов, но дальнейшие операции с ними могут быть невозможны.

![polygon.png](polygon.png)

![polygon2.png](polygon2.png)


```python
pointList = [[59.928813,30.268443], [59.931574,30.268144], [59.929816,30.270000]]

poly_mining = Polygon(pointList)
```


```python
poly_mining
```




    
![svg](output_41_0.svg)
    




```python
print(f"Тип объекта: {type(poly_mining)}")
```

    Тип объекта: <class 'shapely.geometry.polygon.Polygon'>



```python
print(f"Тип геометрии объекта: {poly_mining.geom_type}")
```

    Тип геометрии объекта: Polygon


Получим список координат границы полигона.

Координаты внешнего контура можно получить через `exterior` свойства, а координаты внутренних контуров через `interior`.


```python
list(poly_mining.exterior.coords)
```




    [(59.928813, 30.268443),
     (59.931574, 30.268144),
     (59.929816, 30.27),
     (59.928813, 30.268443)]



Обратите внимание, что в полученном полигоне координаты первой точки повторяются еще и в конце. Таким образом достигается замкнутость полигона.


```python
print(f'Длина исходного списка координат: {len(list(pointList))},'\
      f' длина списка координат объекта shapely: {len(list(poly_mining.exterior.coords))}'
      )
```

    Длина исходного списка координат: 3, длина списка координат объекта shapely: 4


## Создание объектов из словаря

При создании словаря, который будет конвертироваться в пространственный объект, фактически используется `geojson`, который является универсальным форматом данных, не привязанным к конкретному языку программирования. 

Этот формат основан на JavaScript object notation (JSON).

В GeoJSON объект состоит из набора пар ключ/значение, также называемых свойствами. Имя каждого свойства – строка. Значение свойства может представлять собой строку, число, объект, массив или один из литералов: «true», «false» и «null». 
Подробнее о формате можно почитать [здесь](https://geojson.org/)

### Точки

При создании точки из словаря, в нем обязательно должны быть два основных свойства:
- "type" - тип геометрии объекта;
- "coordinates" - перечень координат в виде списков или кортежей.


```python
from shapely.geometry import shape
```


```python
pin_itmo_geojson = {"type":"Point",
                   "coordinates":[59.944295,30.265266]
                   }
```


```python
print(f"Текущий тип объекта: {type(pin_itmo_geojson)}")
```

    Текущий тип объекта: <class 'dict'>



```python
pin_itmo1 = shape(pin_itmo_geojson)
```


```python
pin_itmo1
```




    
![svg](output_55_0.svg)
    




```python
print(f"Текущий тип объекта: {type(pin_itmo1)}")
```

    Текущий тип объекта: <class 'shapely.geometry.point.Point'>


### Линии


```python
line_geojson = {"type":"Linestring",
                "coordinates": [[59.929624, 30.268675],
                                [59.936355, 30.257589]],
                }

line3 = shape(line_geojson)
```


```python
print(f"Текущий тип объекта: {type(line3)}")
```

    Текущий тип объекта: <class 'shapely.geometry.linestring.LineString'>



```python
line3
```




    
![svg](output_60_0.svg)
    



### Полигоны


```python
poly_mining_geojson ={"type":"Polygon",
                      "coordinates": [[[59.928795, 30.268423],
                                       [59.930972, 30.265923],
                                       [59.931569, 30.268101],
                                       [59.929806, 30.269936],
                                       [59.928795, 30.268423]]],
                       }

poly_mining2 = shape(poly_mining_geojson)
```


```python
print(f"Текущий тип объекта: {type(poly_mining2)}")
```

    Текущий тип объекта: <class 'shapely.geometry.polygon.Polygon'>



```python
poly_mining2
```




    
![svg](output_64_0.svg)
    



## Создание объектов из текстовой строки

В этом случае описание объектов должно строиться на основе формата [WKT](https://ru.wikipedia.org/wiki/WKT) 

![WKT.png](WKT.png)


```python
from shapely import wkt
```

Для того, чтобы строка в формате WKT была преобразована в геометрический пространственный объект нужно воспользоваться функцией `wkt.loads` (load string). 

### Точки


```python
pin_itmo2 = wkt.loads('POINT (59.944295 30.265266)')

print(f"Тип объекта: {type(pin_itmo2)}")
```

    Тип объекта: <class 'shapely.geometry.point.Point'>



```python
pin_itmo2
```




    
![svg](output_71_0.svg)
    



### Линии


```python
line_wkt = 'LINESTRING (59.929624 30.268675, 59.936355 30.257589)'

line4 = wkt.loads(line_wkt)
```


```python
print(f"Тип объекта: {type(line4)}")
```

    Тип объекта: <class 'shapely.geometry.linestring.LineString'>



```python
line4
```




    
![svg](output_75_0.svg)
    



### Полигоны


```python
poly_mining_str = """POLYGON ((59.928795 30.268423, 59.930972 30.265923, 59.931569 30.268101, 
                     59.929806 30.269936, 59.928795 30.268423))"""

poly_mining4 = wkt.loads(poly_mining_str)
```


```python
poly_mining4
```




    
![svg](output_78_0.svg)
    




```python
print(f"Тип объекта: {type(poly_mining4)}")
```

    Тип объекта: <class 'shapely.geometry.polygon.Polygon'>


Обратите внимание, что при создании полигонов таким способом в строке с перечнем координат координаты первой точки должны обязательно также повторяться в конце.

## Основные свойства объектов

- `object.area` - возвращает площадь объектов в виде числа `float` (у точечных и линейных объектов будет нулевой)


```python
pin_itmo.area
```




    0.0




```python
line.area
```




    0.0




```python
poly_mining.area
```




    2.299386999998814e-06



- `object.length` - возвращает длину объектов в виде числа `float` (у точечных объектов будет нулевой, для линейных объектов будет равна длине линии, а для площадных объектов - периметру)


```python
pin_itmo.length
```




    0.0




```python
line.length
```




    0.012969416216625946




```python
poly_mining.length
```




    0.007185661628829153



- `object.bounds` - возвращает кортеж координат (minx, miny, maxx, maxy) из числовых значений; полученные границы полностью охватывают объект


```python
pin_itmo.bounds
```




    (59.944295, 30.265266, 59.944295, 30.265266)




```python
line.bounds
```




    (59.929624, 30.257589, 59.936355, 30.268675)




```python
poly_mining.bounds
```




    (59.928813, 30.268144, 59.931574, 30.27)



## Геометрические предикаты

Все геометрические предикаты возвращают только **True** или **False**.

### Унарные предикаты

Это атрибуты объектов.
При их использовании задействуется только один объект.

- `object.is_empty` - возвращает **True**, если объект является пустым набором


```python
pin_itmo.is_empty
```




    False




```python
Point().is_empty
```




    True



- `object.is_ring` - проверяет является ли объект замкнутой ломаной линией; имеет значение только для `LineString` и `LinearRing` объектов


```python
line1.is_ring
```




    False




```python
line2.is_ring
```




    True




```python
line1
```




    
![svg](output_100_0.svg)
    




```python
line2
```




    
![svg](output_101_0.svg)
    



- `object.is_simple` - возвращает **True**, если объект не пересекает сам себя; имеет значение только для `LineString` и `LinearRing` объектов


```python
line1.is_simple
```




    True




```python
line2.is_simple
```




    True



- `object.is_valid` - возвращает **True**, если объект не имеет топологических ошибок; имеет значение только для `Polygon` и `MultiPolygon` объектов, для всех остальных объектов всегда возвращает **True**


```python
poly_mining.is_valid
```




    True



### Бинарные предикаты

Эти предикаты реализованы как методы классов.
Они исследуют наличие топологических, теоретико-множественных отношений.

- `object.equals(other)` - возвращает **True**, если граничное, внешнее и внутренее множества двух объектов совпадают.


```python
poly_mining.equals(poly_mining2)
```




    False




```python
poly_mining2.equals(poly_mining4)
```




    True



- `object.contains(other)` - возвращает **True**, если ни одна из точек второго объекта (other) не находится в наружном множества объекта и как минимум одна точка внутреннего множества второго объекта попадает во внутренее множество объекта

![overlay_contains.jpg](overlay_contains.jpg)


```python
poly_mining.contains(pin_itmo)
```




    False




```python
line1.contains(pin_itmo)
```




    True



- `object.covers(other)` - возвращает **True**, если каждая точка второго объекта находится во внутреннем или граничном множестве объекта; отличается от предыдущего метода тем, что не требует нахождения точек из внутренного множества второго объекта во внутреннем множестве первого

- `object.covered_by(other)` - возвращает **True**, если каждая точка объекта является точкой внутреннего или граничного множества второго объекта; фактически противоположна предыдущему методу

- `object.crosses(other)` - возвращает **True**, если внутреннее множество объекта пересекает внутреннее множество второго объекта, но не содержит его; размерность пересечения меньше размерности любого из объектов (например, пересечение полигонов, размерность которых 2, - это линия с размерностью 1); линия не может пересекать точку, которую содержит

- `object.intersects(other)` - возвращает **True**, если граничное или внутреннее множество пересекает аналогичные множества второго объекта, то есть объекты пересекаются, если у них есть общая точка на границе или во внутреннем множестве

- `object.overlaps(other)` - возвращает **True**, если у объектов более одной общей точки, но не все, они имеют одинаковую размерность и размерность пересечения такая же, как размерность исходных объектов

- `object.touches(other)` - возвращает **True**, если у объектов есть хотя бы одна общая точка, но их внутренние множества не пересекаются

- `object.within(other)` - возвращает **True**, если граничное или внутреннее множество объекта пересекается с внутренним множеством второго объекта, но не граничным или внешним множеством

![overlay_intersects.jpg](overlay_intersects.jpg)

![overlay_touches.jpg](overlay_touches.jpg)

![overlay_within.jpg](overlay_within.jpg)

# GeoPandas и геодатафреймы

`GeoPandas` расширяет  библиотеку данных `pandas`, добавляя поддержку геопространственных данных (https://geopandas.org/en/stable/index.html).

![image.png](bac9f36b-db95-457c-a926-97c155885182.png)

![image.png](35d7f8ac-c861-4659-8d0f-ddb277719503.png)

Основной структурой данных в GeoPandas является `geopandas.GeoDataFrame`, подкласс `pandas.DataFrame`, который может хранить геометрические столбцы и выполнять пространственные операции. 

`Geopandas.GeoSeries`, подкласс `pandas.Series`, обрабатывает геометрические данные. Таким образом, ваш `GeoDataFrame` - это комбинация `pandas.Series` с традиционными данными (числовыми, булевыми, текстовыми и т.д.) и `geopandas.GeoSeries` с геометрией (точками, полигонами и т.д.). Вы можете иметь столько столбцов с геометриями, сколько пожелаете; нет ограничений, характерных для настольных ГИС-программ.

![image.png](cd2a3e82-3261-44d6-b4fe-750af80f12ee.png)

То есть фактически `Geoseries` - это геометрии объектов, а `GeoDataFrame` - аналог векторного слоя в ГИС.

Каждая `Geoseries` может содержать любой тип геометрии (вы можете даже смешивать их в одном массиве) и имеет атрибут `GeoSeries.crs`, который хранит информацию о системе координат (CRS означает Coordinate Reference System). Таким образом, каждая `GeoSeries` в `GeoDataFrame` может быть в разной проекции, что позволяет иметь, например, несколько версий (разных проекций) одной и той же геометрии.

Только одна GeoSeries в `GeoDataFrame` считается активной геометрией, что означает, что все геометрические операции, применяемые к GeoDataFrame, работают с этим активным столбцом.


```python
 pip install geopandas
```

    Requirement already satisfied: geopandas in /Users/tatianabaltyzhakova/.pyenv/versions/3.13.7/lib/python3.13/site-packages (1.1.1)
    Requirement already satisfied: numpy>=1.24 in /Users/tatianabaltyzhakova/.pyenv/versions/3.13.7/lib/python3.13/site-packages (from geopandas) (2.3.4)
    Requirement already satisfied: pyogrio>=0.7.2 in /Users/tatianabaltyzhakova/.pyenv/versions/3.13.7/lib/python3.13/site-packages (from geopandas) (0.11.1)
    Requirement already satisfied: packaging in /Users/tatianabaltyzhakova/.pyenv/versions/3.13.7/lib/python3.13/site-packages (from geopandas) (25.0)
    Requirement already satisfied: pandas>=2.0.0 in /Users/tatianabaltyzhakova/.pyenv/versions/3.13.7/lib/python3.13/site-packages (from geopandas) (2.3.3)
    Requirement already satisfied: pyproj>=3.5.0 in /Users/tatianabaltyzhakova/.pyenv/versions/3.13.7/lib/python3.13/site-packages (from geopandas) (3.7.2)
    Requirement already satisfied: shapely>=2.0.0 in /Users/tatianabaltyzhakova/.pyenv/versions/3.13.7/lib/python3.13/site-packages (from geopandas) (2.1.2)
    Requirement already satisfied: python-dateutil>=2.8.2 in /Users/tatianabaltyzhakova/.pyenv/versions/3.13.7/lib/python3.13/site-packages (from pandas>=2.0.0->geopandas) (2.9.0.post0)
    Requirement already satisfied: pytz>=2020.1 in /Users/tatianabaltyzhakova/.pyenv/versions/3.13.7/lib/python3.13/site-packages (from pandas>=2.0.0->geopandas) (2025.2)
    Requirement already satisfied: tzdata>=2022.7 in /Users/tatianabaltyzhakova/.pyenv/versions/3.13.7/lib/python3.13/site-packages (from pandas>=2.0.0->geopandas) (2025.2)
    Requirement already satisfied: certifi in /Users/tatianabaltyzhakova/.pyenv/versions/3.13.7/lib/python3.13/site-packages (from pyogrio>=0.7.2->geopandas) (2025.10.5)
    Requirement already satisfied: six>=1.5 in /Users/tatianabaltyzhakova/.pyenv/versions/3.13.7/lib/python3.13/site-packages (from python-dateutil>=2.8.2->pandas>=2.0.0->geopandas) (1.17.0)
    
    [1m[[0m[34;49mnotice[0m[1;39;49m][0m[39;49m A new release of pip is available: [0m[31;49m25.2[0m[39;49m -> [0m[32;49m26.1.2[0m
    [1m[[0m[34;49mnotice[0m[1;39;49m][0m[39;49m To update, run: [0m[32;49mpip install --upgrade pip[0m
    Note: you may need to restart the kernel to use updated packages.



```python
 pip install geodatasets
```

    Collecting geodatasets
      Downloading geodatasets-2026.5.1-py3-none-any.whl.metadata (5.5 kB)
    Collecting pooch (from geodatasets)
      Downloading pooch-1.9.0-py3-none-any.whl.metadata (10 kB)
    Requirement already satisfied: platformdirs>=2.5.0 in /Users/tatianabaltyzhakova/.pyenv/versions/3.13.7/lib/python3.13/site-packages (from pooch->geodatasets) (4.9.6)
    Requirement already satisfied: packaging>=20.0 in /Users/tatianabaltyzhakova/.pyenv/versions/3.13.7/lib/python3.13/site-packages (from pooch->geodatasets) (25.0)
    Requirement already satisfied: requests>=2.19.0 in /Users/tatianabaltyzhakova/.pyenv/versions/3.13.7/lib/python3.13/site-packages (from pooch->geodatasets) (2.32.5)
    Requirement already satisfied: charset_normalizer<4,>=2 in /Users/tatianabaltyzhakova/.pyenv/versions/3.13.7/lib/python3.13/site-packages (from requests>=2.19.0->pooch->geodatasets) (3.4.4)
    Requirement already satisfied: idna<4,>=2.5 in /Users/tatianabaltyzhakova/.pyenv/versions/3.13.7/lib/python3.13/site-packages (from requests>=2.19.0->pooch->geodatasets) (3.11)
    Requirement already satisfied: urllib3<3,>=1.21.1 in /Users/tatianabaltyzhakova/.pyenv/versions/3.13.7/lib/python3.13/site-packages (from requests>=2.19.0->pooch->geodatasets) (2.5.0)
    Requirement already satisfied: certifi>=2017.4.17 in /Users/tatianabaltyzhakova/.pyenv/versions/3.13.7/lib/python3.13/site-packages (from requests>=2.19.0->pooch->geodatasets) (2025.10.5)
    Downloading geodatasets-2026.5.1-py3-none-any.whl (21 kB)
    Downloading pooch-1.9.0-py3-none-any.whl (67 kB)
    Installing collected packages: pooch, geodatasets
    [2K   [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m2/2[0m [geodatasets]
    [1A[2KSuccessfully installed geodatasets-2026.5.1 pooch-1.9.0
    
    [1m[[0m[34;49mnotice[0m[1;39;49m][0m[39;49m A new release of pip is available: [0m[31;49m25.2[0m[39;49m -> [0m[32;49m26.1.2[0m
    [1m[[0m[34;49mnotice[0m[1;39;49m][0m[39;49m To update, run: [0m[32;49mpip install --upgrade pip[0m
    Note: you may need to restart the kernel to use updated packages.



```python
import geopandas as gpd
import geodatasets
```

Функция `gpd.read_file` позволяет читать основные типы векторных файлов, используемых в ГИС.
- Shapefile (.shp)

- GeoJSON (.geojson)

- GeoPackage (.gpkg)

- File Geodatabase (.gdb)


```python
guerry = gpd.read_file(geodatasets.get_path("geoda.guerry"))
```

    Downloading file 'guerry.zip' from 'https://geodacenter.github.io/data-and-lab//data/guerry.zip' to '/Users/tatianabaltyzhakova/Library/Caches/geodatasets'.
    Extracting 'guerry/guerry.shp' from '/Users/tatianabaltyzhakova/Library/Caches/geodatasets/guerry.zip' to '/Users/tatianabaltyzhakova/Library/Caches/geodatasets/guerry.zip.unzip'
    Extracting 'guerry/guerry.dbf' from '/Users/tatianabaltyzhakova/Library/Caches/geodatasets/guerry.zip' to '/Users/tatianabaltyzhakova/Library/Caches/geodatasets/guerry.zip.unzip'
    Extracting 'guerry/guerry.shx' from '/Users/tatianabaltyzhakova/Library/Caches/geodatasets/guerry.zip' to '/Users/tatianabaltyzhakova/Library/Caches/geodatasets/guerry.zip.unzip'
    Extracting 'guerry/guerry.prj' from '/Users/tatianabaltyzhakova/Library/Caches/geodatasets/guerry.zip' to '/Users/tatianabaltyzhakova/Library/Caches/geodatasets/guerry.zip.unzip'



```python
type(guerry)
```




    geopandas.geodataframe.GeoDataFrame




```python
guerry.plot()
```




    <Axes: >




    
![png](output_130_1.png)
    



```python
guerry.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>dept</th>
      <th>Region</th>
      <th>Dprtmnt</th>
      <th>Crm_prs</th>
      <th>Crm_prp</th>
      <th>Litercy</th>
      <th>Donatns</th>
      <th>Infants</th>
      <th>Suicids</th>
      <th>MainCty</th>
      <th>...</th>
      <th>Infntcd</th>
      <th>Dntn_cl</th>
      <th>Lottery</th>
      <th>Desertn</th>
      <th>Instrct</th>
      <th>Prsttts</th>
      <th>Distanc</th>
      <th>Area</th>
      <th>Pop1831</th>
      <th>geometry</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>E</td>
      <td>Ain</td>
      <td>28870.0</td>
      <td>15890.0</td>
      <td>37.0</td>
      <td>5098.0</td>
      <td>33120.0</td>
      <td>35039.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>60.0</td>
      <td>69.0</td>
      <td>41.0</td>
      <td>55.0</td>
      <td>46.0</td>
      <td>13.0</td>
      <td>218.372</td>
      <td>5762.0</td>
      <td>346.03</td>
      <td>POLYGON ((801150 2092615, 800669 2093190, 8006...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2.0</td>
      <td>N</td>
      <td>Aisne</td>
      <td>26226.0</td>
      <td>5521.0</td>
      <td>51.0</td>
      <td>8901.0</td>
      <td>14572.0</td>
      <td>12831.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>82.0</td>
      <td>36.0</td>
      <td>38.0</td>
      <td>82.0</td>
      <td>24.0</td>
      <td>327.0</td>
      <td>65.945</td>
      <td>7369.0</td>
      <td>513.00</td>
      <td>POLYGON ((729326 2521619, 729320 2521230, 7292...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3.0</td>
      <td>C</td>
      <td>Allier</td>
      <td>26747.0</td>
      <td>7925.0</td>
      <td>13.0</td>
      <td>10973.0</td>
      <td>17044.0</td>
      <td>114121.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>42.0</td>
      <td>76.0</td>
      <td>66.0</td>
      <td>16.0</td>
      <td>85.0</td>
      <td>34.0</td>
      <td>161.927</td>
      <td>7340.0</td>
      <td>298.26</td>
      <td>POLYGON ((710830 2137350, 711746 2136617, 7124...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.0</td>
      <td>E</td>
      <td>Basses-Alpes</td>
      <td>12935.0</td>
      <td>7289.0</td>
      <td>46.0</td>
      <td>2733.0</td>
      <td>23018.0</td>
      <td>14238.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>12.0</td>
      <td>37.0</td>
      <td>80.0</td>
      <td>32.0</td>
      <td>29.0</td>
      <td>2.0</td>
      <td>351.399</td>
      <td>6925.0</td>
      <td>155.90</td>
      <td>POLYGON ((882701 1920024, 882408 1920733, 8817...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>E</td>
      <td>Hautes-Alpes</td>
      <td>17488.0</td>
      <td>8174.0</td>
      <td>69.0</td>
      <td>6962.0</td>
      <td>23076.0</td>
      <td>16171.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>23.0</td>
      <td>64.0</td>
      <td>79.0</td>
      <td>35.0</td>
      <td>7.0</td>
      <td>1.0</td>
      <td>320.280</td>
      <td>5549.0</td>
      <td>129.10</td>
      <td>POLYGON ((886504 1922890, 885733 1922978, 8854...</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 24 columns</p>
</div>




```python
guerry
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>dept</th>
      <th>Region</th>
      <th>Dprtmnt</th>
      <th>Crm_prs</th>
      <th>Crm_prp</th>
      <th>Litercy</th>
      <th>Donatns</th>
      <th>Infants</th>
      <th>Suicids</th>
      <th>MainCty</th>
      <th>...</th>
      <th>Infntcd</th>
      <th>Dntn_cl</th>
      <th>Lottery</th>
      <th>Desertn</th>
      <th>Instrct</th>
      <th>Prsttts</th>
      <th>Distanc</th>
      <th>Area</th>
      <th>Pop1831</th>
      <th>geometry</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>E</td>
      <td>Ain</td>
      <td>28870.0</td>
      <td>15890.0</td>
      <td>37.0</td>
      <td>5098.0</td>
      <td>33120.0</td>
      <td>35039.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>60.0</td>
      <td>69.0</td>
      <td>41.0</td>
      <td>55.0</td>
      <td>46.0</td>
      <td>13.0</td>
      <td>218.372</td>
      <td>5762.0</td>
      <td>346.03</td>
      <td>POLYGON ((801150 2092615, 800669 2093190, 8006...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2.0</td>
      <td>N</td>
      <td>Aisne</td>
      <td>26226.0</td>
      <td>5521.0</td>
      <td>51.0</td>
      <td>8901.0</td>
      <td>14572.0</td>
      <td>12831.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>82.0</td>
      <td>36.0</td>
      <td>38.0</td>
      <td>82.0</td>
      <td>24.0</td>
      <td>327.0</td>
      <td>65.945</td>
      <td>7369.0</td>
      <td>513.00</td>
      <td>POLYGON ((729326 2521619, 729320 2521230, 7292...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3.0</td>
      <td>C</td>
      <td>Allier</td>
      <td>26747.0</td>
      <td>7925.0</td>
      <td>13.0</td>
      <td>10973.0</td>
      <td>17044.0</td>
      <td>114121.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>42.0</td>
      <td>76.0</td>
      <td>66.0</td>
      <td>16.0</td>
      <td>85.0</td>
      <td>34.0</td>
      <td>161.927</td>
      <td>7340.0</td>
      <td>298.26</td>
      <td>POLYGON ((710830 2137350, 711746 2136617, 7124...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.0</td>
      <td>E</td>
      <td>Basses-Alpes</td>
      <td>12935.0</td>
      <td>7289.0</td>
      <td>46.0</td>
      <td>2733.0</td>
      <td>23018.0</td>
      <td>14238.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>12.0</td>
      <td>37.0</td>
      <td>80.0</td>
      <td>32.0</td>
      <td>29.0</td>
      <td>2.0</td>
      <td>351.399</td>
      <td>6925.0</td>
      <td>155.90</td>
      <td>POLYGON ((882701 1920024, 882408 1920733, 8817...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>E</td>
      <td>Hautes-Alpes</td>
      <td>17488.0</td>
      <td>8174.0</td>
      <td>69.0</td>
      <td>6962.0</td>
      <td>23076.0</td>
      <td>16171.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>23.0</td>
      <td>64.0</td>
      <td>79.0</td>
      <td>35.0</td>
      <td>7.0</td>
      <td>1.0</td>
      <td>320.280</td>
      <td>5549.0</td>
      <td>129.10</td>
      <td>POLYGON ((886504 1922890, 885733 1922978, 8854...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>80</th>
      <td>85.0</td>
      <td>W</td>
      <td>Vendee</td>
      <td>20827.0</td>
      <td>7566.0</td>
      <td>28.0</td>
      <td>14035.0</td>
      <td>62486.0</td>
      <td>67963.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>44.0</td>
      <td>30.0</td>
      <td>68.0</td>
      <td>79.0</td>
      <td>59.0</td>
      <td>4.0</td>
      <td>212.459</td>
      <td>6720.0</td>
      <td>330.36</td>
      <td>MULTIPOLYGON (((243055 2197885, 243019 2198089...</td>
    </tr>
    <tr>
      <th>81</th>
      <td>86.0</td>
      <td>W</td>
      <td>Vienne</td>
      <td>15010.0</td>
      <td>4710.0</td>
      <td>25.0</td>
      <td>8922.0</td>
      <td>35224.0</td>
      <td>21851.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>1.0</td>
      <td>44.0</td>
      <td>40.0</td>
      <td>38.0</td>
      <td>65.0</td>
      <td>18.0</td>
      <td>170.523</td>
      <td>6990.0</td>
      <td>282.73</td>
      <td>POLYGON ((450395 2119945, 450065 2120124, 4494...</td>
    </tr>
    <tr>
      <th>82</th>
      <td>87.0</td>
      <td>C</td>
      <td>Haute-Vienne</td>
      <td>16256.0</td>
      <td>6402.0</td>
      <td>13.0</td>
      <td>13817.0</td>
      <td>19940.0</td>
      <td>33497.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>6.0</td>
      <td>78.0</td>
      <td>55.0</td>
      <td>11.0</td>
      <td>84.0</td>
      <td>7.0</td>
      <td>198.874</td>
      <td>5520.0</td>
      <td>285.13</td>
      <td>POLYGON ((515230 2049895, 514990 2049594, 5143...</td>
    </tr>
    <tr>
      <th>83</th>
      <td>88.0</td>
      <td>E</td>
      <td>Vosges</td>
      <td>18835.0</td>
      <td>9044.0</td>
      <td>62.0</td>
      <td>4040.0</td>
      <td>14978.0</td>
      <td>33029.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>34.0</td>
      <td>5.0</td>
      <td>14.0</td>
      <td>85.0</td>
      <td>11.0</td>
      <td>43.0</td>
      <td>174.477</td>
      <td>5874.0</td>
      <td>397.99</td>
      <td>POLYGON ((951144 2383215, 953082 2382491, 9534...</td>
    </tr>
    <tr>
      <th>84</th>
      <td>89.0</td>
      <td>C</td>
      <td>Yonne</td>
      <td>18006.0</td>
      <td>6516.0</td>
      <td>47.0</td>
      <td>4276.0</td>
      <td>16616.0</td>
      <td>12789.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>22.0</td>
      <td>35.0</td>
      <td>51.0</td>
      <td>66.0</td>
      <td>27.0</td>
      <td>272.0</td>
      <td>81.797</td>
      <td>7427.0</td>
      <td>352.49</td>
      <td>POLYGON ((650260 2358330, 651712 2361305, 6528...</td>
    </tr>
  </tbody>
</table>
<p>85 rows × 24 columns</p>
</div>



Для того, чтобы посмотреть `GeoDataFrame` целиком, нужно установить большее значение в максимальном количестве строк, которое отображается при вызове объекта.


```python
import pandas as pd
```


```python
pd.set_option("display.max_rows", 100)
```


```python
guerry
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>dept</th>
      <th>Region</th>
      <th>Dprtmnt</th>
      <th>Crm_prs</th>
      <th>Crm_prp</th>
      <th>Litercy</th>
      <th>Donatns</th>
      <th>Infants</th>
      <th>Suicids</th>
      <th>MainCty</th>
      <th>...</th>
      <th>Infntcd</th>
      <th>Dntn_cl</th>
      <th>Lottery</th>
      <th>Desertn</th>
      <th>Instrct</th>
      <th>Prsttts</th>
      <th>Distanc</th>
      <th>Area</th>
      <th>Pop1831</th>
      <th>geometry</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>E</td>
      <td>Ain</td>
      <td>28870.0</td>
      <td>15890.0</td>
      <td>37.0</td>
      <td>5098.0</td>
      <td>33120.0</td>
      <td>35039.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>60.0</td>
      <td>69.0</td>
      <td>41.0</td>
      <td>55.0</td>
      <td>46.0</td>
      <td>13.0</td>
      <td>218.372</td>
      <td>5762.0</td>
      <td>346.03</td>
      <td>POLYGON ((801150 2092615, 800669 2093190, 8006...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2.0</td>
      <td>N</td>
      <td>Aisne</td>
      <td>26226.0</td>
      <td>5521.0</td>
      <td>51.0</td>
      <td>8901.0</td>
      <td>14572.0</td>
      <td>12831.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>82.0</td>
      <td>36.0</td>
      <td>38.0</td>
      <td>82.0</td>
      <td>24.0</td>
      <td>327.0</td>
      <td>65.945</td>
      <td>7369.0</td>
      <td>513.00</td>
      <td>POLYGON ((729326 2521619, 729320 2521230, 7292...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3.0</td>
      <td>C</td>
      <td>Allier</td>
      <td>26747.0</td>
      <td>7925.0</td>
      <td>13.0</td>
      <td>10973.0</td>
      <td>17044.0</td>
      <td>114121.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>42.0</td>
      <td>76.0</td>
      <td>66.0</td>
      <td>16.0</td>
      <td>85.0</td>
      <td>34.0</td>
      <td>161.927</td>
      <td>7340.0</td>
      <td>298.26</td>
      <td>POLYGON ((710830 2137350, 711746 2136617, 7124...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.0</td>
      <td>E</td>
      <td>Basses-Alpes</td>
      <td>12935.0</td>
      <td>7289.0</td>
      <td>46.0</td>
      <td>2733.0</td>
      <td>23018.0</td>
      <td>14238.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>12.0</td>
      <td>37.0</td>
      <td>80.0</td>
      <td>32.0</td>
      <td>29.0</td>
      <td>2.0</td>
      <td>351.399</td>
      <td>6925.0</td>
      <td>155.90</td>
      <td>POLYGON ((882701 1920024, 882408 1920733, 8817...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>E</td>
      <td>Hautes-Alpes</td>
      <td>17488.0</td>
      <td>8174.0</td>
      <td>69.0</td>
      <td>6962.0</td>
      <td>23076.0</td>
      <td>16171.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>23.0</td>
      <td>64.0</td>
      <td>79.0</td>
      <td>35.0</td>
      <td>7.0</td>
      <td>1.0</td>
      <td>320.280</td>
      <td>5549.0</td>
      <td>129.10</td>
      <td>POLYGON ((886504 1922890, 885733 1922978, 8854...</td>
    </tr>
    <tr>
      <th>5</th>
      <td>7.0</td>
      <td>S</td>
      <td>Ardeche</td>
      <td>9474.0</td>
      <td>10263.0</td>
      <td>27.0</td>
      <td>3188.0</td>
      <td>42117.0</td>
      <td>52547.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>47.0</td>
      <td>67.0</td>
      <td>70.0</td>
      <td>19.0</td>
      <td>62.0</td>
      <td>1.0</td>
      <td>279.413</td>
      <td>5529.0</td>
      <td>340.73</td>
      <td>POLYGON ((747008 1925789, 746630 1925762, 7457...</td>
    </tr>
    <tr>
      <th>6</th>
      <td>8.0</td>
      <td>N</td>
      <td>Ardennes</td>
      <td>35203.0</td>
      <td>8847.0</td>
      <td>67.0</td>
      <td>6400.0</td>
      <td>16106.0</td>
      <td>26198.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>85.0</td>
      <td>49.0</td>
      <td>31.0</td>
      <td>62.0</td>
      <td>9.0</td>
      <td>83.0</td>
      <td>105.694</td>
      <td>5229.0</td>
      <td>289.62</td>
      <td>POLYGON ((818893 2514767, 818614 2514515, 8179...</td>
    </tr>
    <tr>
      <th>7</th>
      <td>9.0</td>
      <td>S</td>
      <td>Ariege</td>
      <td>6173.0</td>
      <td>9597.0</td>
      <td>18.0</td>
      <td>3542.0</td>
      <td>22916.0</td>
      <td>123625.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>28.0</td>
      <td>63.0</td>
      <td>75.0</td>
      <td>22.0</td>
      <td>77.0</td>
      <td>3.0</td>
      <td>385.313</td>
      <td>4890.0</td>
      <td>253.12</td>
      <td>POLYGON ((509103 1747787, 508820 1747513, 5081...</td>
    </tr>
    <tr>
      <th>8</th>
      <td>10.0</td>
      <td>E</td>
      <td>Aube</td>
      <td>19602.0</td>
      <td>4086.0</td>
      <td>59.0</td>
      <td>3608.0</td>
      <td>18642.0</td>
      <td>10989.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>54.0</td>
      <td>9.0</td>
      <td>28.0</td>
      <td>86.0</td>
      <td>15.0</td>
      <td>207.0</td>
      <td>83.244</td>
      <td>6004.0</td>
      <td>246.36</td>
      <td>POLYGON ((775400 2345600, 775068 2345397, 7735...</td>
    </tr>
    <tr>
      <th>9</th>
      <td>11.0</td>
      <td>S</td>
      <td>Aude</td>
      <td>15647.0</td>
      <td>10431.0</td>
      <td>34.0</td>
      <td>2582.0</td>
      <td>20225.0</td>
      <td>66498.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>35.0</td>
      <td>27.0</td>
      <td>50.0</td>
      <td>63.0</td>
      <td>48.0</td>
      <td>1.0</td>
      <td>370.949</td>
      <td>6139.0</td>
      <td>270.13</td>
      <td>POLYGON ((626230 1810121, 626269 1810496, 6274...</td>
    </tr>
    <tr>
      <th>10</th>
      <td>12.0</td>
      <td>S</td>
      <td>Aveyron</td>
      <td>8236.0</td>
      <td>6731.0</td>
      <td>31.0</td>
      <td>3211.0</td>
      <td>21981.0</td>
      <td>116671.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>5.0</td>
      <td>23.0</td>
      <td>81.0</td>
      <td>10.0</td>
      <td>44.0</td>
      <td>4.0</td>
      <td>296.089</td>
      <td>8735.0</td>
      <td>359.06</td>
      <td>POLYGON ((642972 1978185, 643791 1976549, 6444...</td>
    </tr>
    <tr>
      <th>11</th>
      <td>13.0</td>
      <td>S</td>
      <td>Bouches-du-Rhone</td>
      <td>13409.0</td>
      <td>5291.0</td>
      <td>38.0</td>
      <td>2314.0</td>
      <td>9325.0</td>
      <td>8107.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>74.0</td>
      <td>55.0</td>
      <td>3.0</td>
      <td>23.0</td>
      <td>43.0</td>
      <td>25.0</td>
      <td>362.568</td>
      <td>5087.0</td>
      <td>359.47</td>
      <td>POLYGON ((824692 1865875, 825615 1865409, 8259...</td>
    </tr>
    <tr>
      <th>12</th>
      <td>14.0</td>
      <td>N</td>
      <td>Calvados</td>
      <td>17577.0</td>
      <td>4500.0</td>
      <td>52.0</td>
      <td>27830.0</td>
      <td>8983.0</td>
      <td>31807.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>56.0</td>
      <td>11.0</td>
      <td>13.0</td>
      <td>12.0</td>
      <td>22.0</td>
      <td>194.0</td>
      <td>117.487</td>
      <td>5548.0</td>
      <td>494.70</td>
      <td>POLYGON ((345476 2429914, 345299 2430235, 3436...</td>
    </tr>
    <tr>
      <th>13</th>
      <td>15.0</td>
      <td>C</td>
      <td>Cantal</td>
      <td>18070.0</td>
      <td>11645.0</td>
      <td>31.0</td>
      <td>4093.0</td>
      <td>15335.0</td>
      <td>87338.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>83.0</td>
      <td>66.0</td>
      <td>82.0</td>
      <td>1.0</td>
      <td>51.0</td>
      <td>20.0</td>
      <td>245.849</td>
      <td>5726.0</td>
      <td>258.59</td>
      <td>POLYGON ((591653 2017934, 591727 2018244, 5918...</td>
    </tr>
    <tr>
      <th>14</th>
      <td>16.0</td>
      <td>W</td>
      <td>Charente</td>
      <td>24964.0</td>
      <td>13018.0</td>
      <td>36.0</td>
      <td>13602.0</td>
      <td>19454.0</td>
      <td>25720.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>7.0</td>
      <td>81.0</td>
      <td>60.0</td>
      <td>61.0</td>
      <td>47.0</td>
      <td>8.0</td>
      <td>224.339</td>
      <td>5956.0</td>
      <td>362.53</td>
      <td>POLYGON ((456425 2120055, 456229 2120382, 4559...</td>
    </tr>
    <tr>
      <th>15</th>
      <td>17.0</td>
      <td>W</td>
      <td>Charente-Inferieure</td>
      <td>18712.0</td>
      <td>5357.0</td>
      <td>39.0</td>
      <td>13254.0</td>
      <td>23999.0</td>
      <td>16798.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>38.0</td>
      <td>72.0</td>
      <td>35.0</td>
      <td>74.0</td>
      <td>42.0</td>
      <td>27.0</td>
      <td>238.538</td>
      <td>6864.0</td>
      <td>445.25</td>
      <td>MULTIPOLYGON (((328075 2118055, 327916 2118168...</td>
    </tr>
    <tr>
      <th>16</th>
      <td>18.0</td>
      <td>C</td>
      <td>Cher</td>
      <td>21934.0</td>
      <td>10503.0</td>
      <td>13.0</td>
      <td>9561.0</td>
      <td>23574.0</td>
      <td>19497.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>11.0</td>
      <td>86.0</td>
      <td>44.0</td>
      <td>51.0</td>
      <td>83.0</td>
      <td>26.0</td>
      <td>116.257</td>
      <td>7235.0</td>
      <td>256.06</td>
      <td>POLYGON ((572720 2252955, 574278 2251834, 5753...</td>
    </tr>
    <tr>
      <th>17</th>
      <td>19.0</td>
      <td>C</td>
      <td>Correze</td>
      <td>15262.0</td>
      <td>12949.0</td>
      <td>12.0</td>
      <td>14993.0</td>
      <td>19330.0</td>
      <td>47480.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>16.0</td>
      <td>82.0</td>
      <td>84.0</td>
      <td>2.0</td>
      <td>86.0</td>
      <td>3.0</td>
      <td>227.899</td>
      <td>5857.0</td>
      <td>294.83</td>
      <td>POLYGON ((608225 2042680, 608101 2042880, 6079...</td>
    </tr>
    <tr>
      <th>18</th>
      <td>21.0</td>
      <td>E</td>
      <td>Cote-d'Or</td>
      <td>32256.0</td>
      <td>9159.0</td>
      <td>60.0</td>
      <td>2540.0</td>
      <td>15599.0</td>
      <td>16128.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>27.0</td>
      <td>18.0</td>
      <td>33.0</td>
      <td>78.0</td>
      <td>13.0</td>
      <td>206.0</td>
      <td>136.109</td>
      <td>8763.0</td>
      <td>375.88</td>
      <td>MULTIPOLYGON (((738935 2236890, 738359 2237343...</td>
    </tr>
    <tr>
      <th>19</th>
      <td>22.0</td>
      <td>W</td>
      <td>Cotes-du-Nord</td>
      <td>28607.0</td>
      <td>7050.0</td>
      <td>16.0</td>
      <td>10387.0</td>
      <td>36098.0</td>
      <td>75056.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>69.0</td>
      <td>15.0</td>
      <td>72.0</td>
      <td>47.0</td>
      <td>80.0</td>
      <td>16.0</td>
      <td>225.161</td>
      <td>6878.0</td>
      <td>598.87</td>
      <td>MULTIPOLYGON (((208165 2439753, 208131 2439949...</td>
    </tr>
    <tr>
      <th>20</th>
      <td>23.0</td>
      <td>C</td>
      <td>Creuse</td>
      <td>37014.0</td>
      <td>20235.0</td>
      <td>23.0</td>
      <td>10997.0</td>
      <td>14363.0</td>
      <td>77823.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>24.0</td>
      <td>75.0</td>
      <td>85.0</td>
      <td>4.0</td>
      <td>71.0</td>
      <td>12.0</td>
      <td>180.846</td>
      <td>5565.0</td>
      <td>265.38</td>
      <td>POLYGON ((540175 2111095, 538135 2111105, 5380...</td>
    </tr>
    <tr>
      <th>21</th>
      <td>24.0</td>
      <td>W</td>
      <td>Dordogne</td>
      <td>21585.0</td>
      <td>10237.0</td>
      <td>18.0</td>
      <td>4687.0</td>
      <td>21375.0</td>
      <td>36024.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>18.0</td>
      <td>79.0</td>
      <td>77.0</td>
      <td>44.0</td>
      <td>78.0</td>
      <td>3.0</td>
      <td>253.776</td>
      <td>9060.0</td>
      <td>482.75</td>
      <td>POLYGON ((527718 1988833, 528808 1988071, 5291...</td>
    </tr>
    <tr>
      <th>22</th>
      <td>25.0</td>
      <td>E</td>
      <td>Doubs</td>
      <td>11560.0</td>
      <td>5914.0</td>
      <td>73.0</td>
      <td>3436.0</td>
      <td>12512.0</td>
      <td>40690.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>25.0</td>
      <td>6.0</td>
      <td>18.0</td>
      <td>73.0</td>
      <td>2.0</td>
      <td>65.0</td>
      <td>202.065</td>
      <td>5234.0</td>
      <td>265.54</td>
      <td>POLYGON ((886630 2188665, 886948 2188898, 8879...</td>
    </tr>
    <tr>
      <th>23</th>
      <td>26.0</td>
      <td>E</td>
      <td>Drome</td>
      <td>13396.0</td>
      <td>7759.0</td>
      <td>42.0</td>
      <td>2829.0</td>
      <td>16348.0</td>
      <td>23816.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>13.0</td>
      <td>62.0</td>
      <td>54.0</td>
      <td>46.0</td>
      <td>38.0</td>
      <td>8.0</td>
      <td>295.543</td>
      <td>6530.0</td>
      <td>299.56</td>
      <td>POLYGON ((830803 2010472, 831288 2010361, 8315...</td>
    </tr>
    <tr>
      <th>24</th>
      <td>27.0</td>
      <td>N</td>
      <td>Eure</td>
      <td>14795.0</td>
      <td>4774.0</td>
      <td>51.0</td>
      <td>11712.0</td>
      <td>16039.0</td>
      <td>13493.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>45.0</td>
      <td>45.0</td>
      <td>47.0</td>
      <td>27.0</td>
      <td>23.0</td>
      <td>179.0</td>
      <td>61.863</td>
      <td>6040.0</td>
      <td>424.25</td>
      <td>POLYGON ((515046 2482676, 515755 2483384, 5160...</td>
    </tr>
    <tr>
      <th>25</th>
      <td>28.0</td>
      <td>C</td>
      <td>Eure-et-Loir</td>
      <td>21368.0</td>
      <td>4016.0</td>
      <td>54.0</td>
      <td>4553.0</td>
      <td>14475.0</td>
      <td>15015.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>62.0</td>
      <td>14.0</td>
      <td>48.0</td>
      <td>72.0</td>
      <td>18.0</td>
      <td>180.0</td>
      <td>54.558</td>
      <td>5880.0</td>
      <td>278.82</td>
      <td>POLYGON ((562860 2342515, 562499 2342577, 5602...</td>
    </tr>
    <tr>
      <th>26</th>
      <td>29.0</td>
      <td>W</td>
      <td>Finistere</td>
      <td>29872.0</td>
      <td>6842.0</td>
      <td>15.0</td>
      <td>23945.0</td>
      <td>28392.0</td>
      <td>25143.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>78.0</td>
      <td>25.0</td>
      <td>36.0</td>
      <td>77.0</td>
      <td>81.0</td>
      <td>42.0</td>
      <td>276.210</td>
      <td>6733.0</td>
      <td>524.40</td>
      <td>MULTIPOLYGON (((134794 2434061, 134532 2434541...</td>
    </tr>
    <tr>
      <th>27</th>
      <td>30.0</td>
      <td>S</td>
      <td>Gard</td>
      <td>13115.0</td>
      <td>7990.0</td>
      <td>40.0</td>
      <td>3048.0</td>
      <td>28726.0</td>
      <td>18292.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>39.0</td>
      <td>59.0</td>
      <td>20.0</td>
      <td>40.0</td>
      <td>40.0</td>
      <td>5.0</td>
      <td>323.004</td>
      <td>5853.0</td>
      <td>357.38</td>
      <td>POLYGON ((719592 1880745, 719924 1881419, 7194...</td>
    </tr>
    <tr>
      <th>28</th>
      <td>31.0</td>
      <td>S</td>
      <td>Haute-Garonne</td>
      <td>18642.0</td>
      <td>7204.0</td>
      <td>31.0</td>
      <td>2286.0</td>
      <td>15378.0</td>
      <td>56140.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>59.0</td>
      <td>13.0</td>
      <td>25.0</td>
      <td>15.0</td>
      <td>33.0</td>
      <td>8.0</td>
      <td>361.668</td>
      <td>6257.0</td>
      <td>427.86</td>
      <td>POLYGON ((491745 1820323, 491926 1820668, 4914...</td>
    </tr>
    <tr>
      <th>29</th>
      <td>32.0</td>
      <td>S</td>
      <td>Gers</td>
      <td>18642.0</td>
      <td>10486.0</td>
      <td>38.0</td>
      <td>2848.0</td>
      <td>15250.0</td>
      <td>61510.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>13.0</td>
      <td>32.0</td>
      <td>74.0</td>
      <td>30.0</td>
      <td>44.0</td>
      <td>1.0</td>
      <td>343.569</td>
      <td>6309.0</td>
      <td>312.16</td>
      <td>POLYGON ((447673 1816738, 447362 1816893, 4463...</td>
    </tr>
    <tr>
      <th>30</th>
      <td>33.0</td>
      <td>W</td>
      <td>Gironde</td>
      <td>24096.0</td>
      <td>7423.0</td>
      <td>40.0</td>
      <td>5076.0</td>
      <td>10676.0</td>
      <td>19220.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>80.0</td>
      <td>48.0</td>
      <td>4.0</td>
      <td>13.0</td>
      <td>41.0</td>
      <td>39.0</td>
      <td>291.624</td>
      <td>10000.0</td>
      <td>554.23</td>
      <td>MULTIPOLYGON (((332874 1966651, 332777 1966980...</td>
    </tr>
    <tr>
      <th>31</th>
      <td>34.0</td>
      <td>S</td>
      <td>Herault</td>
      <td>12814.0</td>
      <td>10954.0</td>
      <td>45.0</td>
      <td>1680.0</td>
      <td>21346.0</td>
      <td>30869.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>51.0</td>
      <td>28.0</td>
      <td>19.0</td>
      <td>43.0</td>
      <td>32.0</td>
      <td>9.0</td>
      <td>344.030</td>
      <td>6101.0</td>
      <td>346.30</td>
      <td>POLYGON ((739523 1864067, 740853 1864454, 7414...</td>
    </tr>
    <tr>
      <th>32</th>
      <td>35.0</td>
      <td>W</td>
      <td>Ille-et-Vilaine</td>
      <td>22138.0</td>
      <td>6524.0</td>
      <td>25.0</td>
      <td>7686.0</td>
      <td>40736.0</td>
      <td>45180.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>31.0</td>
      <td>22.0</td>
      <td>37.0</td>
      <td>50.0</td>
      <td>66.0</td>
      <td>77.0</td>
      <td>179.379</td>
      <td>6775.0</td>
      <td>547.05</td>
      <td>MULTIPOLYGON (((271910 2322460, 272047 2322795...</td>
    </tr>
    <tr>
      <th>33</th>
      <td>36.0</td>
      <td>C</td>
      <td>Indre</td>
      <td>32404.0</td>
      <td>7624.0</td>
      <td>17.0</td>
      <td>11315.0</td>
      <td>20046.0</td>
      <td>25014.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>19.0</td>
      <td>83.0</td>
      <td>69.0</td>
      <td>29.0</td>
      <td>79.0</td>
      <td>14.0</td>
      <td>139.587</td>
      <td>6791.0</td>
      <td>245.29</td>
      <td>POLYGON ((573430 2159520, 573109 2159583, 5726...</td>
    </tr>
    <tr>
      <th>34</th>
      <td>37.0</td>
      <td>C</td>
      <td>Indre-et-Loire</td>
      <td>19131.0</td>
      <td>6909.0</td>
      <td>27.0</td>
      <td>7254.0</td>
      <td>16601.0</td>
      <td>15272.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>3.0</td>
      <td>41.0</td>
      <td>15.0</td>
      <td>49.0</td>
      <td>63.0</td>
      <td>59.0</td>
      <td>126.468</td>
      <td>6127.0</td>
      <td>297.02</td>
      <td>POLYGON ((505590 2270755, 507478 2268385, 5076...</td>
    </tr>
    <tr>
      <th>35</th>
      <td>38.0</td>
      <td>E</td>
      <td>Isere</td>
      <td>18785.0</td>
      <td>8326.0</td>
      <td>29.0</td>
      <td>4077.0</td>
      <td>12236.0</td>
      <td>36275.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>27.0</td>
      <td>73.0</td>
      <td>23.0</td>
      <td>26.0</td>
      <td>57.0</td>
      <td>12.0</td>
      <td>268.661</td>
      <td>7431.0</td>
      <td>550.26</td>
      <td>POLYGON ((839825 2094355, 840895 2093318, 8411...</td>
    </tr>
    <tr>
      <th>36</th>
      <td>39.0</td>
      <td>E</td>
      <td>Jura</td>
      <td>26221.0</td>
      <td>8059.0</td>
      <td>73.0</td>
      <td>3012.0</td>
      <td>20384.0</td>
      <td>34476.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>66.0</td>
      <td>43.0</td>
      <td>39.0</td>
      <td>71.0</td>
      <td>3.0</td>
      <td>32.0</td>
      <td>197.155</td>
      <td>4999.0</td>
      <td>312.50</td>
      <td>MULTIPOLYGON (((836965 2209730, 836855 2209785...</td>
    </tr>
    <tr>
      <th>37</th>
      <td>40.0</td>
      <td>W</td>
      <td>Landes</td>
      <td>17687.0</td>
      <td>6170.0</td>
      <td>28.0</td>
      <td>12059.0</td>
      <td>15302.0</td>
      <td>35375.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>43.0</td>
      <td>56.0</td>
      <td>73.0</td>
      <td>28.0</td>
      <td>58.0</td>
      <td>3.0</td>
      <td>344.676</td>
      <td>9243.0</td>
      <td>281.50</td>
      <td>POLYGON ((311864 1932711, 314132 1946872, 3141...</td>
    </tr>
    <tr>
      <th>38</th>
      <td>41.0</td>
      <td>C</td>
      <td>Loir-et-Cher</td>
      <td>21292.0</td>
      <td>6017.0</td>
      <td>27.0</td>
      <td>5626.0</td>
      <td>13364.0</td>
      <td>14417.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>37.0</td>
      <td>70.0</td>
      <td>46.0</td>
      <td>54.0</td>
      <td>61.0</td>
      <td>54.0</td>
      <td>90.735</td>
      <td>6343.0</td>
      <td>235.75</td>
      <td>POLYGON ((519655 2330465, 520005 2329830, 5225...</td>
    </tr>
    <tr>
      <th>39</th>
      <td>42.0</td>
      <td>C</td>
      <td>Loire</td>
      <td>27491.0</td>
      <td>12665.0</td>
      <td>29.0</td>
      <td>3446.0</td>
      <td>29605.0</td>
      <td>71364.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>77.0</td>
      <td>34.0</td>
      <td>42.0</td>
      <td>6.0</td>
      <td>56.0</td>
      <td>14.0</td>
      <td>215.598</td>
      <td>4781.0</td>
      <td>391.22</td>
      <td>POLYGON ((732285 2132610, 732782 2133196, 7330...</td>
    </tr>
    <tr>
      <th>40</th>
      <td>43.0</td>
      <td>C</td>
      <td>Haute-Loire</td>
      <td>16170.0</td>
      <td>18043.0</td>
      <td>21.0</td>
      <td>2746.0</td>
      <td>31017.0</td>
      <td>163241.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>17.0</td>
      <td>65.0</td>
      <td>62.0</td>
      <td>3.0</td>
      <td>72.0</td>
      <td>10.0</td>
      <td>248.877</td>
      <td>4977.0</td>
      <td>292.08</td>
      <td>POLYGON ((742975 2044820, 744433 2045165, 7460...</td>
    </tr>
    <tr>
      <th>41</th>
      <td>44.0</td>
      <td>W</td>
      <td>Loire-Inferieure</td>
      <td>19314.0</td>
      <td>9392.0</td>
      <td>24.0</td>
      <td>8310.0</td>
      <td>14097.0</td>
      <td>27289.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>52.0</td>
      <td>29.0</td>
      <td>12.0</td>
      <td>45.0</td>
      <td>67.0</td>
      <td>63.0</td>
      <td>199.167</td>
      <td>6815.0</td>
      <td>470.09</td>
      <td>POLYGON ((268705 2263645, 268976 2263891, 2710...</td>
    </tr>
    <tr>
      <th>42</th>
      <td>45.0</td>
      <td>C</td>
      <td>Loiret</td>
      <td>17722.0</td>
      <td>5042.0</td>
      <td>42.0</td>
      <td>4753.0</td>
      <td>9986.0</td>
      <td>11813.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>22.0</td>
      <td>16.0</td>
      <td>17.0</td>
      <td>60.0</td>
      <td>37.0</td>
      <td>256.0</td>
      <td>61.106</td>
      <td>6775.0</td>
      <td>305.28</td>
      <td>POLYGON ((557890 2341355, 558382 2341921, 5598...</td>
    </tr>
    <tr>
      <th>43</th>
      <td>46.0</td>
      <td>S</td>
      <td>Lot</td>
      <td>5883.0</td>
      <td>9049.0</td>
      <td>24.0</td>
      <td>5194.0</td>
      <td>20383.0</td>
      <td>48783.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>15.0</td>
      <td>68.0</td>
      <td>78.0</td>
      <td>24.0</td>
      <td>68.0</td>
      <td>1.0</td>
      <td>275.725</td>
      <td>5217.0</td>
      <td>283.83</td>
      <td>POLYGON ((503966 1958060, 505528 1959658, 5058...</td>
    </tr>
    <tr>
      <th>44</th>
      <td>47.0</td>
      <td>W</td>
      <td>Lot-et-Garonne</td>
      <td>22969.0</td>
      <td>8943.0</td>
      <td>31.0</td>
      <td>4432.0</td>
      <td>17681.0</td>
      <td>38501.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>32.0</td>
      <td>46.0</td>
      <td>52.0</td>
      <td>34.0</td>
      <td>50.0</td>
      <td>5.0</td>
      <td>302.345</td>
      <td>5361.0</td>
      <td>346.89</td>
      <td>POLYGON ((413714 1942691, 413362 1942587, 4128...</td>
    </tr>
    <tr>
      <th>45</th>
      <td>48.0</td>
      <td>S</td>
      <td>Lozere</td>
      <td>7710.0</td>
      <td>5990.0</td>
      <td>27.0</td>
      <td>2040.0</td>
      <td>25157.0</td>
      <td>11092.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>45.0</td>
      <td>42.0</td>
      <td>86.0</td>
      <td>5.0</td>
      <td>60.0</td>
      <td>0.0</td>
      <td>283.810</td>
      <td>5167.0</td>
      <td>140.35</td>
      <td>POLYGON ((702442 1987131, 703082 1987282, 7033...</td>
    </tr>
    <tr>
      <th>46</th>
      <td>49.0</td>
      <td>W</td>
      <td>Maine-et-Loire</td>
      <td>29692.0</td>
      <td>8520.0</td>
      <td>23.0</td>
      <td>4410.0</td>
      <td>18708.0</td>
      <td>33358.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>36.0</td>
      <td>20.0</td>
      <td>24.0</td>
      <td>76.0</td>
      <td>70.0</td>
      <td>35.0</td>
      <td>157.437</td>
      <td>7166.0</td>
      <td>467.87</td>
      <td>POLYGON ((409765 2298980, 409716 2297568, 4099...</td>
    </tr>
    <tr>
      <th>47</th>
      <td>50.0</td>
      <td>N</td>
      <td>Manche</td>
      <td>31078.0</td>
      <td>7424.0</td>
      <td>43.0</td>
      <td>5179.0</td>
      <td>14281.0</td>
      <td>55564.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>70.0</td>
      <td>3.0</td>
      <td>59.0</td>
      <td>21.0</td>
      <td>36.0</td>
      <td>98.0</td>
      <td>157.187</td>
      <td>5938.0</td>
      <td>591.28</td>
      <td>MULTIPOLYGON (((316425 2410987, 316287 2411065...</td>
    </tr>
    <tr>
      <th>48</th>
      <td>51.0</td>
      <td>N</td>
      <td>Marne</td>
      <td>15602.0</td>
      <td>4950.0</td>
      <td>63.0</td>
      <td>3963.0</td>
      <td>11267.0</td>
      <td>8334.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>58.0</td>
      <td>39.0</td>
      <td>22.0</td>
      <td>81.0</td>
      <td>10.0</td>
      <td>262.0</td>
      <td>77.364</td>
      <td>6211.0</td>
      <td>337.08</td>
      <td>POLYGON ((781920 2395187, 781562 2395133, 7809...</td>
    </tr>
    <tr>
      <th>49</th>
      <td>52.0</td>
      <td>E</td>
      <td>Haute-Marne</td>
      <td>26231.0</td>
      <td>9539.0</td>
      <td>72.0</td>
      <td>4013.0</td>
      <td>17507.0</td>
      <td>19586.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>55.0</td>
      <td>4.0</td>
      <td>56.0</td>
      <td>65.0</td>
      <td>4.0</td>
      <td>138.0</td>
      <td>129.765</td>
      <td>8162.0</td>
      <td>249.83</td>
      <td>POLYGON ((776565 2346640, 776344 2346943, 7780...</td>
    </tr>
    <tr>
      <th>50</th>
      <td>53.0</td>
      <td>W</td>
      <td>Mayenne</td>
      <td>28331.0</td>
      <td>9198.0</td>
      <td>19.0</td>
      <td>2107.0</td>
      <td>18544.0</td>
      <td>28331.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>40.0</td>
      <td>8.0</td>
      <td>61.0</td>
      <td>58.0</td>
      <td>75.0</td>
      <td>46.0</td>
      <td>139.999</td>
      <td>5175.0</td>
      <td>352.59</td>
      <td>POLYGON ((394355 2321180, 394249 2320876, 3943...</td>
    </tr>
    <tr>
      <th>51</th>
      <td>54.0</td>
      <td>E</td>
      <td>Meurthe</td>
      <td>26674.0</td>
      <td>6831.0</td>
      <td>68.0</td>
      <td>3912.0</td>
      <td>12355.0</td>
      <td>15652.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>71.0</td>
      <td>1.0</td>
      <td>21.0</td>
      <td>70.0</td>
      <td>8.0</td>
      <td>154.0</td>
      <td>159.648</td>
      <td>5241.0</td>
      <td>415.57</td>
      <td>MULTIPOLYGON (((826186 2502671, 825892 2502926...</td>
    </tr>
    <tr>
      <th>52</th>
      <td>55.0</td>
      <td>N</td>
      <td>Meuse</td>
      <td>24507.0</td>
      <td>9190.0</td>
      <td>74.0</td>
      <td>4196.0</td>
      <td>17333.0</td>
      <td>13463.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>65.0</td>
      <td>12.0</td>
      <td>58.0</td>
      <td>59.0</td>
      <td>1.0</td>
      <td>131.0</td>
      <td>126.378</td>
      <td>6216.0</td>
      <td>314.59</td>
      <td>POLYGON ((853530 2462643, 853898 2462654, 8542...</td>
    </tr>
    <tr>
      <th>53</th>
      <td>56.0</td>
      <td>W</td>
      <td>Morbihan</td>
      <td>23316.0</td>
      <td>7940.0</td>
      <td>14.0</td>
      <td>14739.0</td>
      <td>31754.0</td>
      <td>34196.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>29.0</td>
      <td>7.0</td>
      <td>32.0</td>
      <td>69.0</td>
      <td>82.0</td>
      <td>38.0</td>
      <td>230.531</td>
      <td>6823.0</td>
      <td>433.52</td>
      <td>MULTIPOLYGON (((167530 2307010, 167140 2307457...</td>
    </tr>
    <tr>
      <th>54</th>
      <td>57.0</td>
      <td>N</td>
      <td>Moselle</td>
      <td>12153.0</td>
      <td>4529.0</td>
      <td>57.0</td>
      <td>9515.0</td>
      <td>13877.0</td>
      <td>25572.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>9.0</td>
      <td>2.0</td>
      <td>16.0</td>
      <td>68.0</td>
      <td>16.0</td>
      <td>165.0</td>
      <td>180.462</td>
      <td>6216.0</td>
      <td>417.00</td>
      <td>POLYGON ((929062 2475639, 929093 2476415, 9280...</td>
    </tr>
    <tr>
      <th>55</th>
      <td>58.0</td>
      <td>C</td>
      <td>Nievre</td>
      <td>25087.0</td>
      <td>8236.0</td>
      <td>20.0</td>
      <td>10452.0</td>
      <td>19747.0</td>
      <td>29381.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>20.0</td>
      <td>80.0</td>
      <td>63.0</td>
      <td>37.0</td>
      <td>74.0</td>
      <td>39.0</td>
      <td>119.718</td>
      <td>6817.0</td>
      <td>282.52</td>
      <td>POLYGON ((715920 2264185, 717135 2264065, 7172...</td>
    </tr>
    <tr>
      <th>56</th>
      <td>59.0</td>
      <td>N</td>
      <td>Nord</td>
      <td>26740.0</td>
      <td>6175.0</td>
      <td>45.0</td>
      <td>6092.0</td>
      <td>8926.0</td>
      <td>13851.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>81.0</td>
      <td>38.0</td>
      <td>7.0</td>
      <td>64.0</td>
      <td>30.0</td>
      <td>308.0</td>
      <td>106.335</td>
      <td>5743.0</td>
      <td>989.94</td>
      <td>MULTIPOLYGON (((664166 2630647, 664342 2629299...</td>
    </tr>
    <tr>
      <th>57</th>
      <td>60.0</td>
      <td>N</td>
      <td>Oise</td>
      <td>28180.0</td>
      <td>6659.0</td>
      <td>54.0</td>
      <td>5501.0</td>
      <td>18021.0</td>
      <td>5994.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>86.0</td>
      <td>50.0</td>
      <td>43.0</td>
      <td>57.0</td>
      <td>20.0</td>
      <td>337.0</td>
      <td>33.768</td>
      <td>5860.0</td>
      <td>397.73</td>
      <td>MULTIPOLYGON (((647667 2468296, 647542 2468371...</td>
    </tr>
    <tr>
      <th>58</th>
      <td>61.0</td>
      <td>N</td>
      <td>Orne</td>
      <td>28329.0</td>
      <td>8248.0</td>
      <td>45.0</td>
      <td>9242.0</td>
      <td>20852.0</td>
      <td>34069.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>50.0</td>
      <td>31.0</td>
      <td>57.0</td>
      <td>25.0</td>
      <td>33.0</td>
      <td>117.0</td>
      <td>97.554</td>
      <td>6103.0</td>
      <td>441.88</td>
      <td>POLYGON ((469173 2432434, 470681 2434059, 4709...</td>
    </tr>
    <tr>
      <th>59</th>
      <td>62.0</td>
      <td>N</td>
      <td>Pas-de-Calais</td>
      <td>23101.0</td>
      <td>4040.0</td>
      <td>49.0</td>
      <td>5740.0</td>
      <td>10575.0</td>
      <td>15400.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>79.0</td>
      <td>10.0</td>
      <td>27.0</td>
      <td>48.0</td>
      <td>26.0</td>
      <td>163.0</td>
      <td>104.400</td>
      <td>6671.0</td>
      <td>655.22</td>
      <td>POLYGON ((629822 2560555, 629583 2560843, 6291...</td>
    </tr>
    <tr>
      <th>60</th>
      <td>63.0</td>
      <td>C</td>
      <td>Puy-de-Dome</td>
      <td>17256.0</td>
      <td>12141.0</td>
      <td>19.0</td>
      <td>5963.0</td>
      <td>22948.0</td>
      <td>78148.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>63.0</td>
      <td>61.0</td>
      <td>53.0</td>
      <td>8.0</td>
      <td>76.0</td>
      <td>62.0</td>
      <td>205.218</td>
      <td>7970.0</td>
      <td>573.11</td>
      <td>POLYGON ((615585 2050805, 615649 2051154, 6162...</td>
    </tr>
    <tr>
      <th>61</th>
      <td>64.0</td>
      <td>W</td>
      <td>Basses-Pyrenees</td>
      <td>16722.0</td>
      <td>8533.0</td>
      <td>47.0</td>
      <td>3299.0</td>
      <td>12393.0</td>
      <td>65995.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>72.0</td>
      <td>60.0</td>
      <td>34.0</td>
      <td>7.0</td>
      <td>28.0</td>
      <td>12.0</td>
      <td>387.935</td>
      <td>7645.0</td>
      <td>428.40</td>
      <td>POLYGON ((386095 1774604, 386085 1774237, 3855...</td>
    </tr>
    <tr>
      <th>62</th>
      <td>65.0</td>
      <td>S</td>
      <td>Hautes-Pyrenees</td>
      <td>12223.0</td>
      <td>9797.0</td>
      <td>53.0</td>
      <td>6001.0</td>
      <td>12125.0</td>
      <td>148039.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>75.0</td>
      <td>71.0</td>
      <td>76.0</td>
      <td>20.0</td>
      <td>21.0</td>
      <td>5.0</td>
      <td>386.559</td>
      <td>4464.0</td>
      <td>233.03</td>
      <td>MULTIPOLYGON (((406987 1826038, 405019 1826121...</td>
    </tr>
    <tr>
      <th>63</th>
      <td>66.0</td>
      <td>S</td>
      <td>Pyrenees-Orientales</td>
      <td>6728.0</td>
      <td>7632.0</td>
      <td>31.0</td>
      <td>11644.0</td>
      <td>15167.0</td>
      <td>37843.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>84.0</td>
      <td>77.0</td>
      <td>11.0</td>
      <td>18.0</td>
      <td>52.0</td>
      <td>5.0</td>
      <td>403.445</td>
      <td>4116.0</td>
      <td>157.05</td>
      <td>POLYGON ((658127 1733192, 658228 1732843, 6582...</td>
    </tr>
    <tr>
      <th>64</th>
      <td>67.0</td>
      <td>E</td>
      <td>Bas-Rhin</td>
      <td>12309.0</td>
      <td>4920.0</td>
      <td>62.0</td>
      <td>14472.0</td>
      <td>14356.0</td>
      <td>18623.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>48.0</td>
      <td>51.0</td>
      <td>5.0</td>
      <td>53.0</td>
      <td>12.0</td>
      <td>101.0</td>
      <td>217.752</td>
      <td>4755.0</td>
      <td>540.21</td>
      <td>POLYGON ((946663 2460717, 946292 2461188, 9461...</td>
    </tr>
    <tr>
      <th>65</th>
      <td>68.0</td>
      <td>E</td>
      <td>Haut-Rhin</td>
      <td>7343.0</td>
      <td>4915.0</td>
      <td>71.0</td>
      <td>6001.0</td>
      <td>14783.0</td>
      <td>21233.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>53.0</td>
      <td>17.0</td>
      <td>10.0</td>
      <td>56.0</td>
      <td>5.0</td>
      <td>26.0</td>
      <td>217.971</td>
      <td>3525.0</td>
      <td>424.26</td>
      <td>POLYGON ((989865 2319005, 990659 2316949, 9900...</td>
    </tr>
    <tr>
      <th>66</th>
      <td>69.0</td>
      <td>E</td>
      <td>Rhone</td>
      <td>18793.0</td>
      <td>4504.0</td>
      <td>45.0</td>
      <td>1983.0</td>
      <td>3910.0</td>
      <td>17003.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>33.0</td>
      <td>21.0</td>
      <td>2.0</td>
      <td>14.0</td>
      <td>31.0</td>
      <td>104.0</td>
      <td>213.032</td>
      <td>3249.0</td>
      <td>434.43</td>
      <td>POLYGON ((752410 2115380, 752067 2115294, 7510...</td>
    </tr>
    <tr>
      <th>67</th>
      <td>70.0</td>
      <td>E</td>
      <td>Haute-Saone</td>
      <td>22339.0</td>
      <td>7770.0</td>
      <td>59.0</td>
      <td>11701.0</td>
      <td>11850.0</td>
      <td>39714.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>68.0</td>
      <td>57.0</td>
      <td>65.0</td>
      <td>83.0</td>
      <td>14.0</td>
      <td>99.0</td>
      <td>176.135</td>
      <td>5360.0</td>
      <td>338.91</td>
      <td>POLYGON ((933555 2291420, 933269 2291556, 9326...</td>
    </tr>
    <tr>
      <th>68</th>
      <td>71.0</td>
      <td>E</td>
      <td>Saone-et-Loire</td>
      <td>28391.0</td>
      <td>10708.0</td>
      <td>32.0</td>
      <td>3710.0</td>
      <td>20442.0</td>
      <td>22184.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>10.0</td>
      <td>58.0</td>
      <td>45.0</td>
      <td>31.0</td>
      <td>49.0</td>
      <td>40.0</td>
      <td>168.713</td>
      <td>8575.0</td>
      <td>523.97</td>
      <td>POLYGON ((834930 2207585, 834681 2207740, 8344...</td>
    </tr>
    <tr>
      <th>69</th>
      <td>72.0</td>
      <td>C</td>
      <td>Sarthe</td>
      <td>33913.0</td>
      <td>8294.0</td>
      <td>30.0</td>
      <td>3357.0</td>
      <td>10779.0</td>
      <td>29280.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>57.0</td>
      <td>19.0</td>
      <td>49.0</td>
      <td>75.0</td>
      <td>35.0</td>
      <td>79.0</td>
      <td>108.294</td>
      <td>6206.0</td>
      <td>457.37</td>
      <td>POLYGON ((470543 2362046, 471980 2361813, 4726...</td>
    </tr>
    <tr>
      <th>70</th>
      <td>75.0</td>
      <td>N</td>
      <td>Seine</td>
      <td>13945.0</td>
      <td>1368.0</td>
      <td>71.0</td>
      <td>4204.0</td>
      <td>2660.0</td>
      <td>3632.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>67.0</td>
      <td>53.0</td>
      <td>1.0</td>
      <td>33.0</td>
      <td>6.0</td>
      <td>4744.0</td>
      <td>0.000</td>
      <td>762.0</td>
      <td>935.11</td>
      <td>POLYGON ((615302 2411120, 615000 2411180, 6143...</td>
    </tr>
    <tr>
      <th>71</th>
      <td>76.0</td>
      <td>N</td>
      <td>Seine-Inferieure</td>
      <td>18355.0</td>
      <td>2906.0</td>
      <td>43.0</td>
      <td>7245.0</td>
      <td>7506.0</td>
      <td>9523.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>61.0</td>
      <td>74.0</td>
      <td>9.0</td>
      <td>36.0</td>
      <td>35.0</td>
      <td>546.0</td>
      <td>75.658</td>
      <td>6278.0</td>
      <td>693.68</td>
      <td>POLYGON ((438965 2512493, 440124 2514448, 4402...</td>
    </tr>
    <tr>
      <th>72</th>
      <td>77.0</td>
      <td>N</td>
      <td>Seine-et-Marne</td>
      <td>22201.0</td>
      <td>5786.0</td>
      <td>54.0</td>
      <td>5303.0</td>
      <td>16324.0</td>
      <td>7315.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>73.0</td>
      <td>26.0</td>
      <td>29.0</td>
      <td>67.0</td>
      <td>37.0</td>
      <td>453.0</td>
      <td>27.647</td>
      <td>5915.0</td>
      <td>323.89</td>
      <td>POLYGON ((675580 2375994, 675218 2376008, 6748...</td>
    </tr>
    <tr>
      <th>73</th>
      <td>78.0</td>
      <td>N</td>
      <td>Seine-et-Oise</td>
      <td>12477.0</td>
      <td>3879.0</td>
      <td>56.0</td>
      <td>4007.0</td>
      <td>16303.0</td>
      <td>3460.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>30.0</td>
      <td>24.0</td>
      <td>6.0</td>
      <td>42.0</td>
      <td>17.0</td>
      <td>874.0</td>
      <td>16.888</td>
      <td>5334.0</td>
      <td>448.18</td>
      <td>POLYGON ((546799 2453567, 547588 2454258, 5478...</td>
    </tr>
    <tr>
      <th>74</th>
      <td>79.0</td>
      <td>W</td>
      <td>Deux-Sevres</td>
      <td>18400.0</td>
      <td>6863.0</td>
      <td>41.0</td>
      <td>16956.0</td>
      <td>25461.0</td>
      <td>24533.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>4.0</td>
      <td>85.0</td>
      <td>71.0</td>
      <td>84.0</td>
      <td>39.0</td>
      <td>6.0</td>
      <td>188.474</td>
      <td>5999.0</td>
      <td>297.85</td>
      <td>POLYGON ((419808 2218480, 420449 2218054, 4209...</td>
    </tr>
    <tr>
      <th>75</th>
      <td>80.0</td>
      <td>N</td>
      <td>Somme</td>
      <td>33592.0</td>
      <td>7144.0</td>
      <td>44.0</td>
      <td>4964.0</td>
      <td>12447.0</td>
      <td>12836.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>64.0</td>
      <td>33.0</td>
      <td>30.0</td>
      <td>80.0</td>
      <td>34.0</td>
      <td>302.0</td>
      <td>69.520</td>
      <td>6170.0</td>
      <td>543.70</td>
      <td>POLYGON ((543667 2592806, 544247 2596216, 5451...</td>
    </tr>
    <tr>
      <th>76</th>
      <td>81.0</td>
      <td>S</td>
      <td>Tarn</td>
      <td>13019.0</td>
      <td>6241.0</td>
      <td>20.0</td>
      <td>3449.0</td>
      <td>29305.0</td>
      <td>68980.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>9.0</td>
      <td>47.0</td>
      <td>67.0</td>
      <td>17.0</td>
      <td>73.0</td>
      <td>3.0</td>
      <td>328.146</td>
      <td>5758.0</td>
      <td>333.84</td>
      <td>POLYGON ((548083 1858875, 547740 1858741, 5469...</td>
    </tr>
    <tr>
      <th>77</th>
      <td>82.0</td>
      <td>S</td>
      <td>Tarn-et-Garonne</td>
      <td>14790.0</td>
      <td>8680.0</td>
      <td>25.0</td>
      <td>4558.0</td>
      <td>23771.0</td>
      <td>48317.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>41.0</td>
      <td>52.0</td>
      <td>64.0</td>
      <td>39.0</td>
      <td>64.0</td>
      <td>4.0</td>
      <td>313.090</td>
      <td>3718.0</td>
      <td>242.51</td>
      <td>POLYGON ((572261 1905414, 571717 1905736, 5705...</td>
    </tr>
    <tr>
      <th>78</th>
      <td>83.0</td>
      <td>S</td>
      <td>Var</td>
      <td>13145.0</td>
      <td>9572.0</td>
      <td>23.0</td>
      <td>2449.0</td>
      <td>14800.0</td>
      <td>13380.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>49.0</td>
      <td>40.0</td>
      <td>26.0</td>
      <td>52.0</td>
      <td>69.0</td>
      <td>6.0</td>
      <td>389.512</td>
      <td>5973.0</td>
      <td>317.50</td>
      <td>MULTIPOLYGON (((937679 1788572, 937646 1788379...</td>
    </tr>
    <tr>
      <th>79</th>
      <td>84.0</td>
      <td>S</td>
      <td>Vaucluse</td>
      <td>13576.0</td>
      <td>5731.0</td>
      <td>37.0</td>
      <td>1246.0</td>
      <td>17239.0</td>
      <td>19024.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>76.0</td>
      <td>54.0</td>
      <td>8.0</td>
      <td>41.0</td>
      <td>45.0</td>
      <td>2.0</td>
      <td>337.215</td>
      <td>3567.0</td>
      <td>239.11</td>
      <td>MULTIPOLYGON (((811669 1924852, 811384 1925100...</td>
    </tr>
    <tr>
      <th>80</th>
      <td>85.0</td>
      <td>W</td>
      <td>Vendee</td>
      <td>20827.0</td>
      <td>7566.0</td>
      <td>28.0</td>
      <td>14035.0</td>
      <td>62486.0</td>
      <td>67963.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>44.0</td>
      <td>30.0</td>
      <td>68.0</td>
      <td>79.0</td>
      <td>59.0</td>
      <td>4.0</td>
      <td>212.459</td>
      <td>6720.0</td>
      <td>330.36</td>
      <td>MULTIPOLYGON (((243055 2197885, 243019 2198089...</td>
    </tr>
    <tr>
      <th>81</th>
      <td>86.0</td>
      <td>W</td>
      <td>Vienne</td>
      <td>15010.0</td>
      <td>4710.0</td>
      <td>25.0</td>
      <td>8922.0</td>
      <td>35224.0</td>
      <td>21851.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>1.0</td>
      <td>44.0</td>
      <td>40.0</td>
      <td>38.0</td>
      <td>65.0</td>
      <td>18.0</td>
      <td>170.523</td>
      <td>6990.0</td>
      <td>282.73</td>
      <td>POLYGON ((450395 2119945, 450065 2120124, 4494...</td>
    </tr>
    <tr>
      <th>82</th>
      <td>87.0</td>
      <td>C</td>
      <td>Haute-Vienne</td>
      <td>16256.0</td>
      <td>6402.0</td>
      <td>13.0</td>
      <td>13817.0</td>
      <td>19940.0</td>
      <td>33497.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>6.0</td>
      <td>78.0</td>
      <td>55.0</td>
      <td>11.0</td>
      <td>84.0</td>
      <td>7.0</td>
      <td>198.874</td>
      <td>5520.0</td>
      <td>285.13</td>
      <td>POLYGON ((515230 2049895, 514990 2049594, 5143...</td>
    </tr>
    <tr>
      <th>83</th>
      <td>88.0</td>
      <td>E</td>
      <td>Vosges</td>
      <td>18835.0</td>
      <td>9044.0</td>
      <td>62.0</td>
      <td>4040.0</td>
      <td>14978.0</td>
      <td>33029.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>34.0</td>
      <td>5.0</td>
      <td>14.0</td>
      <td>85.0</td>
      <td>11.0</td>
      <td>43.0</td>
      <td>174.477</td>
      <td>5874.0</td>
      <td>397.99</td>
      <td>POLYGON ((951144 2383215, 953082 2382491, 9534...</td>
    </tr>
    <tr>
      <th>84</th>
      <td>89.0</td>
      <td>C</td>
      <td>Yonne</td>
      <td>18006.0</td>
      <td>6516.0</td>
      <td>47.0</td>
      <td>4276.0</td>
      <td>16616.0</td>
      <td>12789.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>22.0</td>
      <td>35.0</td>
      <td>51.0</td>
      <td>66.0</td>
      <td>27.0</td>
      <td>272.0</td>
      <td>81.797</td>
      <td>7427.0</td>
      <td>352.49</td>
      <td>POLYGON ((650260 2358330, 651712 2361305, 6528...</td>
    </tr>
  </tbody>
</table>
<p>85 rows × 24 columns</p>
</div>




```python
guerry.plot(column = 'Litercy')
```




    <Axes: >




    
![png](output_137_1.png)
    



```python
guerry.plot(column = 'Litercy', legend = True)
```




    <Axes: >




    
![png](output_138_1.png)
    


Геометрии объектов являются объектами библиотеки `shapely`


```python
guerry.geometry
```




    0     POLYGON ((801150 2092615, 800669 2093190, 8006...
    1     POLYGON ((729326 2521619, 729320 2521230, 7292...
    2     POLYGON ((710830 2137350, 711746 2136617, 7124...
    3     POLYGON ((882701 1920024, 882408 1920733, 8817...
    4     POLYGON ((886504 1922890, 885733 1922978, 8854...
    5     POLYGON ((747008 1925789, 746630 1925762, 7457...
    6     POLYGON ((818893 2514767, 818614 2514515, 8179...
    7     POLYGON ((509103 1747787, 508820 1747513, 5081...
    8     POLYGON ((775400 2345600, 775068 2345397, 7735...
    9     POLYGON ((626230 1810121, 626269 1810496, 6274...
    10    POLYGON ((642972 1978185, 643791 1976549, 6444...
    11    POLYGON ((824692 1865875, 825615 1865409, 8259...
    12    POLYGON ((345476 2429914, 345299 2430235, 3436...
    13    POLYGON ((591653 2017934, 591727 2018244, 5918...
    14    POLYGON ((456425 2120055, 456229 2120382, 4559...
    15    MULTIPOLYGON (((328075 2118055, 327916 2118168...
    16    POLYGON ((572720 2252955, 574278 2251834, 5753...
    17    POLYGON ((608225 2042680, 608101 2042880, 6079...
    18    MULTIPOLYGON (((738935 2236890, 738359 2237343...
    19    MULTIPOLYGON (((208165 2439753, 208131 2439949...
    20    POLYGON ((540175 2111095, 538135 2111105, 5380...
    21    POLYGON ((527718 1988833, 528808 1988071, 5291...
    22    POLYGON ((886630 2188665, 886948 2188898, 8879...
    23    POLYGON ((830803 2010472, 831288 2010361, 8315...
    24    POLYGON ((515046 2482676, 515755 2483384, 5160...
    25    POLYGON ((562860 2342515, 562499 2342577, 5602...
    26    MULTIPOLYGON (((134794 2434061, 134532 2434541...
    27    POLYGON ((719592 1880745, 719924 1881419, 7194...
    28    POLYGON ((491745 1820323, 491926 1820668, 4914...
    29    POLYGON ((447673 1816738, 447362 1816893, 4463...
    30    MULTIPOLYGON (((332874 1966651, 332777 1966980...
    31    POLYGON ((739523 1864067, 740853 1864454, 7414...
    32    MULTIPOLYGON (((271910 2322460, 272047 2322795...
    33    POLYGON ((573430 2159520, 573109 2159583, 5726...
    34    POLYGON ((505590 2270755, 507478 2268385, 5076...
    35    POLYGON ((839825 2094355, 840895 2093318, 8411...
    36    MULTIPOLYGON (((836965 2209730, 836855 2209785...
    37    POLYGON ((311864 1932711, 314132 1946872, 3141...
    38    POLYGON ((519655 2330465, 520005 2329830, 5225...
    39    POLYGON ((732285 2132610, 732782 2133196, 7330...
    40    POLYGON ((742975 2044820, 744433 2045165, 7460...
    41    POLYGON ((268705 2263645, 268976 2263891, 2710...
    42    POLYGON ((557890 2341355, 558382 2341921, 5598...
    43    POLYGON ((503966 1958060, 505528 1959658, 5058...
    44    POLYGON ((413714 1942691, 413362 1942587, 4128...
    45    POLYGON ((702442 1987131, 703082 1987282, 7033...
    46    POLYGON ((409765 2298980, 409716 2297568, 4099...
    47    MULTIPOLYGON (((316425 2410987, 316287 2411065...
    48    POLYGON ((781920 2395187, 781562 2395133, 7809...
    49    POLYGON ((776565 2346640, 776344 2346943, 7780...
    50    POLYGON ((394355 2321180, 394249 2320876, 3943...
    51    MULTIPOLYGON (((826186 2502671, 825892 2502926...
    52    POLYGON ((853530 2462643, 853898 2462654, 8542...
    53    MULTIPOLYGON (((167530 2307010, 167140 2307457...
    54    POLYGON ((929062 2475639, 929093 2476415, 9280...
    55    POLYGON ((715920 2264185, 717135 2264065, 7172...
    56    MULTIPOLYGON (((664166 2630647, 664342 2629299...
    57    MULTIPOLYGON (((647667 2468296, 647542 2468371...
    58    POLYGON ((469173 2432434, 470681 2434059, 4709...
    59    POLYGON ((629822 2560555, 629583 2560843, 6291...
    60    POLYGON ((615585 2050805, 615649 2051154, 6162...
    61    POLYGON ((386095 1774604, 386085 1774237, 3855...
    62    MULTIPOLYGON (((406987 1826038, 405019 1826121...
    63    POLYGON ((658127 1733192, 658228 1732843, 6582...
    64    POLYGON ((946663 2460717, 946292 2461188, 9461...
    65    POLYGON ((989865 2319005, 990659 2316949, 9900...
    66    POLYGON ((752410 2115380, 752067 2115294, 7510...
    67    POLYGON ((933555 2291420, 933269 2291556, 9326...
    68    POLYGON ((834930 2207585, 834681 2207740, 8344...
    69    POLYGON ((470543 2362046, 471980 2361813, 4726...
    70    POLYGON ((615302 2411120, 615000 2411180, 6143...
    71    POLYGON ((438965 2512493, 440124 2514448, 4402...
    72    POLYGON ((675580 2375994, 675218 2376008, 6748...
    73    POLYGON ((546799 2453567, 547588 2454258, 5478...
    74    POLYGON ((419808 2218480, 420449 2218054, 4209...
    75    POLYGON ((543667 2592806, 544247 2596216, 5451...
    76    POLYGON ((548083 1858875, 547740 1858741, 5469...
    77    POLYGON ((572261 1905414, 571717 1905736, 5705...
    78    MULTIPOLYGON (((937679 1788572, 937646 1788379...
    79    MULTIPOLYGON (((811669 1924852, 811384 1925100...
    80    MULTIPOLYGON (((243055 2197885, 243019 2198089...
    81    POLYGON ((450395 2119945, 450065 2120124, 4494...
    82    POLYGON ((515230 2049895, 514990 2049594, 5143...
    83    POLYGON ((951144 2383215, 953082 2382491, 9534...
    84    POLYGON ((650260 2358330, 651712 2361305, 6528...
    Name: geometry, dtype: geometry




```python
guerry['geometry']
```




    0     POLYGON ((801150 2092615, 800669 2093190, 8006...
    1     POLYGON ((729326 2521619, 729320 2521230, 7292...
    2     POLYGON ((710830 2137350, 711746 2136617, 7124...
    3     POLYGON ((882701 1920024, 882408 1920733, 8817...
    4     POLYGON ((886504 1922890, 885733 1922978, 8854...
    5     POLYGON ((747008 1925789, 746630 1925762, 7457...
    6     POLYGON ((818893 2514767, 818614 2514515, 8179...
    7     POLYGON ((509103 1747787, 508820 1747513, 5081...
    8     POLYGON ((775400 2345600, 775068 2345397, 7735...
    9     POLYGON ((626230 1810121, 626269 1810496, 6274...
    10    POLYGON ((642972 1978185, 643791 1976549, 6444...
    11    POLYGON ((824692 1865875, 825615 1865409, 8259...
    12    POLYGON ((345476 2429914, 345299 2430235, 3436...
    13    POLYGON ((591653 2017934, 591727 2018244, 5918...
    14    POLYGON ((456425 2120055, 456229 2120382, 4559...
    15    MULTIPOLYGON (((328075 2118055, 327916 2118168...
    16    POLYGON ((572720 2252955, 574278 2251834, 5753...
    17    POLYGON ((608225 2042680, 608101 2042880, 6079...
    18    MULTIPOLYGON (((738935 2236890, 738359 2237343...
    19    MULTIPOLYGON (((208165 2439753, 208131 2439949...
    20    POLYGON ((540175 2111095, 538135 2111105, 5380...
    21    POLYGON ((527718 1988833, 528808 1988071, 5291...
    22    POLYGON ((886630 2188665, 886948 2188898, 8879...
    23    POLYGON ((830803 2010472, 831288 2010361, 8315...
    24    POLYGON ((515046 2482676, 515755 2483384, 5160...
    25    POLYGON ((562860 2342515, 562499 2342577, 5602...
    26    MULTIPOLYGON (((134794 2434061, 134532 2434541...
    27    POLYGON ((719592 1880745, 719924 1881419, 7194...
    28    POLYGON ((491745 1820323, 491926 1820668, 4914...
    29    POLYGON ((447673 1816738, 447362 1816893, 4463...
    30    MULTIPOLYGON (((332874 1966651, 332777 1966980...
    31    POLYGON ((739523 1864067, 740853 1864454, 7414...
    32    MULTIPOLYGON (((271910 2322460, 272047 2322795...
    33    POLYGON ((573430 2159520, 573109 2159583, 5726...
    34    POLYGON ((505590 2270755, 507478 2268385, 5076...
    35    POLYGON ((839825 2094355, 840895 2093318, 8411...
    36    MULTIPOLYGON (((836965 2209730, 836855 2209785...
    37    POLYGON ((311864 1932711, 314132 1946872, 3141...
    38    POLYGON ((519655 2330465, 520005 2329830, 5225...
    39    POLYGON ((732285 2132610, 732782 2133196, 7330...
    40    POLYGON ((742975 2044820, 744433 2045165, 7460...
    41    POLYGON ((268705 2263645, 268976 2263891, 2710...
    42    POLYGON ((557890 2341355, 558382 2341921, 5598...
    43    POLYGON ((503966 1958060, 505528 1959658, 5058...
    44    POLYGON ((413714 1942691, 413362 1942587, 4128...
    45    POLYGON ((702442 1987131, 703082 1987282, 7033...
    46    POLYGON ((409765 2298980, 409716 2297568, 4099...
    47    MULTIPOLYGON (((316425 2410987, 316287 2411065...
    48    POLYGON ((781920 2395187, 781562 2395133, 7809...
    49    POLYGON ((776565 2346640, 776344 2346943, 7780...
    50    POLYGON ((394355 2321180, 394249 2320876, 3943...
    51    MULTIPOLYGON (((826186 2502671, 825892 2502926...
    52    POLYGON ((853530 2462643, 853898 2462654, 8542...
    53    MULTIPOLYGON (((167530 2307010, 167140 2307457...
    54    POLYGON ((929062 2475639, 929093 2476415, 9280...
    55    POLYGON ((715920 2264185, 717135 2264065, 7172...
    56    MULTIPOLYGON (((664166 2630647, 664342 2629299...
    57    MULTIPOLYGON (((647667 2468296, 647542 2468371...
    58    POLYGON ((469173 2432434, 470681 2434059, 4709...
    59    POLYGON ((629822 2560555, 629583 2560843, 6291...
    60    POLYGON ((615585 2050805, 615649 2051154, 6162...
    61    POLYGON ((386095 1774604, 386085 1774237, 3855...
    62    MULTIPOLYGON (((406987 1826038, 405019 1826121...
    63    POLYGON ((658127 1733192, 658228 1732843, 6582...
    64    POLYGON ((946663 2460717, 946292 2461188, 9461...
    65    POLYGON ((989865 2319005, 990659 2316949, 9900...
    66    POLYGON ((752410 2115380, 752067 2115294, 7510...
    67    POLYGON ((933555 2291420, 933269 2291556, 9326...
    68    POLYGON ((834930 2207585, 834681 2207740, 8344...
    69    POLYGON ((470543 2362046, 471980 2361813, 4726...
    70    POLYGON ((615302 2411120, 615000 2411180, 6143...
    71    POLYGON ((438965 2512493, 440124 2514448, 4402...
    72    POLYGON ((675580 2375994, 675218 2376008, 6748...
    73    POLYGON ((546799 2453567, 547588 2454258, 5478...
    74    POLYGON ((419808 2218480, 420449 2218054, 4209...
    75    POLYGON ((543667 2592806, 544247 2596216, 5451...
    76    POLYGON ((548083 1858875, 547740 1858741, 5469...
    77    POLYGON ((572261 1905414, 571717 1905736, 5705...
    78    MULTIPOLYGON (((937679 1788572, 937646 1788379...
    79    MULTIPOLYGON (((811669 1924852, 811384 1925100...
    80    MULTIPOLYGON (((243055 2197885, 243019 2198089...
    81    POLYGON ((450395 2119945, 450065 2120124, 4494...
    82    POLYGON ((515230 2049895, 514990 2049594, 5143...
    83    POLYGON ((951144 2383215, 953082 2382491, 9534...
    84    POLYGON ((650260 2358330, 651712 2361305, 6528...
    Name: geometry, dtype: geometry



Фактически колонка `geometry` представляет собой объект `GeoSeries`.
Именно эта колонка то, что отличает `GeoDataFrame` от `DataFrame`


```python
type(guerry['geometry'])
```




    geopandas.geoseries.GeoSeries



Так как в нашем `GeoDataFrame` хранится целый набор объектов, мы можем обращаться к каждому из них отдельно


```python
guerry['geometry'].iloc[20]
```




    
![svg](output_145_0.svg)
    



Кроме того, что у объектов есть геометрия, у них еще есть и система координат CRS (coordinate reference system) описанная в соответствии с реестром **EPSG**.
Про системы координат и их преобразования будет чуть ниже.


```python
guerry.crs
```




    <Projected CRS: EPSG:27572>
    Name: NTF (Paris) / Lambert zone II
    Axis Info [cartesian]:
    - X[east]: Easting (metre)
    - Y[north]: Northing (metre)
    Area of Use:
    - name: France mainland onshore between 50.5 grads and 53.5 grads North (45°27'N to 48°09'N). Also used over all onshore mainland France.
    - bounds: (-4.87, 42.33, 8.23, 51.14)
    Coordinate Operation:
    - name: Lambert zone II
    - method: Lambert Conic Conformal (1SP)
    Datum: Nouvelle Triangulation Francaise (Paris)
    - Ellipsoid: Clarke 1880 (IGN)
    - Prime Meridian: Paris



Так как каждый пространственный объект занимает определенную часть поверхности, мы можем знать охват каждого элемента `GeoDataFrame`.


```python
guerry.bounds
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>minx</th>
      <th>miny</th>
      <th>maxx</th>
      <th>maxy</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>785562.0</td>
      <td>2073221.0</td>
      <td>894622.0</td>
      <td>2172530.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>645357.0</td>
      <td>2427270.0</td>
      <td>738049.0</td>
      <td>2564568.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>595532.0</td>
      <td>2104320.0</td>
      <td>728480.0</td>
      <td>2200625.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>853311.0</td>
      <td>1858801.0</td>
      <td>970310.0</td>
      <td>1972682.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>845528.0</td>
      <td>1915176.0</td>
      <td>975716.0</td>
      <td>2022608.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>720908.0</td>
      <td>1920016.0</td>
      <td>801330.0</td>
      <td>2043510.0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>722230.0</td>
      <td>2472836.0</td>
      <td>821101.0</td>
      <td>2577475.0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>476458.0</td>
      <td>1729992.0</td>
      <td>586665.0</td>
      <td>1813083.0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>677472.0</td>
      <td>2326409.0</td>
      <td>787769.0</td>
      <td>2414830.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>547293.0</td>
      <td>1738382.0</td>
      <td>673587.0</td>
      <td>1828670.0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>560428.0</td>
      <td>1854631.0</td>
      <td>689438.0</td>
      <td>1993474.0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>753479.0</td>
      <td>1801065.0</td>
      <td>880584.0</td>
      <td>1883210.0</td>
    </tr>
    <tr>
      <th>12</th>
      <td>343281.0</td>
      <td>2421791.0</td>
      <td>461649.0</td>
      <td>2494418.0</td>
    </tr>
    <tr>
      <th>13</th>
      <td>578407.0</td>
      <td>1957191.0</td>
      <td>681624.0</td>
      <td>2053570.0</td>
    </tr>
    <tr>
      <th>14</th>
      <td>382200.0</td>
      <td>2023953.0</td>
      <td>492036.0</td>
      <td>2127830.0</td>
    </tr>
    <tr>
      <th>15</th>
      <td>299524.0</td>
      <td>2012956.0</td>
      <td>416924.0</td>
      <td>2157530.0</td>
    </tr>
    <tr>
      <th>16</th>
      <td>557360.0</td>
      <td>2157815.0</td>
      <td>656530.0</td>
      <td>2292170.0</td>
    </tr>
    <tr>
      <th>17</th>
      <td>512915.0</td>
      <td>1991211.0</td>
      <td>614970.0</td>
      <td>2084866.0</td>
    </tr>
    <tr>
      <th>18</th>
      <td>730455.0</td>
      <td>2213900.0</td>
      <td>840550.0</td>
      <td>2339370.0</td>
    </tr>
    <tr>
      <th>19</th>
      <td>158177.0</td>
      <td>2348855.0</td>
      <td>286218.0</td>
      <td>2444887.0</td>
    </tr>
    <tr>
      <th>20</th>
      <td>525780.0</td>
      <td>2073768.0</td>
      <td>621254.0</td>
      <td>2161816.0</td>
    </tr>
    <tr>
      <th>21</th>
      <td>412537.0</td>
      <td>1953083.0</td>
      <td>529961.0</td>
      <td>2080805.0</td>
    </tr>
    <tr>
      <th>22</th>
      <td>854350.0</td>
      <td>2179635.0</td>
      <td>956561.0</td>
      <td>2295645.0</td>
    </tr>
    <tr>
      <th>23</th>
      <td>784328.0</td>
      <td>1906647.0</td>
      <td>876891.0</td>
      <td>2041614.0</td>
    </tr>
    <tr>
      <th>24</th>
      <td>451680.0</td>
      <td>2408681.0</td>
      <td>561119.0</td>
      <td>2500185.0</td>
    </tr>
    <tr>
      <th>25</th>
      <td>482816.0</td>
      <td>2328715.0</td>
      <td>574582.0</td>
      <td>2438418.0</td>
    </tr>
    <tr>
      <th>26</th>
      <td>47680.0</td>
      <td>2323751.0</td>
      <td>172543.0</td>
      <td>2436033.0</td>
    </tr>
    <tr>
      <th>27</th>
      <td>674291.0</td>
      <td>1830522.0</td>
      <td>801413.0</td>
      <td>1941263.0</td>
    </tr>
    <tr>
      <th>28</th>
      <td>445263.0</td>
      <td>1744543.0</td>
      <td>576643.0</td>
      <td>1880284.0</td>
    </tr>
    <tr>
      <th>29</th>
      <td>388461.0</td>
      <td>1813610.0</td>
      <td>508221.0</td>
      <td>1899093.0</td>
    </tr>
    <tr>
      <th>30</th>
      <td>314116.0</td>
      <td>1913779.0</td>
      <td>440128.0</td>
      <td>2069014.0</td>
    </tr>
    <tr>
      <th>31</th>
      <td>616528.0</td>
      <td>1801568.0</td>
      <td>750021.0</td>
      <td>1886461.0</td>
    </tr>
    <tr>
      <th>32</th>
      <td>255035.0</td>
      <td>2301820.0</td>
      <td>349781.0</td>
      <td>2420371.0</td>
    </tr>
    <tr>
      <th>33</th>
      <td>487765.0</td>
      <td>2150095.0</td>
      <td>589810.0</td>
      <td>2253298.0</td>
    </tr>
    <tr>
      <th>34</th>
      <td>426955.0</td>
      <td>2193900.0</td>
      <td>526245.0</td>
      <td>2302342.0</td>
    </tr>
    <tr>
      <th>35</th>
      <td>788362.0</td>
      <td>1972129.0</td>
      <td>917741.0</td>
      <td>2102554.0</td>
    </tr>
    <tr>
      <th>36</th>
      <td>821840.0</td>
      <td>2145394.0</td>
      <td>895467.0</td>
      <td>2261060.0</td>
    </tr>
    <tr>
      <th>37</th>
      <td>287519.0</td>
      <td>1838086.0</td>
      <td>423747.0</td>
      <td>1953842.0</td>
    </tr>
    <tr>
      <th>38</th>
      <td>468225.0</td>
      <td>2243430.0</td>
      <td>593310.0</td>
      <td>2348995.0</td>
    </tr>
    <tr>
      <th>39</th>
      <td>705258.0</td>
      <td>2028059.0</td>
      <td>789713.0</td>
      <td>2142950.0</td>
    </tr>
    <tr>
      <th>40</th>
      <td>658752.0</td>
      <td>1972624.0</td>
      <td>769100.0</td>
      <td>2048140.0</td>
    </tr>
    <tr>
      <th>41</th>
      <td>230711.0</td>
      <td>2214005.0</td>
      <td>353995.0</td>
      <td>2321981.0</td>
    </tr>
    <tr>
      <th>42</th>
      <td>538649.0</td>
      <td>2276010.0</td>
      <td>659129.0</td>
      <td>2371784.0</td>
    </tr>
    <tr>
      <th>43</th>
      <td>492252.0</td>
      <td>1911800.0</td>
      <td>589888.0</td>
      <td>2005212.0</td>
    </tr>
    <tr>
      <th>44</th>
      <td>401927.0</td>
      <td>1888135.0</td>
      <td>499975.0</td>
      <td>1975953.0</td>
    </tr>
    <tr>
      <th>45</th>
      <td>651208.0</td>
      <td>1902123.0</td>
      <td>732320.0</td>
      <td>1997767.0</td>
    </tr>
    <tr>
      <th>46</th>
      <td>321020.0</td>
      <td>2223897.0</td>
      <td>441890.0</td>
      <td>2318375.0</td>
    </tr>
    <tr>
      <th>47</th>
      <td>290741.0</td>
      <td>2390737.0</td>
      <td>373680.0</td>
      <td>2533863.0</td>
    </tr>
    <tr>
      <th>48</th>
      <td>678219.0</td>
      <td>2391754.0</td>
      <td>797839.0</td>
      <td>2491197.0</td>
    </tr>
    <tr>
      <th>49</th>
      <td>769392.0</td>
      <td>2290410.0</td>
      <td>865605.0</td>
      <td>2413138.0</td>
    </tr>
    <tr>
      <th>50</th>
      <td>332335.0</td>
      <td>2308035.0</td>
      <td>423374.0</td>
      <td>2399712.0</td>
    </tr>
    <tr>
      <th>51</th>
      <td>824020.0</td>
      <td>2378553.0</td>
      <td>953547.0</td>
      <td>2512709.0</td>
    </tr>
    <tr>
      <th>52</th>
      <td>787497.0</td>
      <td>2383743.0</td>
      <td>857296.0</td>
      <td>2517642.0</td>
    </tr>
    <tr>
      <th>53</th>
      <td>148290.0</td>
      <td>2267645.0</td>
      <td>272800.0</td>
      <td>2370649.0</td>
    </tr>
    <tr>
      <th>54</th>
      <td>857837.0</td>
      <td>2402961.0</td>
      <td>987605.0</td>
      <td>2508696.0</td>
    </tr>
    <tr>
      <th>55</th>
      <td>638290.0</td>
      <td>2184105.0</td>
      <td>743520.0</td>
      <td>2287762.0</td>
    </tr>
    <tr>
      <th>56</th>
      <td>581084.0</td>
      <td>2554112.0</td>
      <td>735799.0</td>
      <td>2677441.0</td>
    </tr>
    <tr>
      <th>57</th>
      <td>553200.0</td>
      <td>2451453.0</td>
      <td>660220.0</td>
      <td>2529648.0</td>
    </tr>
    <tr>
      <th>58</th>
      <td>363740.0</td>
      <td>2354620.0</td>
      <td>499340.0</td>
      <td>2443388.0</td>
    </tr>
    <tr>
      <th>59</th>
      <td>544398.0</td>
      <td>2558462.0</td>
      <td>660799.0</td>
      <td>2668207.0</td>
    </tr>
    <tr>
      <th>60</th>
      <td>604000.0</td>
      <td>2032072.0</td>
      <td>728930.0</td>
      <td>2139740.0</td>
    </tr>
    <tr>
      <th>61</th>
      <td>265360.0</td>
      <td>1757230.0</td>
      <td>412520.0</td>
      <td>1847811.0</td>
    </tr>
    <tr>
      <th>62</th>
      <td>382108.0</td>
      <td>1743459.0</td>
      <td>461744.0</td>
      <td>1848393.0</td>
    </tr>
    <tr>
      <th>63</th>
      <td>549532.0</td>
      <td>1703258.0</td>
      <td>669196.0</td>
      <td>1768513.0</td>
    </tr>
    <tr>
      <th>64</th>
      <td>937463.0</td>
      <td>2359888.0</td>
      <td>1031401.0</td>
      <td>2465672.0</td>
    </tr>
    <tr>
      <th>65</th>
      <td>937334.0</td>
      <td>2280516.0</td>
      <td>994987.0</td>
      <td>2379232.0</td>
    </tr>
    <tr>
      <th>66</th>
      <td>747910.0</td>
      <td>2053380.0</td>
      <td>819740.0</td>
      <td>2147622.0</td>
    </tr>
    <tr>
      <th>67</th>
      <td>828336.0</td>
      <td>2255412.0</td>
      <td>937270.0</td>
      <td>2342925.0</td>
    </tr>
    <tr>
      <th>68</th>
      <td>698284.0</td>
      <td>2130343.0</td>
      <td>838497.0</td>
      <td>2241205.0</td>
    </tr>
    <tr>
      <th>69</th>
      <td>391570.0</td>
      <td>2287275.0</td>
      <td>494315.0</td>
      <td>2389324.0</td>
    </tr>
    <tr>
      <th>70</th>
      <td>585997.0</td>
      <td>2410080.0</td>
      <td>620470.0</td>
      <td>2446056.0</td>
    </tr>
    <tr>
      <th>71</th>
      <td>435461.0</td>
      <td>2473524.0</td>
      <td>560272.0</td>
      <td>2564284.0</td>
    </tr>
    <tr>
      <th>72</th>
      <td>604141.0</td>
      <td>2346870.0</td>
      <td>689984.0</td>
      <td>2457985.0</td>
    </tr>
    <tr>
      <th>73</th>
      <td>534961.0</td>
      <td>2365196.0</td>
      <td>618869.0</td>
      <td>2471252.0</td>
    </tr>
    <tr>
      <th>74</th>
      <td>353635.0</td>
      <td>2110650.0</td>
      <td>436452.0</td>
      <td>2237360.0</td>
    </tr>
    <tr>
      <th>75</th>
      <td>531390.0</td>
      <td>2508339.0</td>
      <td>662211.0</td>
      <td>2596807.0</td>
    </tr>
    <tr>
      <th>76</th>
      <td>535618.0</td>
      <td>1820051.0</td>
      <td>648303.0</td>
      <td>1911053.0</td>
    </tr>
    <tr>
      <th>77</th>
      <td>471821.0</td>
      <td>1863598.0</td>
      <td>572816.0</td>
      <td>1933271.0</td>
    </tr>
    <tr>
      <th>78</th>
      <td>868544.0</td>
      <td>1783206.0</td>
      <td>972280.0</td>
      <td>1876406.0</td>
    </tr>
    <tr>
      <th>79</th>
      <td>784690.0</td>
      <td>1856067.0</td>
      <td>875879.0</td>
      <td>1940082.0</td>
    </tr>
    <tr>
      <th>80</th>
      <td>238257.0</td>
      <td>2147245.0</td>
      <td>378970.0</td>
      <td>2237880.0</td>
    </tr>
    <tr>
      <th>81</th>
      <td>414673.0</td>
      <td>2118365.0</td>
      <td>513665.0</td>
      <td>2244365.0</td>
    </tr>
    <tr>
      <th>82</th>
      <td>467110.0</td>
      <td>2049172.0</td>
      <td>566733.0</td>
      <td>2156205.0</td>
    </tr>
    <tr>
      <th>83</th>
      <td>826426.0</td>
      <td>2322215.0</td>
      <td>960485.0</td>
      <td>2401303.0</td>
    </tr>
    <tr>
      <th>84</th>
      <td>638420.0</td>
      <td>2258284.0</td>
      <td>750100.0</td>
      <td>2378276.0</td>
    </tr>
  </tbody>
</table>
</div>



Или охват всего `GeoDataFrame`


```python
guerry.total_bounds
```




    array([  47680., 1703258., 1031401., 2677441.])



Подход работы с данными в `GeoDataFrame` позволяет, например, выбирать только определенные колонки из набора данных.


```python
print(guerry.columns.tolist())
```

    ['dept', 'Region', 'Dprtmnt', 'Crm_prs', 'Crm_prp', 'Litercy', 'Donatns', 'Infants', 'Suicids', 'MainCty', 'Wealth', 'Commerc', 'Clergy', 'Crm_prn', 'Infntcd', 'Dntn_cl', 'Lottery', 'Desertn', 'Instrct', 'Prsttts', 'Distanc', 'Area', 'Pop1831', 'geometry']



```python
guerry[["Region","Dprtmnt", "Litercy", "MainCty","geometry"]]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Region</th>
      <th>Dprtmnt</th>
      <th>Litercy</th>
      <th>MainCty</th>
      <th>geometry</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>E</td>
      <td>Ain</td>
      <td>37.0</td>
      <td>2.0</td>
      <td>POLYGON ((801150 2092615, 800669 2093190, 8006...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>N</td>
      <td>Aisne</td>
      <td>51.0</td>
      <td>2.0</td>
      <td>POLYGON ((729326 2521619, 729320 2521230, 7292...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>C</td>
      <td>Allier</td>
      <td>13.0</td>
      <td>2.0</td>
      <td>POLYGON ((710830 2137350, 711746 2136617, 7124...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>E</td>
      <td>Basses-Alpes</td>
      <td>46.0</td>
      <td>1.0</td>
      <td>POLYGON ((882701 1920024, 882408 1920733, 8817...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>E</td>
      <td>Hautes-Alpes</td>
      <td>69.0</td>
      <td>1.0</td>
      <td>POLYGON ((886504 1922890, 885733 1922978, 8854...</td>
    </tr>
    <tr>
      <th>5</th>
      <td>S</td>
      <td>Ardeche</td>
      <td>27.0</td>
      <td>1.0</td>
      <td>POLYGON ((747008 1925789, 746630 1925762, 7457...</td>
    </tr>
    <tr>
      <th>6</th>
      <td>N</td>
      <td>Ardennes</td>
      <td>67.0</td>
      <td>2.0</td>
      <td>POLYGON ((818893 2514767, 818614 2514515, 8179...</td>
    </tr>
    <tr>
      <th>7</th>
      <td>S</td>
      <td>Ariege</td>
      <td>18.0</td>
      <td>1.0</td>
      <td>POLYGON ((509103 1747787, 508820 1747513, 5081...</td>
    </tr>
    <tr>
      <th>8</th>
      <td>E</td>
      <td>Aube</td>
      <td>59.0</td>
      <td>2.0</td>
      <td>POLYGON ((775400 2345600, 775068 2345397, 7735...</td>
    </tr>
    <tr>
      <th>9</th>
      <td>S</td>
      <td>Aude</td>
      <td>34.0</td>
      <td>2.0</td>
      <td>POLYGON ((626230 1810121, 626269 1810496, 6274...</td>
    </tr>
    <tr>
      <th>10</th>
      <td>S</td>
      <td>Aveyron</td>
      <td>31.0</td>
      <td>2.0</td>
      <td>POLYGON ((642972 1978185, 643791 1976549, 6444...</td>
    </tr>
    <tr>
      <th>11</th>
      <td>S</td>
      <td>Bouches-du-Rhone</td>
      <td>38.0</td>
      <td>3.0</td>
      <td>POLYGON ((824692 1865875, 825615 1865409, 8259...</td>
    </tr>
    <tr>
      <th>12</th>
      <td>N</td>
      <td>Calvados</td>
      <td>52.0</td>
      <td>2.0</td>
      <td>POLYGON ((345476 2429914, 345299 2430235, 3436...</td>
    </tr>
    <tr>
      <th>13</th>
      <td>C</td>
      <td>Cantal</td>
      <td>31.0</td>
      <td>2.0</td>
      <td>POLYGON ((591653 2017934, 591727 2018244, 5918...</td>
    </tr>
    <tr>
      <th>14</th>
      <td>W</td>
      <td>Charente</td>
      <td>36.0</td>
      <td>2.0</td>
      <td>POLYGON ((456425 2120055, 456229 2120382, 4559...</td>
    </tr>
    <tr>
      <th>15</th>
      <td>W</td>
      <td>Charente-Inferieure</td>
      <td>39.0</td>
      <td>2.0</td>
      <td>MULTIPOLYGON (((328075 2118055, 327916 2118168...</td>
    </tr>
    <tr>
      <th>16</th>
      <td>C</td>
      <td>Cher</td>
      <td>13.0</td>
      <td>2.0</td>
      <td>POLYGON ((572720 2252955, 574278 2251834, 5753...</td>
    </tr>
    <tr>
      <th>17</th>
      <td>C</td>
      <td>Correze</td>
      <td>12.0</td>
      <td>2.0</td>
      <td>POLYGON ((608225 2042680, 608101 2042880, 6079...</td>
    </tr>
    <tr>
      <th>18</th>
      <td>E</td>
      <td>Cote-d'Or</td>
      <td>60.0</td>
      <td>2.0</td>
      <td>MULTIPOLYGON (((738935 2236890, 738359 2237343...</td>
    </tr>
    <tr>
      <th>19</th>
      <td>W</td>
      <td>Cotes-du-Nord</td>
      <td>16.0</td>
      <td>2.0</td>
      <td>MULTIPOLYGON (((208165 2439753, 208131 2439949...</td>
    </tr>
    <tr>
      <th>20</th>
      <td>C</td>
      <td>Creuse</td>
      <td>23.0</td>
      <td>1.0</td>
      <td>POLYGON ((540175 2111095, 538135 2111105, 5380...</td>
    </tr>
    <tr>
      <th>21</th>
      <td>W</td>
      <td>Dordogne</td>
      <td>18.0</td>
      <td>2.0</td>
      <td>POLYGON ((527718 1988833, 528808 1988071, 5291...</td>
    </tr>
    <tr>
      <th>22</th>
      <td>E</td>
      <td>Doubs</td>
      <td>73.0</td>
      <td>2.0</td>
      <td>POLYGON ((886630 2188665, 886948 2188898, 8879...</td>
    </tr>
    <tr>
      <th>23</th>
      <td>E</td>
      <td>Drome</td>
      <td>42.0</td>
      <td>2.0</td>
      <td>POLYGON ((830803 2010472, 831288 2010361, 8315...</td>
    </tr>
    <tr>
      <th>24</th>
      <td>N</td>
      <td>Eure</td>
      <td>51.0</td>
      <td>2.0</td>
      <td>POLYGON ((515046 2482676, 515755 2483384, 5160...</td>
    </tr>
    <tr>
      <th>25</th>
      <td>C</td>
      <td>Eure-et-Loir</td>
      <td>54.0</td>
      <td>2.0</td>
      <td>POLYGON ((562860 2342515, 562499 2342577, 5602...</td>
    </tr>
    <tr>
      <th>26</th>
      <td>W</td>
      <td>Finistere</td>
      <td>15.0</td>
      <td>2.0</td>
      <td>MULTIPOLYGON (((134794 2434061, 134532 2434541...</td>
    </tr>
    <tr>
      <th>27</th>
      <td>S</td>
      <td>Gard</td>
      <td>40.0</td>
      <td>2.0</td>
      <td>POLYGON ((719592 1880745, 719924 1881419, 7194...</td>
    </tr>
    <tr>
      <th>28</th>
      <td>S</td>
      <td>Haute-Garonne</td>
      <td>31.0</td>
      <td>3.0</td>
      <td>POLYGON ((491745 1820323, 491926 1820668, 4914...</td>
    </tr>
    <tr>
      <th>29</th>
      <td>S</td>
      <td>Gers</td>
      <td>38.0</td>
      <td>2.0</td>
      <td>POLYGON ((447673 1816738, 447362 1816893, 4463...</td>
    </tr>
    <tr>
      <th>30</th>
      <td>W</td>
      <td>Gironde</td>
      <td>40.0</td>
      <td>3.0</td>
      <td>MULTIPOLYGON (((332874 1966651, 332777 1966980...</td>
    </tr>
    <tr>
      <th>31</th>
      <td>S</td>
      <td>Herault</td>
      <td>45.0</td>
      <td>2.0</td>
      <td>POLYGON ((739523 1864067, 740853 1864454, 7414...</td>
    </tr>
    <tr>
      <th>32</th>
      <td>W</td>
      <td>Ille-et-Vilaine</td>
      <td>25.0</td>
      <td>2.0</td>
      <td>MULTIPOLYGON (((271910 2322460, 272047 2322795...</td>
    </tr>
    <tr>
      <th>33</th>
      <td>C</td>
      <td>Indre</td>
      <td>17.0</td>
      <td>2.0</td>
      <td>POLYGON ((573430 2159520, 573109 2159583, 5726...</td>
    </tr>
    <tr>
      <th>34</th>
      <td>C</td>
      <td>Indre-et-Loire</td>
      <td>27.0</td>
      <td>2.0</td>
      <td>POLYGON ((505590 2270755, 507478 2268385, 5076...</td>
    </tr>
    <tr>
      <th>35</th>
      <td>E</td>
      <td>Isere</td>
      <td>29.0</td>
      <td>2.0</td>
      <td>POLYGON ((839825 2094355, 840895 2093318, 8411...</td>
    </tr>
    <tr>
      <th>36</th>
      <td>E</td>
      <td>Jura</td>
      <td>73.0</td>
      <td>2.0</td>
      <td>MULTIPOLYGON (((836965 2209730, 836855 2209785...</td>
    </tr>
    <tr>
      <th>37</th>
      <td>W</td>
      <td>Landes</td>
      <td>28.0</td>
      <td>1.0</td>
      <td>POLYGON ((311864 1932711, 314132 1946872, 3141...</td>
    </tr>
    <tr>
      <th>38</th>
      <td>C</td>
      <td>Loir-et-Cher</td>
      <td>27.0</td>
      <td>2.0</td>
      <td>POLYGON ((519655 2330465, 520005 2329830, 5225...</td>
    </tr>
    <tr>
      <th>39</th>
      <td>C</td>
      <td>Loire</td>
      <td>29.0</td>
      <td>2.0</td>
      <td>POLYGON ((732285 2132610, 732782 2133196, 7330...</td>
    </tr>
    <tr>
      <th>40</th>
      <td>C</td>
      <td>Haute-Loire</td>
      <td>21.0</td>
      <td>2.0</td>
      <td>POLYGON ((742975 2044820, 744433 2045165, 7460...</td>
    </tr>
    <tr>
      <th>41</th>
      <td>W</td>
      <td>Loire-Inferieure</td>
      <td>24.0</td>
      <td>3.0</td>
      <td>POLYGON ((268705 2263645, 268976 2263891, 2710...</td>
    </tr>
    <tr>
      <th>42</th>
      <td>C</td>
      <td>Loiret</td>
      <td>42.0</td>
      <td>2.0</td>
      <td>POLYGON ((557890 2341355, 558382 2341921, 5598...</td>
    </tr>
    <tr>
      <th>43</th>
      <td>S</td>
      <td>Lot</td>
      <td>24.0</td>
      <td>2.0</td>
      <td>POLYGON ((503966 1958060, 505528 1959658, 5058...</td>
    </tr>
    <tr>
      <th>44</th>
      <td>W</td>
      <td>Lot-et-Garonne</td>
      <td>31.0</td>
      <td>2.0</td>
      <td>POLYGON ((413714 1942691, 413362 1942587, 4128...</td>
    </tr>
    <tr>
      <th>45</th>
      <td>S</td>
      <td>Lozere</td>
      <td>27.0</td>
      <td>1.0</td>
      <td>POLYGON ((702442 1987131, 703082 1987282, 7033...</td>
    </tr>
    <tr>
      <th>46</th>
      <td>W</td>
      <td>Maine-et-Loire</td>
      <td>23.0</td>
      <td>2.0</td>
      <td>POLYGON ((409765 2298980, 409716 2297568, 4099...</td>
    </tr>
    <tr>
      <th>47</th>
      <td>N</td>
      <td>Manche</td>
      <td>43.0</td>
      <td>2.0</td>
      <td>MULTIPOLYGON (((316425 2410987, 316287 2411065...</td>
    </tr>
    <tr>
      <th>48</th>
      <td>N</td>
      <td>Marne</td>
      <td>63.0</td>
      <td>2.0</td>
      <td>POLYGON ((781920 2395187, 781562 2395133, 7809...</td>
    </tr>
    <tr>
      <th>49</th>
      <td>E</td>
      <td>Haute-Marne</td>
      <td>72.0</td>
      <td>1.0</td>
      <td>POLYGON ((776565 2346640, 776344 2346943, 7780...</td>
    </tr>
    <tr>
      <th>50</th>
      <td>W</td>
      <td>Mayenne</td>
      <td>19.0</td>
      <td>2.0</td>
      <td>POLYGON ((394355 2321180, 394249 2320876, 3943...</td>
    </tr>
    <tr>
      <th>51</th>
      <td>E</td>
      <td>Meurthe</td>
      <td>68.0</td>
      <td>2.0</td>
      <td>MULTIPOLYGON (((826186 2502671, 825892 2502926...</td>
    </tr>
    <tr>
      <th>52</th>
      <td>N</td>
      <td>Meuse</td>
      <td>74.0</td>
      <td>2.0</td>
      <td>POLYGON ((853530 2462643, 853898 2462654, 8542...</td>
    </tr>
    <tr>
      <th>53</th>
      <td>W</td>
      <td>Morbihan</td>
      <td>14.0</td>
      <td>2.0</td>
      <td>MULTIPOLYGON (((167530 2307010, 167140 2307457...</td>
    </tr>
    <tr>
      <th>54</th>
      <td>N</td>
      <td>Moselle</td>
      <td>57.0</td>
      <td>3.0</td>
      <td>POLYGON ((929062 2475639, 929093 2476415, 9280...</td>
    </tr>
    <tr>
      <th>55</th>
      <td>C</td>
      <td>Nievre</td>
      <td>20.0</td>
      <td>2.0</td>
      <td>POLYGON ((715920 2264185, 717135 2264065, 7172...</td>
    </tr>
    <tr>
      <th>56</th>
      <td>N</td>
      <td>Nord</td>
      <td>45.0</td>
      <td>3.0</td>
      <td>MULTIPOLYGON (((664166 2630647, 664342 2629299...</td>
    </tr>
    <tr>
      <th>57</th>
      <td>N</td>
      <td>Oise</td>
      <td>54.0</td>
      <td>2.0</td>
      <td>MULTIPOLYGON (((647667 2468296, 647542 2468371...</td>
    </tr>
    <tr>
      <th>58</th>
      <td>N</td>
      <td>Orne</td>
      <td>45.0</td>
      <td>2.0</td>
      <td>POLYGON ((469173 2432434, 470681 2434059, 4709...</td>
    </tr>
    <tr>
      <th>59</th>
      <td>N</td>
      <td>Pas-de-Calais</td>
      <td>49.0</td>
      <td>2.0</td>
      <td>POLYGON ((629822 2560555, 629583 2560843, 6291...</td>
    </tr>
    <tr>
      <th>60</th>
      <td>C</td>
      <td>Puy-de-Dome</td>
      <td>19.0</td>
      <td>2.0</td>
      <td>POLYGON ((615585 2050805, 615649 2051154, 6162...</td>
    </tr>
    <tr>
      <th>61</th>
      <td>W</td>
      <td>Basses-Pyrenees</td>
      <td>47.0</td>
      <td>2.0</td>
      <td>POLYGON ((386095 1774604, 386085 1774237, 3855...</td>
    </tr>
    <tr>
      <th>62</th>
      <td>S</td>
      <td>Hautes-Pyrenees</td>
      <td>53.0</td>
      <td>2.0</td>
      <td>MULTIPOLYGON (((406987 1826038, 405019 1826121...</td>
    </tr>
    <tr>
      <th>63</th>
      <td>S</td>
      <td>Pyrenees-Orientales</td>
      <td>31.0</td>
      <td>2.0</td>
      <td>POLYGON ((658127 1733192, 658228 1732843, 6582...</td>
    </tr>
    <tr>
      <th>64</th>
      <td>E</td>
      <td>Bas-Rhin</td>
      <td>62.0</td>
      <td>3.0</td>
      <td>POLYGON ((946663 2460717, 946292 2461188, 9461...</td>
    </tr>
    <tr>
      <th>65</th>
      <td>E</td>
      <td>Haut-Rhin</td>
      <td>71.0</td>
      <td>2.0</td>
      <td>POLYGON ((989865 2319005, 990659 2316949, 9900...</td>
    </tr>
    <tr>
      <th>66</th>
      <td>E</td>
      <td>Rhone</td>
      <td>45.0</td>
      <td>3.0</td>
      <td>POLYGON ((752410 2115380, 752067 2115294, 7510...</td>
    </tr>
    <tr>
      <th>67</th>
      <td>E</td>
      <td>Haute-Saone</td>
      <td>59.0</td>
      <td>1.0</td>
      <td>POLYGON ((933555 2291420, 933269 2291556, 9326...</td>
    </tr>
    <tr>
      <th>68</th>
      <td>E</td>
      <td>Saone-et-Loire</td>
      <td>32.0</td>
      <td>2.0</td>
      <td>POLYGON ((834930 2207585, 834681 2207740, 8344...</td>
    </tr>
    <tr>
      <th>69</th>
      <td>C</td>
      <td>Sarthe</td>
      <td>30.0</td>
      <td>2.0</td>
      <td>POLYGON ((470543 2362046, 471980 2361813, 4726...</td>
    </tr>
    <tr>
      <th>70</th>
      <td>N</td>
      <td>Seine</td>
      <td>71.0</td>
      <td>3.0</td>
      <td>POLYGON ((615302 2411120, 615000 2411180, 6143...</td>
    </tr>
    <tr>
      <th>71</th>
      <td>N</td>
      <td>Seine-Inferieure</td>
      <td>43.0</td>
      <td>3.0</td>
      <td>POLYGON ((438965 2512493, 440124 2514448, 4402...</td>
    </tr>
    <tr>
      <th>72</th>
      <td>N</td>
      <td>Seine-et-Marne</td>
      <td>54.0</td>
      <td>2.0</td>
      <td>POLYGON ((675580 2375994, 675218 2376008, 6748...</td>
    </tr>
    <tr>
      <th>73</th>
      <td>N</td>
      <td>Seine-et-Oise</td>
      <td>56.0</td>
      <td>2.0</td>
      <td>POLYGON ((546799 2453567, 547588 2454258, 5478...</td>
    </tr>
    <tr>
      <th>74</th>
      <td>W</td>
      <td>Deux-Sevres</td>
      <td>41.0</td>
      <td>2.0</td>
      <td>POLYGON ((419808 2218480, 420449 2218054, 4209...</td>
    </tr>
    <tr>
      <th>75</th>
      <td>N</td>
      <td>Somme</td>
      <td>44.0</td>
      <td>2.0</td>
      <td>POLYGON ((543667 2592806, 544247 2596216, 5451...</td>
    </tr>
    <tr>
      <th>76</th>
      <td>S</td>
      <td>Tarn</td>
      <td>20.0</td>
      <td>2.0</td>
      <td>POLYGON ((548083 1858875, 547740 1858741, 5469...</td>
    </tr>
    <tr>
      <th>77</th>
      <td>S</td>
      <td>Tarn-et-Garonne</td>
      <td>25.0</td>
      <td>2.0</td>
      <td>POLYGON ((572261 1905414, 571717 1905736, 5705...</td>
    </tr>
    <tr>
      <th>78</th>
      <td>S</td>
      <td>Var</td>
      <td>23.0</td>
      <td>2.0</td>
      <td>MULTIPOLYGON (((937679 1788572, 937646 1788379...</td>
    </tr>
    <tr>
      <th>79</th>
      <td>S</td>
      <td>Vaucluse</td>
      <td>37.0</td>
      <td>2.0</td>
      <td>MULTIPOLYGON (((811669 1924852, 811384 1925100...</td>
    </tr>
    <tr>
      <th>80</th>
      <td>W</td>
      <td>Vendee</td>
      <td>28.0</td>
      <td>1.0</td>
      <td>MULTIPOLYGON (((243055 2197885, 243019 2198089...</td>
    </tr>
    <tr>
      <th>81</th>
      <td>W</td>
      <td>Vienne</td>
      <td>25.0</td>
      <td>2.0</td>
      <td>POLYGON ((450395 2119945, 450065 2120124, 4494...</td>
    </tr>
    <tr>
      <th>82</th>
      <td>C</td>
      <td>Haute-Vienne</td>
      <td>13.0</td>
      <td>2.0</td>
      <td>POLYGON ((515230 2049895, 514990 2049594, 5143...</td>
    </tr>
    <tr>
      <th>83</th>
      <td>E</td>
      <td>Vosges</td>
      <td>62.0</td>
      <td>2.0</td>
      <td>POLYGON ((951144 2383215, 953082 2382491, 9534...</td>
    </tr>
    <tr>
      <th>84</th>
      <td>C</td>
      <td>Yonne</td>
      <td>47.0</td>
      <td>2.0</td>
      <td>POLYGON ((650260 2358330, 651712 2361305, 6528...</td>
    </tr>
  </tbody>
</table>
</div>



При необходимости мы можем отфильтровать объекты нашего `GeoDataFrame` по значению атрибутов.


```python
region_literate = guerry["Litercy"] > 30

region_literate
```




    0      True
    1      True
    2     False
    3      True
    4      True
    5     False
    6      True
    7     False
    8      True
    9      True
    10     True
    11     True
    12     True
    13     True
    14     True
    15     True
    16    False
    17    False
    18     True
    19    False
    20    False
    21    False
    22     True
    23     True
    24     True
    25     True
    26    False
    27     True
    28     True
    29     True
    30     True
    31     True
    32    False
    33    False
    34    False
    35    False
    36     True
    37    False
    38    False
    39    False
    40    False
    41    False
    42     True
    43    False
    44     True
    45    False
    46    False
    47     True
    48     True
    49     True
    50    False
    51     True
    52     True
    53    False
    54     True
    55    False
    56     True
    57     True
    58     True
    59     True
    60    False
    61     True
    62     True
    63     True
    64     True
    65     True
    66     True
    67     True
    68     True
    69    False
    70     True
    71     True
    72     True
    73     True
    74     True
    75     True
    76    False
    77    False
    78    False
    79     True
    80    False
    81    False
    82    False
    83     True
    84     True
    Name: Litercy, dtype: bool




```python
guerry_literate = guerry[region_literate]

guerry_literate
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>dept</th>
      <th>Region</th>
      <th>Dprtmnt</th>
      <th>Crm_prs</th>
      <th>Crm_prp</th>
      <th>Litercy</th>
      <th>Donatns</th>
      <th>Infants</th>
      <th>Suicids</th>
      <th>MainCty</th>
      <th>...</th>
      <th>Infntcd</th>
      <th>Dntn_cl</th>
      <th>Lottery</th>
      <th>Desertn</th>
      <th>Instrct</th>
      <th>Prsttts</th>
      <th>Distanc</th>
      <th>Area</th>
      <th>Pop1831</th>
      <th>geometry</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>S</td>
      <td>Ain</td>
      <td>28870.0</td>
      <td>15890.0</td>
      <td>37.0</td>
      <td>5098.0</td>
      <td>33120.0</td>
      <td>35039.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>60.0</td>
      <td>69.0</td>
      <td>41.0</td>
      <td>55.0</td>
      <td>46.0</td>
      <td>13.0</td>
      <td>218.372</td>
      <td>5762.0</td>
      <td>346.03</td>
      <td>POLYGON ((801150 2092615, 800669 2093190, 8006...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2.0</td>
      <td>S</td>
      <td>Aisne</td>
      <td>26226.0</td>
      <td>5521.0</td>
      <td>51.0</td>
      <td>8901.0</td>
      <td>14572.0</td>
      <td>12831.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>82.0</td>
      <td>36.0</td>
      <td>38.0</td>
      <td>82.0</td>
      <td>24.0</td>
      <td>327.0</td>
      <td>65.945</td>
      <td>7369.0</td>
      <td>513.00</td>
      <td>POLYGON ((729326 2521619, 729320 2521230, 7292...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.0</td>
      <td>S</td>
      <td>Basses-Alpes</td>
      <td>12935.0</td>
      <td>7289.0</td>
      <td>46.0</td>
      <td>2733.0</td>
      <td>23018.0</td>
      <td>14238.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>12.0</td>
      <td>37.0</td>
      <td>80.0</td>
      <td>32.0</td>
      <td>29.0</td>
      <td>2.0</td>
      <td>351.399</td>
      <td>6925.0</td>
      <td>155.90</td>
      <td>POLYGON ((882701 1920024, 882408 1920733, 8817...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>S</td>
      <td>Hautes-Alpes</td>
      <td>17488.0</td>
      <td>8174.0</td>
      <td>69.0</td>
      <td>6962.0</td>
      <td>23076.0</td>
      <td>16171.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>23.0</td>
      <td>64.0</td>
      <td>79.0</td>
      <td>35.0</td>
      <td>7.0</td>
      <td>1.0</td>
      <td>320.280</td>
      <td>5549.0</td>
      <td>129.10</td>
      <td>POLYGON ((886504 1922890, 885733 1922978, 8854...</td>
    </tr>
    <tr>
      <th>6</th>
      <td>8.0</td>
      <td>S</td>
      <td>Ardennes</td>
      <td>35203.0</td>
      <td>8847.0</td>
      <td>67.0</td>
      <td>6400.0</td>
      <td>16106.0</td>
      <td>26198.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>85.0</td>
      <td>49.0</td>
      <td>31.0</td>
      <td>62.0</td>
      <td>9.0</td>
      <td>83.0</td>
      <td>105.694</td>
      <td>5229.0</td>
      <td>289.62</td>
      <td>POLYGON ((818893 2514767, 818614 2514515, 8179...</td>
    </tr>
    <tr>
      <th>8</th>
      <td>10.0</td>
      <td>S</td>
      <td>Aube</td>
      <td>19602.0</td>
      <td>4086.0</td>
      <td>59.0</td>
      <td>3608.0</td>
      <td>18642.0</td>
      <td>10989.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>54.0</td>
      <td>9.0</td>
      <td>28.0</td>
      <td>86.0</td>
      <td>15.0</td>
      <td>207.0</td>
      <td>83.244</td>
      <td>6004.0</td>
      <td>246.36</td>
      <td>POLYGON ((775400 2345600, 775068 2345397, 7735...</td>
    </tr>
    <tr>
      <th>9</th>
      <td>11.0</td>
      <td>S</td>
      <td>Aude</td>
      <td>15647.0</td>
      <td>10431.0</td>
      <td>34.0</td>
      <td>2582.0</td>
      <td>20225.0</td>
      <td>66498.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>35.0</td>
      <td>27.0</td>
      <td>50.0</td>
      <td>63.0</td>
      <td>48.0</td>
      <td>1.0</td>
      <td>370.949</td>
      <td>6139.0</td>
      <td>270.13</td>
      <td>POLYGON ((626230 1810121, 626269 1810496, 6274...</td>
    </tr>
    <tr>
      <th>10</th>
      <td>12.0</td>
      <td>S</td>
      <td>Aveyron</td>
      <td>8236.0</td>
      <td>6731.0</td>
      <td>31.0</td>
      <td>3211.0</td>
      <td>21981.0</td>
      <td>116671.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>5.0</td>
      <td>23.0</td>
      <td>81.0</td>
      <td>10.0</td>
      <td>44.0</td>
      <td>4.0</td>
      <td>296.089</td>
      <td>8735.0</td>
      <td>359.06</td>
      <td>POLYGON ((642972 1978185, 643791 1976549, 6444...</td>
    </tr>
    <tr>
      <th>11</th>
      <td>13.0</td>
      <td>S</td>
      <td>Bouches-du-Rhone</td>
      <td>13409.0</td>
      <td>5291.0</td>
      <td>38.0</td>
      <td>2314.0</td>
      <td>9325.0</td>
      <td>8107.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>74.0</td>
      <td>55.0</td>
      <td>3.0</td>
      <td>23.0</td>
      <td>43.0</td>
      <td>25.0</td>
      <td>362.568</td>
      <td>5087.0</td>
      <td>359.47</td>
      <td>POLYGON ((824692 1865875, 825615 1865409, 8259...</td>
    </tr>
    <tr>
      <th>12</th>
      <td>14.0</td>
      <td>S</td>
      <td>Calvados</td>
      <td>17577.0</td>
      <td>4500.0</td>
      <td>52.0</td>
      <td>27830.0</td>
      <td>8983.0</td>
      <td>31807.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>56.0</td>
      <td>11.0</td>
      <td>13.0</td>
      <td>12.0</td>
      <td>22.0</td>
      <td>194.0</td>
      <td>117.487</td>
      <td>5548.0</td>
      <td>494.70</td>
      <td>POLYGON ((345476 2429914, 345299 2430235, 3436...</td>
    </tr>
    <tr>
      <th>13</th>
      <td>15.0</td>
      <td>S</td>
      <td>Cantal</td>
      <td>18070.0</td>
      <td>11645.0</td>
      <td>31.0</td>
      <td>4093.0</td>
      <td>15335.0</td>
      <td>87338.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>83.0</td>
      <td>66.0</td>
      <td>82.0</td>
      <td>1.0</td>
      <td>51.0</td>
      <td>20.0</td>
      <td>245.849</td>
      <td>5726.0</td>
      <td>258.59</td>
      <td>POLYGON ((591653 2017934, 591727 2018244, 5918...</td>
    </tr>
    <tr>
      <th>14</th>
      <td>16.0</td>
      <td>S</td>
      <td>Charente</td>
      <td>24964.0</td>
      <td>13018.0</td>
      <td>36.0</td>
      <td>13602.0</td>
      <td>19454.0</td>
      <td>25720.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>7.0</td>
      <td>81.0</td>
      <td>60.0</td>
      <td>61.0</td>
      <td>47.0</td>
      <td>8.0</td>
      <td>224.339</td>
      <td>5956.0</td>
      <td>362.53</td>
      <td>POLYGON ((456425 2120055, 456229 2120382, 4559...</td>
    </tr>
    <tr>
      <th>15</th>
      <td>17.0</td>
      <td>S</td>
      <td>Charente-Inferieure</td>
      <td>18712.0</td>
      <td>5357.0</td>
      <td>39.0</td>
      <td>13254.0</td>
      <td>23999.0</td>
      <td>16798.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>38.0</td>
      <td>72.0</td>
      <td>35.0</td>
      <td>74.0</td>
      <td>42.0</td>
      <td>27.0</td>
      <td>238.538</td>
      <td>6864.0</td>
      <td>445.25</td>
      <td>MULTIPOLYGON (((328075 2118055, 327916 2118168...</td>
    </tr>
    <tr>
      <th>18</th>
      <td>21.0</td>
      <td>S</td>
      <td>Cote-d'Or</td>
      <td>32256.0</td>
      <td>9159.0</td>
      <td>60.0</td>
      <td>2540.0</td>
      <td>15599.0</td>
      <td>16128.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>27.0</td>
      <td>18.0</td>
      <td>33.0</td>
      <td>78.0</td>
      <td>13.0</td>
      <td>206.0</td>
      <td>136.109</td>
      <td>8763.0</td>
      <td>375.88</td>
      <td>MULTIPOLYGON (((738935 2236890, 738359 2237343...</td>
    </tr>
    <tr>
      <th>22</th>
      <td>25.0</td>
      <td>S</td>
      <td>Doubs</td>
      <td>11560.0</td>
      <td>5914.0</td>
      <td>73.0</td>
      <td>3436.0</td>
      <td>12512.0</td>
      <td>40690.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>25.0</td>
      <td>6.0</td>
      <td>18.0</td>
      <td>73.0</td>
      <td>2.0</td>
      <td>65.0</td>
      <td>202.065</td>
      <td>5234.0</td>
      <td>265.54</td>
      <td>POLYGON ((886630 2188665, 886948 2188898, 8879...</td>
    </tr>
    <tr>
      <th>23</th>
      <td>26.0</td>
      <td>S</td>
      <td>Drome</td>
      <td>13396.0</td>
      <td>7759.0</td>
      <td>42.0</td>
      <td>2829.0</td>
      <td>16348.0</td>
      <td>23816.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>13.0</td>
      <td>62.0</td>
      <td>54.0</td>
      <td>46.0</td>
      <td>38.0</td>
      <td>8.0</td>
      <td>295.543</td>
      <td>6530.0</td>
      <td>299.56</td>
      <td>POLYGON ((830803 2010472, 831288 2010361, 8315...</td>
    </tr>
    <tr>
      <th>24</th>
      <td>27.0</td>
      <td>S</td>
      <td>Eure</td>
      <td>14795.0</td>
      <td>4774.0</td>
      <td>51.0</td>
      <td>11712.0</td>
      <td>16039.0</td>
      <td>13493.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>45.0</td>
      <td>45.0</td>
      <td>47.0</td>
      <td>27.0</td>
      <td>23.0</td>
      <td>179.0</td>
      <td>61.863</td>
      <td>6040.0</td>
      <td>424.25</td>
      <td>POLYGON ((515046 2482676, 515755 2483384, 5160...</td>
    </tr>
    <tr>
      <th>25</th>
      <td>28.0</td>
      <td>S</td>
      <td>Eure-et-Loir</td>
      <td>21368.0</td>
      <td>4016.0</td>
      <td>54.0</td>
      <td>4553.0</td>
      <td>14475.0</td>
      <td>15015.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>62.0</td>
      <td>14.0</td>
      <td>48.0</td>
      <td>72.0</td>
      <td>18.0</td>
      <td>180.0</td>
      <td>54.558</td>
      <td>5880.0</td>
      <td>278.82</td>
      <td>POLYGON ((562860 2342515, 562499 2342577, 5602...</td>
    </tr>
    <tr>
      <th>27</th>
      <td>30.0</td>
      <td>S</td>
      <td>Gard</td>
      <td>13115.0</td>
      <td>7990.0</td>
      <td>40.0</td>
      <td>3048.0</td>
      <td>28726.0</td>
      <td>18292.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>39.0</td>
      <td>59.0</td>
      <td>20.0</td>
      <td>40.0</td>
      <td>40.0</td>
      <td>5.0</td>
      <td>323.004</td>
      <td>5853.0</td>
      <td>357.38</td>
      <td>POLYGON ((719592 1880745, 719924 1881419, 7194...</td>
    </tr>
    <tr>
      <th>28</th>
      <td>31.0</td>
      <td>S</td>
      <td>Haute-Garonne</td>
      <td>18642.0</td>
      <td>7204.0</td>
      <td>31.0</td>
      <td>2286.0</td>
      <td>15378.0</td>
      <td>56140.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>59.0</td>
      <td>13.0</td>
      <td>25.0</td>
      <td>15.0</td>
      <td>33.0</td>
      <td>8.0</td>
      <td>361.668</td>
      <td>6257.0</td>
      <td>427.86</td>
      <td>POLYGON ((491745 1820323, 491926 1820668, 4914...</td>
    </tr>
    <tr>
      <th>29</th>
      <td>32.0</td>
      <td>S</td>
      <td>Gers</td>
      <td>18642.0</td>
      <td>10486.0</td>
      <td>38.0</td>
      <td>2848.0</td>
      <td>15250.0</td>
      <td>61510.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>13.0</td>
      <td>32.0</td>
      <td>74.0</td>
      <td>30.0</td>
      <td>44.0</td>
      <td>1.0</td>
      <td>343.569</td>
      <td>6309.0</td>
      <td>312.16</td>
      <td>POLYGON ((447673 1816738, 447362 1816893, 4463...</td>
    </tr>
    <tr>
      <th>30</th>
      <td>33.0</td>
      <td>S</td>
      <td>Gironde</td>
      <td>24096.0</td>
      <td>7423.0</td>
      <td>40.0</td>
      <td>5076.0</td>
      <td>10676.0</td>
      <td>19220.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>80.0</td>
      <td>48.0</td>
      <td>4.0</td>
      <td>13.0</td>
      <td>41.0</td>
      <td>39.0</td>
      <td>291.624</td>
      <td>10000.0</td>
      <td>554.23</td>
      <td>MULTIPOLYGON (((332874 1966651, 332777 1966980...</td>
    </tr>
    <tr>
      <th>31</th>
      <td>34.0</td>
      <td>S</td>
      <td>Herault</td>
      <td>12814.0</td>
      <td>10954.0</td>
      <td>45.0</td>
      <td>1680.0</td>
      <td>21346.0</td>
      <td>30869.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>51.0</td>
      <td>28.0</td>
      <td>19.0</td>
      <td>43.0</td>
      <td>32.0</td>
      <td>9.0</td>
      <td>344.030</td>
      <td>6101.0</td>
      <td>346.30</td>
      <td>POLYGON ((739523 1864067, 740853 1864454, 7414...</td>
    </tr>
    <tr>
      <th>36</th>
      <td>39.0</td>
      <td>S</td>
      <td>Jura</td>
      <td>26221.0</td>
      <td>8059.0</td>
      <td>73.0</td>
      <td>3012.0</td>
      <td>20384.0</td>
      <td>34476.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>66.0</td>
      <td>43.0</td>
      <td>39.0</td>
      <td>71.0</td>
      <td>3.0</td>
      <td>32.0</td>
      <td>197.155</td>
      <td>4999.0</td>
      <td>312.50</td>
      <td>MULTIPOLYGON (((836965 2209730, 836855 2209785...</td>
    </tr>
    <tr>
      <th>42</th>
      <td>45.0</td>
      <td>S</td>
      <td>Loiret</td>
      <td>17722.0</td>
      <td>5042.0</td>
      <td>42.0</td>
      <td>4753.0</td>
      <td>9986.0</td>
      <td>11813.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>22.0</td>
      <td>16.0</td>
      <td>17.0</td>
      <td>60.0</td>
      <td>37.0</td>
      <td>256.0</td>
      <td>61.106</td>
      <td>6775.0</td>
      <td>305.28</td>
      <td>POLYGON ((557890 2341355, 558382 2341921, 5598...</td>
    </tr>
    <tr>
      <th>44</th>
      <td>47.0</td>
      <td>S</td>
      <td>Lot-et-Garonne</td>
      <td>22969.0</td>
      <td>8943.0</td>
      <td>31.0</td>
      <td>4432.0</td>
      <td>17681.0</td>
      <td>38501.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>32.0</td>
      <td>46.0</td>
      <td>52.0</td>
      <td>34.0</td>
      <td>50.0</td>
      <td>5.0</td>
      <td>302.345</td>
      <td>5361.0</td>
      <td>346.89</td>
      <td>POLYGON ((413714 1942691, 413362 1942587, 4128...</td>
    </tr>
    <tr>
      <th>47</th>
      <td>50.0</td>
      <td>S</td>
      <td>Manche</td>
      <td>31078.0</td>
      <td>7424.0</td>
      <td>43.0</td>
      <td>5179.0</td>
      <td>14281.0</td>
      <td>55564.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>70.0</td>
      <td>3.0</td>
      <td>59.0</td>
      <td>21.0</td>
      <td>36.0</td>
      <td>98.0</td>
      <td>157.187</td>
      <td>5938.0</td>
      <td>591.28</td>
      <td>MULTIPOLYGON (((316425 2410987, 316287 2411065...</td>
    </tr>
    <tr>
      <th>48</th>
      <td>51.0</td>
      <td>S</td>
      <td>Marne</td>
      <td>15602.0</td>
      <td>4950.0</td>
      <td>63.0</td>
      <td>3963.0</td>
      <td>11267.0</td>
      <td>8334.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>58.0</td>
      <td>39.0</td>
      <td>22.0</td>
      <td>81.0</td>
      <td>10.0</td>
      <td>262.0</td>
      <td>77.364</td>
      <td>6211.0</td>
      <td>337.08</td>
      <td>POLYGON ((781920 2395187, 781562 2395133, 7809...</td>
    </tr>
    <tr>
      <th>49</th>
      <td>52.0</td>
      <td>S</td>
      <td>Haute-Marne</td>
      <td>26231.0</td>
      <td>9539.0</td>
      <td>72.0</td>
      <td>4013.0</td>
      <td>17507.0</td>
      <td>19586.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>55.0</td>
      <td>4.0</td>
      <td>56.0</td>
      <td>65.0</td>
      <td>4.0</td>
      <td>138.0</td>
      <td>129.765</td>
      <td>8162.0</td>
      <td>249.83</td>
      <td>POLYGON ((776565 2346640, 776344 2346943, 7780...</td>
    </tr>
    <tr>
      <th>51</th>
      <td>54.0</td>
      <td>S</td>
      <td>Meurthe</td>
      <td>26674.0</td>
      <td>6831.0</td>
      <td>68.0</td>
      <td>3912.0</td>
      <td>12355.0</td>
      <td>15652.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>71.0</td>
      <td>1.0</td>
      <td>21.0</td>
      <td>70.0</td>
      <td>8.0</td>
      <td>154.0</td>
      <td>159.648</td>
      <td>5241.0</td>
      <td>415.57</td>
      <td>MULTIPOLYGON (((826186 2502671, 825892 2502926...</td>
    </tr>
    <tr>
      <th>52</th>
      <td>55.0</td>
      <td>S</td>
      <td>Meuse</td>
      <td>24507.0</td>
      <td>9190.0</td>
      <td>74.0</td>
      <td>4196.0</td>
      <td>17333.0</td>
      <td>13463.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>65.0</td>
      <td>12.0</td>
      <td>58.0</td>
      <td>59.0</td>
      <td>1.0</td>
      <td>131.0</td>
      <td>126.378</td>
      <td>6216.0</td>
      <td>314.59</td>
      <td>POLYGON ((853530 2462643, 853898 2462654, 8542...</td>
    </tr>
    <tr>
      <th>54</th>
      <td>57.0</td>
      <td>S</td>
      <td>Moselle</td>
      <td>12153.0</td>
      <td>4529.0</td>
      <td>57.0</td>
      <td>9515.0</td>
      <td>13877.0</td>
      <td>25572.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>9.0</td>
      <td>2.0</td>
      <td>16.0</td>
      <td>68.0</td>
      <td>16.0</td>
      <td>165.0</td>
      <td>180.462</td>
      <td>6216.0</td>
      <td>417.00</td>
      <td>POLYGON ((929062 2475639, 929093 2476415, 9280...</td>
    </tr>
    <tr>
      <th>56</th>
      <td>59.0</td>
      <td>S</td>
      <td>Nord</td>
      <td>26740.0</td>
      <td>6175.0</td>
      <td>45.0</td>
      <td>6092.0</td>
      <td>8926.0</td>
      <td>13851.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>81.0</td>
      <td>38.0</td>
      <td>7.0</td>
      <td>64.0</td>
      <td>30.0</td>
      <td>308.0</td>
      <td>106.335</td>
      <td>5743.0</td>
      <td>989.94</td>
      <td>MULTIPOLYGON (((664166 2630647, 664342 2629299...</td>
    </tr>
    <tr>
      <th>57</th>
      <td>60.0</td>
      <td>S</td>
      <td>Oise</td>
      <td>28180.0</td>
      <td>6659.0</td>
      <td>54.0</td>
      <td>5501.0</td>
      <td>18021.0</td>
      <td>5994.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>86.0</td>
      <td>50.0</td>
      <td>43.0</td>
      <td>57.0</td>
      <td>20.0</td>
      <td>337.0</td>
      <td>33.768</td>
      <td>5860.0</td>
      <td>397.73</td>
      <td>MULTIPOLYGON (((647667 2468296, 647542 2468371...</td>
    </tr>
    <tr>
      <th>58</th>
      <td>61.0</td>
      <td>S</td>
      <td>Orne</td>
      <td>28329.0</td>
      <td>8248.0</td>
      <td>45.0</td>
      <td>9242.0</td>
      <td>20852.0</td>
      <td>34069.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>50.0</td>
      <td>31.0</td>
      <td>57.0</td>
      <td>25.0</td>
      <td>33.0</td>
      <td>117.0</td>
      <td>97.554</td>
      <td>6103.0</td>
      <td>441.88</td>
      <td>POLYGON ((469173 2432434, 470681 2434059, 4709...</td>
    </tr>
    <tr>
      <th>59</th>
      <td>62.0</td>
      <td>S</td>
      <td>Pas-de-Calais</td>
      <td>23101.0</td>
      <td>4040.0</td>
      <td>49.0</td>
      <td>5740.0</td>
      <td>10575.0</td>
      <td>15400.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>79.0</td>
      <td>10.0</td>
      <td>27.0</td>
      <td>48.0</td>
      <td>26.0</td>
      <td>163.0</td>
      <td>104.400</td>
      <td>6671.0</td>
      <td>655.22</td>
      <td>POLYGON ((629822 2560555, 629583 2560843, 6291...</td>
    </tr>
    <tr>
      <th>61</th>
      <td>64.0</td>
      <td>S</td>
      <td>Basses-Pyrenees</td>
      <td>16722.0</td>
      <td>8533.0</td>
      <td>47.0</td>
      <td>3299.0</td>
      <td>12393.0</td>
      <td>65995.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>72.0</td>
      <td>60.0</td>
      <td>34.0</td>
      <td>7.0</td>
      <td>28.0</td>
      <td>12.0</td>
      <td>387.935</td>
      <td>7645.0</td>
      <td>428.40</td>
      <td>POLYGON ((386095 1774604, 386085 1774237, 3855...</td>
    </tr>
    <tr>
      <th>62</th>
      <td>65.0</td>
      <td>S</td>
      <td>Hautes-Pyrenees</td>
      <td>12223.0</td>
      <td>9797.0</td>
      <td>53.0</td>
      <td>6001.0</td>
      <td>12125.0</td>
      <td>148039.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>75.0</td>
      <td>71.0</td>
      <td>76.0</td>
      <td>20.0</td>
      <td>21.0</td>
      <td>5.0</td>
      <td>386.559</td>
      <td>4464.0</td>
      <td>233.03</td>
      <td>MULTIPOLYGON (((406987 1826038, 405019 1826121...</td>
    </tr>
    <tr>
      <th>63</th>
      <td>66.0</td>
      <td>S</td>
      <td>Pyrenees-Orientales</td>
      <td>6728.0</td>
      <td>7632.0</td>
      <td>31.0</td>
      <td>11644.0</td>
      <td>15167.0</td>
      <td>37843.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>84.0</td>
      <td>77.0</td>
      <td>11.0</td>
      <td>18.0</td>
      <td>52.0</td>
      <td>5.0</td>
      <td>403.445</td>
      <td>4116.0</td>
      <td>157.05</td>
      <td>POLYGON ((658127 1733192, 658228 1732843, 6582...</td>
    </tr>
    <tr>
      <th>64</th>
      <td>67.0</td>
      <td>S</td>
      <td>Bas-Rhin</td>
      <td>12309.0</td>
      <td>4920.0</td>
      <td>62.0</td>
      <td>14472.0</td>
      <td>14356.0</td>
      <td>18623.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>48.0</td>
      <td>51.0</td>
      <td>5.0</td>
      <td>53.0</td>
      <td>12.0</td>
      <td>101.0</td>
      <td>217.752</td>
      <td>4755.0</td>
      <td>540.21</td>
      <td>POLYGON ((946663 2460717, 946292 2461188, 9461...</td>
    </tr>
    <tr>
      <th>65</th>
      <td>68.0</td>
      <td>S</td>
      <td>Haut-Rhin</td>
      <td>7343.0</td>
      <td>4915.0</td>
      <td>71.0</td>
      <td>6001.0</td>
      <td>14783.0</td>
      <td>21233.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>53.0</td>
      <td>17.0</td>
      <td>10.0</td>
      <td>56.0</td>
      <td>5.0</td>
      <td>26.0</td>
      <td>217.971</td>
      <td>3525.0</td>
      <td>424.26</td>
      <td>POLYGON ((989865 2319005, 990659 2316949, 9900...</td>
    </tr>
    <tr>
      <th>66</th>
      <td>69.0</td>
      <td>S</td>
      <td>Rhone</td>
      <td>18793.0</td>
      <td>4504.0</td>
      <td>45.0</td>
      <td>1983.0</td>
      <td>3910.0</td>
      <td>17003.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>33.0</td>
      <td>21.0</td>
      <td>2.0</td>
      <td>14.0</td>
      <td>31.0</td>
      <td>104.0</td>
      <td>213.032</td>
      <td>3249.0</td>
      <td>434.43</td>
      <td>POLYGON ((752410 2115380, 752067 2115294, 7510...</td>
    </tr>
    <tr>
      <th>67</th>
      <td>70.0</td>
      <td>S</td>
      <td>Haute-Saone</td>
      <td>22339.0</td>
      <td>7770.0</td>
      <td>59.0</td>
      <td>11701.0</td>
      <td>11850.0</td>
      <td>39714.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>68.0</td>
      <td>57.0</td>
      <td>65.0</td>
      <td>83.0</td>
      <td>14.0</td>
      <td>99.0</td>
      <td>176.135</td>
      <td>5360.0</td>
      <td>338.91</td>
      <td>POLYGON ((933555 2291420, 933269 2291556, 9326...</td>
    </tr>
    <tr>
      <th>68</th>
      <td>71.0</td>
      <td>S</td>
      <td>Saone-et-Loire</td>
      <td>28391.0</td>
      <td>10708.0</td>
      <td>32.0</td>
      <td>3710.0</td>
      <td>20442.0</td>
      <td>22184.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>10.0</td>
      <td>58.0</td>
      <td>45.0</td>
      <td>31.0</td>
      <td>49.0</td>
      <td>40.0</td>
      <td>168.713</td>
      <td>8575.0</td>
      <td>523.97</td>
      <td>POLYGON ((834930 2207585, 834681 2207740, 8344...</td>
    </tr>
    <tr>
      <th>70</th>
      <td>75.0</td>
      <td>S</td>
      <td>Seine</td>
      <td>13945.0</td>
      <td>1368.0</td>
      <td>71.0</td>
      <td>4204.0</td>
      <td>2660.0</td>
      <td>3632.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>67.0</td>
      <td>53.0</td>
      <td>1.0</td>
      <td>33.0</td>
      <td>6.0</td>
      <td>4744.0</td>
      <td>0.000</td>
      <td>762.0</td>
      <td>935.11</td>
      <td>POLYGON ((615302 2411120, 615000 2411180, 6143...</td>
    </tr>
    <tr>
      <th>71</th>
      <td>76.0</td>
      <td>S</td>
      <td>Seine-Inferieure</td>
      <td>18355.0</td>
      <td>2906.0</td>
      <td>43.0</td>
      <td>7245.0</td>
      <td>7506.0</td>
      <td>9523.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>61.0</td>
      <td>74.0</td>
      <td>9.0</td>
      <td>36.0</td>
      <td>35.0</td>
      <td>546.0</td>
      <td>75.658</td>
      <td>6278.0</td>
      <td>693.68</td>
      <td>POLYGON ((438965 2512493, 440124 2514448, 4402...</td>
    </tr>
    <tr>
      <th>72</th>
      <td>77.0</td>
      <td>S</td>
      <td>Seine-et-Marne</td>
      <td>22201.0</td>
      <td>5786.0</td>
      <td>54.0</td>
      <td>5303.0</td>
      <td>16324.0</td>
      <td>7315.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>73.0</td>
      <td>26.0</td>
      <td>29.0</td>
      <td>67.0</td>
      <td>37.0</td>
      <td>453.0</td>
      <td>27.647</td>
      <td>5915.0</td>
      <td>323.89</td>
      <td>POLYGON ((675580 2375994, 675218 2376008, 6748...</td>
    </tr>
    <tr>
      <th>73</th>
      <td>78.0</td>
      <td>S</td>
      <td>Seine-et-Oise</td>
      <td>12477.0</td>
      <td>3879.0</td>
      <td>56.0</td>
      <td>4007.0</td>
      <td>16303.0</td>
      <td>3460.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>30.0</td>
      <td>24.0</td>
      <td>6.0</td>
      <td>42.0</td>
      <td>17.0</td>
      <td>874.0</td>
      <td>16.888</td>
      <td>5334.0</td>
      <td>448.18</td>
      <td>POLYGON ((546799 2453567, 547588 2454258, 5478...</td>
    </tr>
    <tr>
      <th>74</th>
      <td>79.0</td>
      <td>S</td>
      <td>Deux-Sevres</td>
      <td>18400.0</td>
      <td>6863.0</td>
      <td>41.0</td>
      <td>16956.0</td>
      <td>25461.0</td>
      <td>24533.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>4.0</td>
      <td>85.0</td>
      <td>71.0</td>
      <td>84.0</td>
      <td>39.0</td>
      <td>6.0</td>
      <td>188.474</td>
      <td>5999.0</td>
      <td>297.85</td>
      <td>POLYGON ((419808 2218480, 420449 2218054, 4209...</td>
    </tr>
    <tr>
      <th>75</th>
      <td>80.0</td>
      <td>S</td>
      <td>Somme</td>
      <td>33592.0</td>
      <td>7144.0</td>
      <td>44.0</td>
      <td>4964.0</td>
      <td>12447.0</td>
      <td>12836.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>64.0</td>
      <td>33.0</td>
      <td>30.0</td>
      <td>80.0</td>
      <td>34.0</td>
      <td>302.0</td>
      <td>69.520</td>
      <td>6170.0</td>
      <td>543.70</td>
      <td>POLYGON ((543667 2592806, 544247 2596216, 5451...</td>
    </tr>
    <tr>
      <th>79</th>
      <td>84.0</td>
      <td>S</td>
      <td>Vaucluse</td>
      <td>13576.0</td>
      <td>5731.0</td>
      <td>37.0</td>
      <td>1246.0</td>
      <td>17239.0</td>
      <td>19024.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>76.0</td>
      <td>54.0</td>
      <td>8.0</td>
      <td>41.0</td>
      <td>45.0</td>
      <td>2.0</td>
      <td>337.215</td>
      <td>3567.0</td>
      <td>239.11</td>
      <td>MULTIPOLYGON (((811669 1924852, 811384 1925100...</td>
    </tr>
    <tr>
      <th>83</th>
      <td>88.0</td>
      <td>S</td>
      <td>Vosges</td>
      <td>18835.0</td>
      <td>9044.0</td>
      <td>62.0</td>
      <td>4040.0</td>
      <td>14978.0</td>
      <td>33029.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>34.0</td>
      <td>5.0</td>
      <td>14.0</td>
      <td>85.0</td>
      <td>11.0</td>
      <td>43.0</td>
      <td>174.477</td>
      <td>5874.0</td>
      <td>397.99</td>
      <td>POLYGON ((951144 2383215, 953082 2382491, 9534...</td>
    </tr>
    <tr>
      <th>84</th>
      <td>89.0</td>
      <td>S</td>
      <td>Yonne</td>
      <td>18006.0</td>
      <td>6516.0</td>
      <td>47.0</td>
      <td>4276.0</td>
      <td>16616.0</td>
      <td>12789.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>22.0</td>
      <td>35.0</td>
      <td>51.0</td>
      <td>66.0</td>
      <td>27.0</td>
      <td>272.0</td>
      <td>81.797</td>
      <td>7427.0</td>
      <td>352.49</td>
      <td>POLYGON ((650260 2358330, 651712 2361305, 6528...</td>
    </tr>
  </tbody>
</table>
<p>53 rows × 24 columns</p>
</div>




```python
guerry_literate = guerry[guerry["Litercy"] > 30]

guerry_literate
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>dept</th>
      <th>Region</th>
      <th>Dprtmnt</th>
      <th>Crm_prs</th>
      <th>Crm_prp</th>
      <th>Litercy</th>
      <th>Donatns</th>
      <th>Infants</th>
      <th>Suicids</th>
      <th>MainCty</th>
      <th>...</th>
      <th>Infntcd</th>
      <th>Dntn_cl</th>
      <th>Lottery</th>
      <th>Desertn</th>
      <th>Instrct</th>
      <th>Prsttts</th>
      <th>Distanc</th>
      <th>Area</th>
      <th>Pop1831</th>
      <th>geometry</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>S</td>
      <td>Ain</td>
      <td>28870.0</td>
      <td>15890.0</td>
      <td>37.0</td>
      <td>5098.0</td>
      <td>33120.0</td>
      <td>35039.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>60.0</td>
      <td>69.0</td>
      <td>41.0</td>
      <td>55.0</td>
      <td>46.0</td>
      <td>13.0</td>
      <td>218.372</td>
      <td>5762.0</td>
      <td>346.03</td>
      <td>POLYGON ((801150 2092615, 800669 2093190, 8006...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2.0</td>
      <td>S</td>
      <td>Aisne</td>
      <td>26226.0</td>
      <td>5521.0</td>
      <td>51.0</td>
      <td>8901.0</td>
      <td>14572.0</td>
      <td>12831.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>82.0</td>
      <td>36.0</td>
      <td>38.0</td>
      <td>82.0</td>
      <td>24.0</td>
      <td>327.0</td>
      <td>65.945</td>
      <td>7369.0</td>
      <td>513.00</td>
      <td>POLYGON ((729326 2521619, 729320 2521230, 7292...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.0</td>
      <td>S</td>
      <td>Basses-Alpes</td>
      <td>12935.0</td>
      <td>7289.0</td>
      <td>46.0</td>
      <td>2733.0</td>
      <td>23018.0</td>
      <td>14238.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>12.0</td>
      <td>37.0</td>
      <td>80.0</td>
      <td>32.0</td>
      <td>29.0</td>
      <td>2.0</td>
      <td>351.399</td>
      <td>6925.0</td>
      <td>155.90</td>
      <td>POLYGON ((882701 1920024, 882408 1920733, 8817...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>S</td>
      <td>Hautes-Alpes</td>
      <td>17488.0</td>
      <td>8174.0</td>
      <td>69.0</td>
      <td>6962.0</td>
      <td>23076.0</td>
      <td>16171.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>23.0</td>
      <td>64.0</td>
      <td>79.0</td>
      <td>35.0</td>
      <td>7.0</td>
      <td>1.0</td>
      <td>320.280</td>
      <td>5549.0</td>
      <td>129.10</td>
      <td>POLYGON ((886504 1922890, 885733 1922978, 8854...</td>
    </tr>
    <tr>
      <th>6</th>
      <td>8.0</td>
      <td>S</td>
      <td>Ardennes</td>
      <td>35203.0</td>
      <td>8847.0</td>
      <td>67.0</td>
      <td>6400.0</td>
      <td>16106.0</td>
      <td>26198.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>85.0</td>
      <td>49.0</td>
      <td>31.0</td>
      <td>62.0</td>
      <td>9.0</td>
      <td>83.0</td>
      <td>105.694</td>
      <td>5229.0</td>
      <td>289.62</td>
      <td>POLYGON ((818893 2514767, 818614 2514515, 8179...</td>
    </tr>
    <tr>
      <th>8</th>
      <td>10.0</td>
      <td>S</td>
      <td>Aube</td>
      <td>19602.0</td>
      <td>4086.0</td>
      <td>59.0</td>
      <td>3608.0</td>
      <td>18642.0</td>
      <td>10989.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>54.0</td>
      <td>9.0</td>
      <td>28.0</td>
      <td>86.0</td>
      <td>15.0</td>
      <td>207.0</td>
      <td>83.244</td>
      <td>6004.0</td>
      <td>246.36</td>
      <td>POLYGON ((775400 2345600, 775068 2345397, 7735...</td>
    </tr>
    <tr>
      <th>9</th>
      <td>11.0</td>
      <td>S</td>
      <td>Aude</td>
      <td>15647.0</td>
      <td>10431.0</td>
      <td>34.0</td>
      <td>2582.0</td>
      <td>20225.0</td>
      <td>66498.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>35.0</td>
      <td>27.0</td>
      <td>50.0</td>
      <td>63.0</td>
      <td>48.0</td>
      <td>1.0</td>
      <td>370.949</td>
      <td>6139.0</td>
      <td>270.13</td>
      <td>POLYGON ((626230 1810121, 626269 1810496, 6274...</td>
    </tr>
    <tr>
      <th>10</th>
      <td>12.0</td>
      <td>S</td>
      <td>Aveyron</td>
      <td>8236.0</td>
      <td>6731.0</td>
      <td>31.0</td>
      <td>3211.0</td>
      <td>21981.0</td>
      <td>116671.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>5.0</td>
      <td>23.0</td>
      <td>81.0</td>
      <td>10.0</td>
      <td>44.0</td>
      <td>4.0</td>
      <td>296.089</td>
      <td>8735.0</td>
      <td>359.06</td>
      <td>POLYGON ((642972 1978185, 643791 1976549, 6444...</td>
    </tr>
    <tr>
      <th>11</th>
      <td>13.0</td>
      <td>S</td>
      <td>Bouches-du-Rhone</td>
      <td>13409.0</td>
      <td>5291.0</td>
      <td>38.0</td>
      <td>2314.0</td>
      <td>9325.0</td>
      <td>8107.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>74.0</td>
      <td>55.0</td>
      <td>3.0</td>
      <td>23.0</td>
      <td>43.0</td>
      <td>25.0</td>
      <td>362.568</td>
      <td>5087.0</td>
      <td>359.47</td>
      <td>POLYGON ((824692 1865875, 825615 1865409, 8259...</td>
    </tr>
    <tr>
      <th>12</th>
      <td>14.0</td>
      <td>S</td>
      <td>Calvados</td>
      <td>17577.0</td>
      <td>4500.0</td>
      <td>52.0</td>
      <td>27830.0</td>
      <td>8983.0</td>
      <td>31807.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>56.0</td>
      <td>11.0</td>
      <td>13.0</td>
      <td>12.0</td>
      <td>22.0</td>
      <td>194.0</td>
      <td>117.487</td>
      <td>5548.0</td>
      <td>494.70</td>
      <td>POLYGON ((345476 2429914, 345299 2430235, 3436...</td>
    </tr>
    <tr>
      <th>13</th>
      <td>15.0</td>
      <td>S</td>
      <td>Cantal</td>
      <td>18070.0</td>
      <td>11645.0</td>
      <td>31.0</td>
      <td>4093.0</td>
      <td>15335.0</td>
      <td>87338.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>83.0</td>
      <td>66.0</td>
      <td>82.0</td>
      <td>1.0</td>
      <td>51.0</td>
      <td>20.0</td>
      <td>245.849</td>
      <td>5726.0</td>
      <td>258.59</td>
      <td>POLYGON ((591653 2017934, 591727 2018244, 5918...</td>
    </tr>
    <tr>
      <th>14</th>
      <td>16.0</td>
      <td>S</td>
      <td>Charente</td>
      <td>24964.0</td>
      <td>13018.0</td>
      <td>36.0</td>
      <td>13602.0</td>
      <td>19454.0</td>
      <td>25720.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>7.0</td>
      <td>81.0</td>
      <td>60.0</td>
      <td>61.0</td>
      <td>47.0</td>
      <td>8.0</td>
      <td>224.339</td>
      <td>5956.0</td>
      <td>362.53</td>
      <td>POLYGON ((456425 2120055, 456229 2120382, 4559...</td>
    </tr>
    <tr>
      <th>15</th>
      <td>17.0</td>
      <td>S</td>
      <td>Charente-Inferieure</td>
      <td>18712.0</td>
      <td>5357.0</td>
      <td>39.0</td>
      <td>13254.0</td>
      <td>23999.0</td>
      <td>16798.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>38.0</td>
      <td>72.0</td>
      <td>35.0</td>
      <td>74.0</td>
      <td>42.0</td>
      <td>27.0</td>
      <td>238.538</td>
      <td>6864.0</td>
      <td>445.25</td>
      <td>MULTIPOLYGON (((328075 2118055, 327916 2118168...</td>
    </tr>
    <tr>
      <th>18</th>
      <td>21.0</td>
      <td>S</td>
      <td>Cote-d'Or</td>
      <td>32256.0</td>
      <td>9159.0</td>
      <td>60.0</td>
      <td>2540.0</td>
      <td>15599.0</td>
      <td>16128.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>27.0</td>
      <td>18.0</td>
      <td>33.0</td>
      <td>78.0</td>
      <td>13.0</td>
      <td>206.0</td>
      <td>136.109</td>
      <td>8763.0</td>
      <td>375.88</td>
      <td>MULTIPOLYGON (((738935 2236890, 738359 2237343...</td>
    </tr>
    <tr>
      <th>22</th>
      <td>25.0</td>
      <td>S</td>
      <td>Doubs</td>
      <td>11560.0</td>
      <td>5914.0</td>
      <td>73.0</td>
      <td>3436.0</td>
      <td>12512.0</td>
      <td>40690.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>25.0</td>
      <td>6.0</td>
      <td>18.0</td>
      <td>73.0</td>
      <td>2.0</td>
      <td>65.0</td>
      <td>202.065</td>
      <td>5234.0</td>
      <td>265.54</td>
      <td>POLYGON ((886630 2188665, 886948 2188898, 8879...</td>
    </tr>
    <tr>
      <th>23</th>
      <td>26.0</td>
      <td>S</td>
      <td>Drome</td>
      <td>13396.0</td>
      <td>7759.0</td>
      <td>42.0</td>
      <td>2829.0</td>
      <td>16348.0</td>
      <td>23816.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>13.0</td>
      <td>62.0</td>
      <td>54.0</td>
      <td>46.0</td>
      <td>38.0</td>
      <td>8.0</td>
      <td>295.543</td>
      <td>6530.0</td>
      <td>299.56</td>
      <td>POLYGON ((830803 2010472, 831288 2010361, 8315...</td>
    </tr>
    <tr>
      <th>24</th>
      <td>27.0</td>
      <td>S</td>
      <td>Eure</td>
      <td>14795.0</td>
      <td>4774.0</td>
      <td>51.0</td>
      <td>11712.0</td>
      <td>16039.0</td>
      <td>13493.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>45.0</td>
      <td>45.0</td>
      <td>47.0</td>
      <td>27.0</td>
      <td>23.0</td>
      <td>179.0</td>
      <td>61.863</td>
      <td>6040.0</td>
      <td>424.25</td>
      <td>POLYGON ((515046 2482676, 515755 2483384, 5160...</td>
    </tr>
    <tr>
      <th>25</th>
      <td>28.0</td>
      <td>S</td>
      <td>Eure-et-Loir</td>
      <td>21368.0</td>
      <td>4016.0</td>
      <td>54.0</td>
      <td>4553.0</td>
      <td>14475.0</td>
      <td>15015.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>62.0</td>
      <td>14.0</td>
      <td>48.0</td>
      <td>72.0</td>
      <td>18.0</td>
      <td>180.0</td>
      <td>54.558</td>
      <td>5880.0</td>
      <td>278.82</td>
      <td>POLYGON ((562860 2342515, 562499 2342577, 5602...</td>
    </tr>
    <tr>
      <th>27</th>
      <td>30.0</td>
      <td>S</td>
      <td>Gard</td>
      <td>13115.0</td>
      <td>7990.0</td>
      <td>40.0</td>
      <td>3048.0</td>
      <td>28726.0</td>
      <td>18292.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>39.0</td>
      <td>59.0</td>
      <td>20.0</td>
      <td>40.0</td>
      <td>40.0</td>
      <td>5.0</td>
      <td>323.004</td>
      <td>5853.0</td>
      <td>357.38</td>
      <td>POLYGON ((719592 1880745, 719924 1881419, 7194...</td>
    </tr>
    <tr>
      <th>28</th>
      <td>31.0</td>
      <td>S</td>
      <td>Haute-Garonne</td>
      <td>18642.0</td>
      <td>7204.0</td>
      <td>31.0</td>
      <td>2286.0</td>
      <td>15378.0</td>
      <td>56140.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>59.0</td>
      <td>13.0</td>
      <td>25.0</td>
      <td>15.0</td>
      <td>33.0</td>
      <td>8.0</td>
      <td>361.668</td>
      <td>6257.0</td>
      <td>427.86</td>
      <td>POLYGON ((491745 1820323, 491926 1820668, 4914...</td>
    </tr>
    <tr>
      <th>29</th>
      <td>32.0</td>
      <td>S</td>
      <td>Gers</td>
      <td>18642.0</td>
      <td>10486.0</td>
      <td>38.0</td>
      <td>2848.0</td>
      <td>15250.0</td>
      <td>61510.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>13.0</td>
      <td>32.0</td>
      <td>74.0</td>
      <td>30.0</td>
      <td>44.0</td>
      <td>1.0</td>
      <td>343.569</td>
      <td>6309.0</td>
      <td>312.16</td>
      <td>POLYGON ((447673 1816738, 447362 1816893, 4463...</td>
    </tr>
    <tr>
      <th>30</th>
      <td>33.0</td>
      <td>S</td>
      <td>Gironde</td>
      <td>24096.0</td>
      <td>7423.0</td>
      <td>40.0</td>
      <td>5076.0</td>
      <td>10676.0</td>
      <td>19220.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>80.0</td>
      <td>48.0</td>
      <td>4.0</td>
      <td>13.0</td>
      <td>41.0</td>
      <td>39.0</td>
      <td>291.624</td>
      <td>10000.0</td>
      <td>554.23</td>
      <td>MULTIPOLYGON (((332874 1966651, 332777 1966980...</td>
    </tr>
    <tr>
      <th>31</th>
      <td>34.0</td>
      <td>S</td>
      <td>Herault</td>
      <td>12814.0</td>
      <td>10954.0</td>
      <td>45.0</td>
      <td>1680.0</td>
      <td>21346.0</td>
      <td>30869.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>51.0</td>
      <td>28.0</td>
      <td>19.0</td>
      <td>43.0</td>
      <td>32.0</td>
      <td>9.0</td>
      <td>344.030</td>
      <td>6101.0</td>
      <td>346.30</td>
      <td>POLYGON ((739523 1864067, 740853 1864454, 7414...</td>
    </tr>
    <tr>
      <th>36</th>
      <td>39.0</td>
      <td>S</td>
      <td>Jura</td>
      <td>26221.0</td>
      <td>8059.0</td>
      <td>73.0</td>
      <td>3012.0</td>
      <td>20384.0</td>
      <td>34476.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>66.0</td>
      <td>43.0</td>
      <td>39.0</td>
      <td>71.0</td>
      <td>3.0</td>
      <td>32.0</td>
      <td>197.155</td>
      <td>4999.0</td>
      <td>312.50</td>
      <td>MULTIPOLYGON (((836965 2209730, 836855 2209785...</td>
    </tr>
    <tr>
      <th>42</th>
      <td>45.0</td>
      <td>S</td>
      <td>Loiret</td>
      <td>17722.0</td>
      <td>5042.0</td>
      <td>42.0</td>
      <td>4753.0</td>
      <td>9986.0</td>
      <td>11813.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>22.0</td>
      <td>16.0</td>
      <td>17.0</td>
      <td>60.0</td>
      <td>37.0</td>
      <td>256.0</td>
      <td>61.106</td>
      <td>6775.0</td>
      <td>305.28</td>
      <td>POLYGON ((557890 2341355, 558382 2341921, 5598...</td>
    </tr>
    <tr>
      <th>44</th>
      <td>47.0</td>
      <td>S</td>
      <td>Lot-et-Garonne</td>
      <td>22969.0</td>
      <td>8943.0</td>
      <td>31.0</td>
      <td>4432.0</td>
      <td>17681.0</td>
      <td>38501.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>32.0</td>
      <td>46.0</td>
      <td>52.0</td>
      <td>34.0</td>
      <td>50.0</td>
      <td>5.0</td>
      <td>302.345</td>
      <td>5361.0</td>
      <td>346.89</td>
      <td>POLYGON ((413714 1942691, 413362 1942587, 4128...</td>
    </tr>
    <tr>
      <th>47</th>
      <td>50.0</td>
      <td>S</td>
      <td>Manche</td>
      <td>31078.0</td>
      <td>7424.0</td>
      <td>43.0</td>
      <td>5179.0</td>
      <td>14281.0</td>
      <td>55564.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>70.0</td>
      <td>3.0</td>
      <td>59.0</td>
      <td>21.0</td>
      <td>36.0</td>
      <td>98.0</td>
      <td>157.187</td>
      <td>5938.0</td>
      <td>591.28</td>
      <td>MULTIPOLYGON (((316425 2410987, 316287 2411065...</td>
    </tr>
    <tr>
      <th>48</th>
      <td>51.0</td>
      <td>S</td>
      <td>Marne</td>
      <td>15602.0</td>
      <td>4950.0</td>
      <td>63.0</td>
      <td>3963.0</td>
      <td>11267.0</td>
      <td>8334.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>58.0</td>
      <td>39.0</td>
      <td>22.0</td>
      <td>81.0</td>
      <td>10.0</td>
      <td>262.0</td>
      <td>77.364</td>
      <td>6211.0</td>
      <td>337.08</td>
      <td>POLYGON ((781920 2395187, 781562 2395133, 7809...</td>
    </tr>
    <tr>
      <th>49</th>
      <td>52.0</td>
      <td>S</td>
      <td>Haute-Marne</td>
      <td>26231.0</td>
      <td>9539.0</td>
      <td>72.0</td>
      <td>4013.0</td>
      <td>17507.0</td>
      <td>19586.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>55.0</td>
      <td>4.0</td>
      <td>56.0</td>
      <td>65.0</td>
      <td>4.0</td>
      <td>138.0</td>
      <td>129.765</td>
      <td>8162.0</td>
      <td>249.83</td>
      <td>POLYGON ((776565 2346640, 776344 2346943, 7780...</td>
    </tr>
    <tr>
      <th>51</th>
      <td>54.0</td>
      <td>S</td>
      <td>Meurthe</td>
      <td>26674.0</td>
      <td>6831.0</td>
      <td>68.0</td>
      <td>3912.0</td>
      <td>12355.0</td>
      <td>15652.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>71.0</td>
      <td>1.0</td>
      <td>21.0</td>
      <td>70.0</td>
      <td>8.0</td>
      <td>154.0</td>
      <td>159.648</td>
      <td>5241.0</td>
      <td>415.57</td>
      <td>MULTIPOLYGON (((826186 2502671, 825892 2502926...</td>
    </tr>
    <tr>
      <th>52</th>
      <td>55.0</td>
      <td>S</td>
      <td>Meuse</td>
      <td>24507.0</td>
      <td>9190.0</td>
      <td>74.0</td>
      <td>4196.0</td>
      <td>17333.0</td>
      <td>13463.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>65.0</td>
      <td>12.0</td>
      <td>58.0</td>
      <td>59.0</td>
      <td>1.0</td>
      <td>131.0</td>
      <td>126.378</td>
      <td>6216.0</td>
      <td>314.59</td>
      <td>POLYGON ((853530 2462643, 853898 2462654, 8542...</td>
    </tr>
    <tr>
      <th>54</th>
      <td>57.0</td>
      <td>S</td>
      <td>Moselle</td>
      <td>12153.0</td>
      <td>4529.0</td>
      <td>57.0</td>
      <td>9515.0</td>
      <td>13877.0</td>
      <td>25572.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>9.0</td>
      <td>2.0</td>
      <td>16.0</td>
      <td>68.0</td>
      <td>16.0</td>
      <td>165.0</td>
      <td>180.462</td>
      <td>6216.0</td>
      <td>417.00</td>
      <td>POLYGON ((929062 2475639, 929093 2476415, 9280...</td>
    </tr>
    <tr>
      <th>56</th>
      <td>59.0</td>
      <td>S</td>
      <td>Nord</td>
      <td>26740.0</td>
      <td>6175.0</td>
      <td>45.0</td>
      <td>6092.0</td>
      <td>8926.0</td>
      <td>13851.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>81.0</td>
      <td>38.0</td>
      <td>7.0</td>
      <td>64.0</td>
      <td>30.0</td>
      <td>308.0</td>
      <td>106.335</td>
      <td>5743.0</td>
      <td>989.94</td>
      <td>MULTIPOLYGON (((664166 2630647, 664342 2629299...</td>
    </tr>
    <tr>
      <th>57</th>
      <td>60.0</td>
      <td>S</td>
      <td>Oise</td>
      <td>28180.0</td>
      <td>6659.0</td>
      <td>54.0</td>
      <td>5501.0</td>
      <td>18021.0</td>
      <td>5994.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>86.0</td>
      <td>50.0</td>
      <td>43.0</td>
      <td>57.0</td>
      <td>20.0</td>
      <td>337.0</td>
      <td>33.768</td>
      <td>5860.0</td>
      <td>397.73</td>
      <td>MULTIPOLYGON (((647667 2468296, 647542 2468371...</td>
    </tr>
    <tr>
      <th>58</th>
      <td>61.0</td>
      <td>S</td>
      <td>Orne</td>
      <td>28329.0</td>
      <td>8248.0</td>
      <td>45.0</td>
      <td>9242.0</td>
      <td>20852.0</td>
      <td>34069.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>50.0</td>
      <td>31.0</td>
      <td>57.0</td>
      <td>25.0</td>
      <td>33.0</td>
      <td>117.0</td>
      <td>97.554</td>
      <td>6103.0</td>
      <td>441.88</td>
      <td>POLYGON ((469173 2432434, 470681 2434059, 4709...</td>
    </tr>
    <tr>
      <th>59</th>
      <td>62.0</td>
      <td>S</td>
      <td>Pas-de-Calais</td>
      <td>23101.0</td>
      <td>4040.0</td>
      <td>49.0</td>
      <td>5740.0</td>
      <td>10575.0</td>
      <td>15400.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>79.0</td>
      <td>10.0</td>
      <td>27.0</td>
      <td>48.0</td>
      <td>26.0</td>
      <td>163.0</td>
      <td>104.400</td>
      <td>6671.0</td>
      <td>655.22</td>
      <td>POLYGON ((629822 2560555, 629583 2560843, 6291...</td>
    </tr>
    <tr>
      <th>61</th>
      <td>64.0</td>
      <td>S</td>
      <td>Basses-Pyrenees</td>
      <td>16722.0</td>
      <td>8533.0</td>
      <td>47.0</td>
      <td>3299.0</td>
      <td>12393.0</td>
      <td>65995.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>72.0</td>
      <td>60.0</td>
      <td>34.0</td>
      <td>7.0</td>
      <td>28.0</td>
      <td>12.0</td>
      <td>387.935</td>
      <td>7645.0</td>
      <td>428.40</td>
      <td>POLYGON ((386095 1774604, 386085 1774237, 3855...</td>
    </tr>
    <tr>
      <th>62</th>
      <td>65.0</td>
      <td>S</td>
      <td>Hautes-Pyrenees</td>
      <td>12223.0</td>
      <td>9797.0</td>
      <td>53.0</td>
      <td>6001.0</td>
      <td>12125.0</td>
      <td>148039.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>75.0</td>
      <td>71.0</td>
      <td>76.0</td>
      <td>20.0</td>
      <td>21.0</td>
      <td>5.0</td>
      <td>386.559</td>
      <td>4464.0</td>
      <td>233.03</td>
      <td>MULTIPOLYGON (((406987 1826038, 405019 1826121...</td>
    </tr>
    <tr>
      <th>63</th>
      <td>66.0</td>
      <td>S</td>
      <td>Pyrenees-Orientales</td>
      <td>6728.0</td>
      <td>7632.0</td>
      <td>31.0</td>
      <td>11644.0</td>
      <td>15167.0</td>
      <td>37843.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>84.0</td>
      <td>77.0</td>
      <td>11.0</td>
      <td>18.0</td>
      <td>52.0</td>
      <td>5.0</td>
      <td>403.445</td>
      <td>4116.0</td>
      <td>157.05</td>
      <td>POLYGON ((658127 1733192, 658228 1732843, 6582...</td>
    </tr>
    <tr>
      <th>64</th>
      <td>67.0</td>
      <td>S</td>
      <td>Bas-Rhin</td>
      <td>12309.0</td>
      <td>4920.0</td>
      <td>62.0</td>
      <td>14472.0</td>
      <td>14356.0</td>
      <td>18623.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>48.0</td>
      <td>51.0</td>
      <td>5.0</td>
      <td>53.0</td>
      <td>12.0</td>
      <td>101.0</td>
      <td>217.752</td>
      <td>4755.0</td>
      <td>540.21</td>
      <td>POLYGON ((946663 2460717, 946292 2461188, 9461...</td>
    </tr>
    <tr>
      <th>65</th>
      <td>68.0</td>
      <td>S</td>
      <td>Haut-Rhin</td>
      <td>7343.0</td>
      <td>4915.0</td>
      <td>71.0</td>
      <td>6001.0</td>
      <td>14783.0</td>
      <td>21233.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>53.0</td>
      <td>17.0</td>
      <td>10.0</td>
      <td>56.0</td>
      <td>5.0</td>
      <td>26.0</td>
      <td>217.971</td>
      <td>3525.0</td>
      <td>424.26</td>
      <td>POLYGON ((989865 2319005, 990659 2316949, 9900...</td>
    </tr>
    <tr>
      <th>66</th>
      <td>69.0</td>
      <td>S</td>
      <td>Rhone</td>
      <td>18793.0</td>
      <td>4504.0</td>
      <td>45.0</td>
      <td>1983.0</td>
      <td>3910.0</td>
      <td>17003.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>33.0</td>
      <td>21.0</td>
      <td>2.0</td>
      <td>14.0</td>
      <td>31.0</td>
      <td>104.0</td>
      <td>213.032</td>
      <td>3249.0</td>
      <td>434.43</td>
      <td>POLYGON ((752410 2115380, 752067 2115294, 7510...</td>
    </tr>
    <tr>
      <th>67</th>
      <td>70.0</td>
      <td>S</td>
      <td>Haute-Saone</td>
      <td>22339.0</td>
      <td>7770.0</td>
      <td>59.0</td>
      <td>11701.0</td>
      <td>11850.0</td>
      <td>39714.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>68.0</td>
      <td>57.0</td>
      <td>65.0</td>
      <td>83.0</td>
      <td>14.0</td>
      <td>99.0</td>
      <td>176.135</td>
      <td>5360.0</td>
      <td>338.91</td>
      <td>POLYGON ((933555 2291420, 933269 2291556, 9326...</td>
    </tr>
    <tr>
      <th>68</th>
      <td>71.0</td>
      <td>S</td>
      <td>Saone-et-Loire</td>
      <td>28391.0</td>
      <td>10708.0</td>
      <td>32.0</td>
      <td>3710.0</td>
      <td>20442.0</td>
      <td>22184.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>10.0</td>
      <td>58.0</td>
      <td>45.0</td>
      <td>31.0</td>
      <td>49.0</td>
      <td>40.0</td>
      <td>168.713</td>
      <td>8575.0</td>
      <td>523.97</td>
      <td>POLYGON ((834930 2207585, 834681 2207740, 8344...</td>
    </tr>
    <tr>
      <th>70</th>
      <td>75.0</td>
      <td>S</td>
      <td>Seine</td>
      <td>13945.0</td>
      <td>1368.0</td>
      <td>71.0</td>
      <td>4204.0</td>
      <td>2660.0</td>
      <td>3632.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>67.0</td>
      <td>53.0</td>
      <td>1.0</td>
      <td>33.0</td>
      <td>6.0</td>
      <td>4744.0</td>
      <td>0.000</td>
      <td>762.0</td>
      <td>935.11</td>
      <td>POLYGON ((615302 2411120, 615000 2411180, 6143...</td>
    </tr>
    <tr>
      <th>71</th>
      <td>76.0</td>
      <td>S</td>
      <td>Seine-Inferieure</td>
      <td>18355.0</td>
      <td>2906.0</td>
      <td>43.0</td>
      <td>7245.0</td>
      <td>7506.0</td>
      <td>9523.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>61.0</td>
      <td>74.0</td>
      <td>9.0</td>
      <td>36.0</td>
      <td>35.0</td>
      <td>546.0</td>
      <td>75.658</td>
      <td>6278.0</td>
      <td>693.68</td>
      <td>POLYGON ((438965 2512493, 440124 2514448, 4402...</td>
    </tr>
    <tr>
      <th>72</th>
      <td>77.0</td>
      <td>S</td>
      <td>Seine-et-Marne</td>
      <td>22201.0</td>
      <td>5786.0</td>
      <td>54.0</td>
      <td>5303.0</td>
      <td>16324.0</td>
      <td>7315.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>73.0</td>
      <td>26.0</td>
      <td>29.0</td>
      <td>67.0</td>
      <td>37.0</td>
      <td>453.0</td>
      <td>27.647</td>
      <td>5915.0</td>
      <td>323.89</td>
      <td>POLYGON ((675580 2375994, 675218 2376008, 6748...</td>
    </tr>
    <tr>
      <th>73</th>
      <td>78.0</td>
      <td>S</td>
      <td>Seine-et-Oise</td>
      <td>12477.0</td>
      <td>3879.0</td>
      <td>56.0</td>
      <td>4007.0</td>
      <td>16303.0</td>
      <td>3460.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>30.0</td>
      <td>24.0</td>
      <td>6.0</td>
      <td>42.0</td>
      <td>17.0</td>
      <td>874.0</td>
      <td>16.888</td>
      <td>5334.0</td>
      <td>448.18</td>
      <td>POLYGON ((546799 2453567, 547588 2454258, 5478...</td>
    </tr>
    <tr>
      <th>74</th>
      <td>79.0</td>
      <td>S</td>
      <td>Deux-Sevres</td>
      <td>18400.0</td>
      <td>6863.0</td>
      <td>41.0</td>
      <td>16956.0</td>
      <td>25461.0</td>
      <td>24533.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>4.0</td>
      <td>85.0</td>
      <td>71.0</td>
      <td>84.0</td>
      <td>39.0</td>
      <td>6.0</td>
      <td>188.474</td>
      <td>5999.0</td>
      <td>297.85</td>
      <td>POLYGON ((419808 2218480, 420449 2218054, 4209...</td>
    </tr>
    <tr>
      <th>75</th>
      <td>80.0</td>
      <td>S</td>
      <td>Somme</td>
      <td>33592.0</td>
      <td>7144.0</td>
      <td>44.0</td>
      <td>4964.0</td>
      <td>12447.0</td>
      <td>12836.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>64.0</td>
      <td>33.0</td>
      <td>30.0</td>
      <td>80.0</td>
      <td>34.0</td>
      <td>302.0</td>
      <td>69.520</td>
      <td>6170.0</td>
      <td>543.70</td>
      <td>POLYGON ((543667 2592806, 544247 2596216, 5451...</td>
    </tr>
    <tr>
      <th>79</th>
      <td>84.0</td>
      <td>S</td>
      <td>Vaucluse</td>
      <td>13576.0</td>
      <td>5731.0</td>
      <td>37.0</td>
      <td>1246.0</td>
      <td>17239.0</td>
      <td>19024.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>76.0</td>
      <td>54.0</td>
      <td>8.0</td>
      <td>41.0</td>
      <td>45.0</td>
      <td>2.0</td>
      <td>337.215</td>
      <td>3567.0</td>
      <td>239.11</td>
      <td>MULTIPOLYGON (((811669 1924852, 811384 1925100...</td>
    </tr>
    <tr>
      <th>83</th>
      <td>88.0</td>
      <td>S</td>
      <td>Vosges</td>
      <td>18835.0</td>
      <td>9044.0</td>
      <td>62.0</td>
      <td>4040.0</td>
      <td>14978.0</td>
      <td>33029.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>34.0</td>
      <td>5.0</td>
      <td>14.0</td>
      <td>85.0</td>
      <td>11.0</td>
      <td>43.0</td>
      <td>174.477</td>
      <td>5874.0</td>
      <td>397.99</td>
      <td>POLYGON ((951144 2383215, 953082 2382491, 9534...</td>
    </tr>
    <tr>
      <th>84</th>
      <td>89.0</td>
      <td>S</td>
      <td>Yonne</td>
      <td>18006.0</td>
      <td>6516.0</td>
      <td>47.0</td>
      <td>4276.0</td>
      <td>16616.0</td>
      <td>12789.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>22.0</td>
      <td>35.0</td>
      <td>51.0</td>
      <td>66.0</td>
      <td>27.0</td>
      <td>272.0</td>
      <td>81.797</td>
      <td>7427.0</td>
      <td>352.49</td>
      <td>POLYGON ((650260 2358330, 651712 2361305, 6528...</td>
    </tr>
  </tbody>
</table>
<p>53 rows × 24 columns</p>
</div>



## Создание объектов из таблицы

Кроме того, что объекты `GeoDataFrame`  могут быть прочитаны из какого-то распространненого формата векторных данных, применемых в ГИС, они могут быть созданы, например, из таблиц формата `DataFrame` или преобразованием других объектов.


```python
# pip install pandas
```


```python
import pandas as pd
```


```python
points_gdf = gpd.GeoDataFrame({
    'geometry': [Point(0, 1), Point(2, 2)],
    'attribute1': [1, 2],
    'attribute2': [0.1, 0.2],
    'attribute3': ['точка 1', 'точка 2']})
```


```python
points_gdf
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>geometry</th>
      <th>attribute1</th>
      <th>attribute2</th>
      <th>attribute3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>POINT (0 1)</td>
      <td>1</td>
      <td>0.1</td>
      <td>точка 1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>POINT (2 2)</td>
      <td>2</td>
      <td>0.2</td>
      <td>точка 2</td>
    </tr>
  </tbody>
</table>
</div>




```python
points_gdf.plot()
```




    <Axes: >




    
![png](output_164_1.png)
    


# Преобразования систем координат

Ответы на самые часто задаваемые вопросы про системы координат в ГИС https://gis-lab.info/qa/proj-sk-faq.html

Все основные системы координат есть в общем [реестре EPSG](https://epsg.io/)

Существует два основных типа систем координат, применяемых в ГИС и пространственном анализе:
1.   географические - в этих системах координаты определяются широтой и долготой на сфере/эллипсоиде;
2.   прямоугольные (иногда их как кальку с английского называют спроецированными) - в этих система координаты определяются в метрических единицах (метры, километры и т.д.) на плоскости.

Следует учитывать, что, если вы работаете с географическими системами координат, все измерения будут происходить в градусах и на сфере.
Если вы хотите измерять расстояния и площади на плоскости, то нужно использовать прямоугольные системы координат.


Для работы с метровым расстоянием рекомендуется использовать зональную систему координат **UTM**.
Кратко про эту систему координат можно почитать [здесь](https://ru.wikipedia.org/wiki/%D0%A3%D0%BD%D0%B8%D0%B2%D0%B5%D1%80%D1%81%D0%B0%D0%BB%D1%8C%D0%BD%D0%B0%D1%8F_%D0%BF%D0%BE%D0%BF%D0%B5%D1%80%D0%B5%D1%87%D0%BD%D0%B0%D1%8F_%D0%BF%D1%80%D0%BE%D0%B5%D0%BA%D1%86%D0%B8%D1%8F_%D0%9C%D0%B5%D1%80%D0%BA%D0%B0%D1%82%D0%BE%D1%80%D0%B0), а подробнее [здесь](https://www.gislounge.com/universal-transverse-mercator/).

Система координат **UTM (Universal Transverse Mercator )** представляет собой набор зональных систем координат.
Фактически UTM представляет собой набор из 60 отдельных «поперечных проекций Меркатора», покрывающих 60 продольных зон шириной 6° каждая. 
Он охватывает широты от 80 ° южной широты до 84 ° северной широты (полюса покрыты отдельной системой «UPS»). 
Эта система координат аналогична системе координат Гаусса-Крюгера, возможно знакомой вам, если вы изучали геодезию. Главное отличие между ними в том, как рассчитываются номера зон.

Для работы с системами координат существует библиотека [pyproj](https://pypi.org/project/pyproj/) 
Фактически эта библиотека является питоновским интерфейсом для взаимодействия с программой PROJ, которая используется во всех современных ГИС.


```python
# pip install pyproj
```


```python
from pyproj import CRS
```

Систему координат можно задать несколькими способами: 
- просто по номеру из реестра, 
- по названию реестра и номеру системы координат в нем (единая строка),
- по строке в формате proj4,
- записав отдельно строками название реестра и номер системы координат в нем.


```python
crs1 = CRS.from_epsg(4326)

crs2 = CRS.from_string('epsg:4326')

crs3 = CRS.from_proj4("+proj=latlon")

crs4 = CRS.from_user_input(('epsg', '4326'))
```


```python
print(f'crs1: {crs1}\ncrs2: {crs2}\ncrs3: {crs3}\ncrs4: {crs4}')
```

    crs1: EPSG:4326
    crs2: epsg:4326
    crs3: +proj=latlon +type=crs
    crs4: epsg:4326


## Перепроецирование объектов `shapely`

Для перепроецирования и пересчета координат из одной системы в другую для таких объектов следует использовать так называемые объекты-трансформеры из пакета `pyproj`, создаваемые функцией `Transformer.from_crs`.
Эти объекты рассчитывают параметры перехода от одной системы координат к другой и хранят их в себе. 
Однако для создания трансформера нужно указать как исходную, так и целевую системы координат.

Перепроецируем одну из созданных нами ранее точек в систему координат **UTM**.
Для этого нужно сначала рассчитать необходимый номер зоны и определить номер системы координат в реестре.


```python
import math
```


```python
def get_utm_zone(lon, lat):
    zone = int((lon + 180) / 6) + 1
    return f'EPSG:326{zone}' if lat >= 0 else f'EPSG:327{zone}'

```


```python
get_utm_zone(lon=pin_itmo.y , lat=pin_itmo.x)
```




    'EPSG:326417968'




```python
crs_itmo = CRS.from_epsg(32636)
```

Далее создадим объект трансформер.


```python
from pyproj import Transformer
```


```python
transformer = Transformer.from_crs(CRS.from_string("epsg:4326"), crs_itmo)

transformer
```




    <Conversion Transformer: pipeline>
    Description: UTM zone 36N
    Area of Use:
    - name: Between 30°E and 36°E, northern hemisphere between equator and 84°N, onshore and offshore.
    - bounds: (30.0, 0.0, 36.0, 84.0)



Рассчитаем новые координаты точки


```python
coords_utm_itmo = transformer.transform(pin_itmo.x, pin_itmo.y )
print(f'coords_utm_itmo: {coords_utm_itmo}. Тип объекта: {type(coords_utm_itmo)}')
```

    coords_utm_itmo: (347235.4179799134, 6648363.905023121). Тип объекта: <class 'tuple'>


В результате мы получили кортеж с координатами нашей точки, из которого уже можно создать пространственный объект.


```python
pin_itmo_utm = Point(coords_utm_itmo)

pin_itmo_utm.xy
```




    (array('d', [347235.4179799134]), array('d', [6648363.905023121]))



## Перепроецирование объектов `GeoDataFrame`

У объектов `GeoDataFrame` система координат является свойством самих объектов, как было уже показано выше.


```python
guerry.crs
```




    <Projected CRS: EPSG:27572>
    Name: NTF (Paris) / Lambert zone II
    Axis Info [cartesian]:
    - X[east]: Easting (metre)
    - Y[north]: Northing (metre)
    Area of Use:
    - name: France mainland onshore between 50.5 grads and 53.5 grads North (45°27'N to 48°09'N). Also used over all onshore mainland France.
    - bounds: (-4.87, 42.33, 8.23, 51.14)
    Coordinate Operation:
    - name: Lambert zone II
    - method: Lambert Conic Conformal (1SP)
    Datum: Nouvelle Triangulation Francaise (Paris)
    - Ellipsoid: Clarke 1880 (IGN)
    - Prime Meridian: Paris



Мы можем *назначить* новую систему координат, используя метод `.set_crs`.
Если у объекта уже есть система координат, тогда нужно использовать параметр `allow_override=True`, который позволить принудительно назначить новую систему координат. Если эту опцию не использовать в нашем случае мы получим ошибку.


```python
guerry.set_crs(4326)
```


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    Cell In[70], line 1
    ----> 1 guerry.set_crs(4326)


    File ~/.pyenv/versions/3.13.7/lib/python3.13/site-packages/geopandas/geodataframe.py:1741, in GeoDataFrame.set_crs(self, crs, epsg, inplace, allow_override)
       1739 else:
       1740     df = self
    -> 1741 df.geometry = df.geometry.set_crs(
       1742     crs=crs, epsg=epsg, allow_override=allow_override, inplace=True
       1743 )
       1744 return df


    File ~/.pyenv/versions/3.13.7/lib/python3.13/site-packages/geopandas/_compat.py:85, in requires_pyproj.<locals>.wrapper(*args, **kwargs)
         79 if not HAS_PYPROJ:
         80     raise ImportError(
         81         f"The 'pyproj' package is required for {func.__name__} to work. "
         82         "Install it and initialize the object with a CRS before using it."
         83         f"\nImporting pyproj resulted in: {pyproj_import_error}"
         84     )
    ---> 85 return func(*args, **kwargs)


    File ~/.pyenv/versions/3.13.7/lib/python3.13/site-packages/geopandas/geoseries.py:1161, in GeoSeries.set_crs(self, crs, epsg, inplace, allow_override)
       1158     crs = CRS.from_epsg(epsg)
       1160 if not allow_override and self.crs is not None and not self.crs == crs:
    -> 1161     raise ValueError(
       1162         "The GeoSeries already has a CRS which is not equal to the passed "
       1163         "CRS. Specify 'allow_override=True' to allow replacing the existing "
       1164         "CRS without doing any transformation. If you actually want to "
       1165         "transform the geometries, use 'GeoSeries.to_crs' instead."
       1166     )
       1167 if not inplace:
       1168     result = self.copy()


    ValueError: The GeoSeries already has a CRS which is not equal to the passed CRS. Specify 'allow_override=True' to allow replacing the existing CRS without doing any transformation. If you actually want to transform the geometries, use 'GeoSeries.to_crs' instead.



```python
guerry.set_crs(4326, allow_override=True)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>dept</th>
      <th>Region</th>
      <th>Dprtmnt</th>
      <th>Crm_prs</th>
      <th>Crm_prp</th>
      <th>Litercy</th>
      <th>Donatns</th>
      <th>Infants</th>
      <th>Suicids</th>
      <th>MainCty</th>
      <th>...</th>
      <th>Infntcd</th>
      <th>Dntn_cl</th>
      <th>Lottery</th>
      <th>Desertn</th>
      <th>Instrct</th>
      <th>Prsttts</th>
      <th>Distanc</th>
      <th>Area</th>
      <th>Pop1831</th>
      <th>geometry</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>S</td>
      <td>Ain</td>
      <td>28870.0</td>
      <td>15890.0</td>
      <td>37.0</td>
      <td>5098.0</td>
      <td>33120.0</td>
      <td>35039.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>60.0</td>
      <td>69.0</td>
      <td>41.0</td>
      <td>55.0</td>
      <td>46.0</td>
      <td>13.0</td>
      <td>218.372</td>
      <td>5762.0</td>
      <td>346.03</td>
      <td>POLYGON ((801150 2092615, 800669 2093190, 8006...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2.0</td>
      <td>S</td>
      <td>Aisne</td>
      <td>26226.0</td>
      <td>5521.0</td>
      <td>51.0</td>
      <td>8901.0</td>
      <td>14572.0</td>
      <td>12831.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>82.0</td>
      <td>36.0</td>
      <td>38.0</td>
      <td>82.0</td>
      <td>24.0</td>
      <td>327.0</td>
      <td>65.945</td>
      <td>7369.0</td>
      <td>513.00</td>
      <td>POLYGON ((729326 2521619, 729320 2521230, 7292...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3.0</td>
      <td>S</td>
      <td>Allier</td>
      <td>26747.0</td>
      <td>7925.0</td>
      <td>13.0</td>
      <td>10973.0</td>
      <td>17044.0</td>
      <td>114121.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>42.0</td>
      <td>76.0</td>
      <td>66.0</td>
      <td>16.0</td>
      <td>85.0</td>
      <td>34.0</td>
      <td>161.927</td>
      <td>7340.0</td>
      <td>298.26</td>
      <td>POLYGON ((710830 2137350, 711746 2136617, 7124...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.0</td>
      <td>S</td>
      <td>Basses-Alpes</td>
      <td>12935.0</td>
      <td>7289.0</td>
      <td>46.0</td>
      <td>2733.0</td>
      <td>23018.0</td>
      <td>14238.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>12.0</td>
      <td>37.0</td>
      <td>80.0</td>
      <td>32.0</td>
      <td>29.0</td>
      <td>2.0</td>
      <td>351.399</td>
      <td>6925.0</td>
      <td>155.90</td>
      <td>POLYGON ((882701 1920024, 882408 1920733, 8817...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>S</td>
      <td>Hautes-Alpes</td>
      <td>17488.0</td>
      <td>8174.0</td>
      <td>69.0</td>
      <td>6962.0</td>
      <td>23076.0</td>
      <td>16171.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>23.0</td>
      <td>64.0</td>
      <td>79.0</td>
      <td>35.0</td>
      <td>7.0</td>
      <td>1.0</td>
      <td>320.280</td>
      <td>5549.0</td>
      <td>129.10</td>
      <td>POLYGON ((886504 1922890, 885733 1922978, 8854...</td>
    </tr>
    <tr>
      <th>5</th>
      <td>7.0</td>
      <td>S</td>
      <td>Ardeche</td>
      <td>9474.0</td>
      <td>10263.0</td>
      <td>27.0</td>
      <td>3188.0</td>
      <td>42117.0</td>
      <td>52547.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>47.0</td>
      <td>67.0</td>
      <td>70.0</td>
      <td>19.0</td>
      <td>62.0</td>
      <td>1.0</td>
      <td>279.413</td>
      <td>5529.0</td>
      <td>340.73</td>
      <td>POLYGON ((747008 1925789, 746630 1925762, 7457...</td>
    </tr>
    <tr>
      <th>6</th>
      <td>8.0</td>
      <td>S</td>
      <td>Ardennes</td>
      <td>35203.0</td>
      <td>8847.0</td>
      <td>67.0</td>
      <td>6400.0</td>
      <td>16106.0</td>
      <td>26198.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>85.0</td>
      <td>49.0</td>
      <td>31.0</td>
      <td>62.0</td>
      <td>9.0</td>
      <td>83.0</td>
      <td>105.694</td>
      <td>5229.0</td>
      <td>289.62</td>
      <td>POLYGON ((818893 2514767, 818614 2514515, 8179...</td>
    </tr>
    <tr>
      <th>7</th>
      <td>9.0</td>
      <td>S</td>
      <td>Ariege</td>
      <td>6173.0</td>
      <td>9597.0</td>
      <td>18.0</td>
      <td>3542.0</td>
      <td>22916.0</td>
      <td>123625.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>28.0</td>
      <td>63.0</td>
      <td>75.0</td>
      <td>22.0</td>
      <td>77.0</td>
      <td>3.0</td>
      <td>385.313</td>
      <td>4890.0</td>
      <td>253.12</td>
      <td>POLYGON ((509103 1747787, 508820 1747513, 5081...</td>
    </tr>
    <tr>
      <th>8</th>
      <td>10.0</td>
      <td>S</td>
      <td>Aube</td>
      <td>19602.0</td>
      <td>4086.0</td>
      <td>59.0</td>
      <td>3608.0</td>
      <td>18642.0</td>
      <td>10989.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>54.0</td>
      <td>9.0</td>
      <td>28.0</td>
      <td>86.0</td>
      <td>15.0</td>
      <td>207.0</td>
      <td>83.244</td>
      <td>6004.0</td>
      <td>246.36</td>
      <td>POLYGON ((775400 2345600, 775068 2345397, 7735...</td>
    </tr>
    <tr>
      <th>9</th>
      <td>11.0</td>
      <td>S</td>
      <td>Aude</td>
      <td>15647.0</td>
      <td>10431.0</td>
      <td>34.0</td>
      <td>2582.0</td>
      <td>20225.0</td>
      <td>66498.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>35.0</td>
      <td>27.0</td>
      <td>50.0</td>
      <td>63.0</td>
      <td>48.0</td>
      <td>1.0</td>
      <td>370.949</td>
      <td>6139.0</td>
      <td>270.13</td>
      <td>POLYGON ((626230 1810121, 626269 1810496, 6274...</td>
    </tr>
    <tr>
      <th>10</th>
      <td>12.0</td>
      <td>S</td>
      <td>Aveyron</td>
      <td>8236.0</td>
      <td>6731.0</td>
      <td>31.0</td>
      <td>3211.0</td>
      <td>21981.0</td>
      <td>116671.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>5.0</td>
      <td>23.0</td>
      <td>81.0</td>
      <td>10.0</td>
      <td>44.0</td>
      <td>4.0</td>
      <td>296.089</td>
      <td>8735.0</td>
      <td>359.06</td>
      <td>POLYGON ((642972 1978185, 643791 1976549, 6444...</td>
    </tr>
    <tr>
      <th>11</th>
      <td>13.0</td>
      <td>S</td>
      <td>Bouches-du-Rhone</td>
      <td>13409.0</td>
      <td>5291.0</td>
      <td>38.0</td>
      <td>2314.0</td>
      <td>9325.0</td>
      <td>8107.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>74.0</td>
      <td>55.0</td>
      <td>3.0</td>
      <td>23.0</td>
      <td>43.0</td>
      <td>25.0</td>
      <td>362.568</td>
      <td>5087.0</td>
      <td>359.47</td>
      <td>POLYGON ((824692 1865875, 825615 1865409, 8259...</td>
    </tr>
    <tr>
      <th>12</th>
      <td>14.0</td>
      <td>S</td>
      <td>Calvados</td>
      <td>17577.0</td>
      <td>4500.0</td>
      <td>52.0</td>
      <td>27830.0</td>
      <td>8983.0</td>
      <td>31807.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>56.0</td>
      <td>11.0</td>
      <td>13.0</td>
      <td>12.0</td>
      <td>22.0</td>
      <td>194.0</td>
      <td>117.487</td>
      <td>5548.0</td>
      <td>494.70</td>
      <td>POLYGON ((345476 2429914, 345299 2430235, 3436...</td>
    </tr>
    <tr>
      <th>13</th>
      <td>15.0</td>
      <td>S</td>
      <td>Cantal</td>
      <td>18070.0</td>
      <td>11645.0</td>
      <td>31.0</td>
      <td>4093.0</td>
      <td>15335.0</td>
      <td>87338.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>83.0</td>
      <td>66.0</td>
      <td>82.0</td>
      <td>1.0</td>
      <td>51.0</td>
      <td>20.0</td>
      <td>245.849</td>
      <td>5726.0</td>
      <td>258.59</td>
      <td>POLYGON ((591653 2017934, 591727 2018244, 5918...</td>
    </tr>
    <tr>
      <th>14</th>
      <td>16.0</td>
      <td>S</td>
      <td>Charente</td>
      <td>24964.0</td>
      <td>13018.0</td>
      <td>36.0</td>
      <td>13602.0</td>
      <td>19454.0</td>
      <td>25720.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>7.0</td>
      <td>81.0</td>
      <td>60.0</td>
      <td>61.0</td>
      <td>47.0</td>
      <td>8.0</td>
      <td>224.339</td>
      <td>5956.0</td>
      <td>362.53</td>
      <td>POLYGON ((456425 2120055, 456229 2120382, 4559...</td>
    </tr>
    <tr>
      <th>15</th>
      <td>17.0</td>
      <td>S</td>
      <td>Charente-Inferieure</td>
      <td>18712.0</td>
      <td>5357.0</td>
      <td>39.0</td>
      <td>13254.0</td>
      <td>23999.0</td>
      <td>16798.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>38.0</td>
      <td>72.0</td>
      <td>35.0</td>
      <td>74.0</td>
      <td>42.0</td>
      <td>27.0</td>
      <td>238.538</td>
      <td>6864.0</td>
      <td>445.25</td>
      <td>MULTIPOLYGON (((328075 2118055, 327916 2118168...</td>
    </tr>
    <tr>
      <th>16</th>
      <td>18.0</td>
      <td>S</td>
      <td>Cher</td>
      <td>21934.0</td>
      <td>10503.0</td>
      <td>13.0</td>
      <td>9561.0</td>
      <td>23574.0</td>
      <td>19497.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>11.0</td>
      <td>86.0</td>
      <td>44.0</td>
      <td>51.0</td>
      <td>83.0</td>
      <td>26.0</td>
      <td>116.257</td>
      <td>7235.0</td>
      <td>256.06</td>
      <td>POLYGON ((572720 2252955, 574278 2251834, 5753...</td>
    </tr>
    <tr>
      <th>17</th>
      <td>19.0</td>
      <td>S</td>
      <td>Correze</td>
      <td>15262.0</td>
      <td>12949.0</td>
      <td>12.0</td>
      <td>14993.0</td>
      <td>19330.0</td>
      <td>47480.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>16.0</td>
      <td>82.0</td>
      <td>84.0</td>
      <td>2.0</td>
      <td>86.0</td>
      <td>3.0</td>
      <td>227.899</td>
      <td>5857.0</td>
      <td>294.83</td>
      <td>POLYGON ((608225 2042680, 608101 2042880, 6079...</td>
    </tr>
    <tr>
      <th>18</th>
      <td>21.0</td>
      <td>S</td>
      <td>Cote-d'Or</td>
      <td>32256.0</td>
      <td>9159.0</td>
      <td>60.0</td>
      <td>2540.0</td>
      <td>15599.0</td>
      <td>16128.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>27.0</td>
      <td>18.0</td>
      <td>33.0</td>
      <td>78.0</td>
      <td>13.0</td>
      <td>206.0</td>
      <td>136.109</td>
      <td>8763.0</td>
      <td>375.88</td>
      <td>MULTIPOLYGON (((738935 2236890, 738359 2237343...</td>
    </tr>
    <tr>
      <th>19</th>
      <td>22.0</td>
      <td>S</td>
      <td>Cotes-du-Nord</td>
      <td>28607.0</td>
      <td>7050.0</td>
      <td>16.0</td>
      <td>10387.0</td>
      <td>36098.0</td>
      <td>75056.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>69.0</td>
      <td>15.0</td>
      <td>72.0</td>
      <td>47.0</td>
      <td>80.0</td>
      <td>16.0</td>
      <td>225.161</td>
      <td>6878.0</td>
      <td>598.87</td>
      <td>MULTIPOLYGON (((208165 2439753, 208131 2439949...</td>
    </tr>
    <tr>
      <th>20</th>
      <td>23.0</td>
      <td>S</td>
      <td>Creuse</td>
      <td>37014.0</td>
      <td>20235.0</td>
      <td>23.0</td>
      <td>10997.0</td>
      <td>14363.0</td>
      <td>77823.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>24.0</td>
      <td>75.0</td>
      <td>85.0</td>
      <td>4.0</td>
      <td>71.0</td>
      <td>12.0</td>
      <td>180.846</td>
      <td>5565.0</td>
      <td>265.38</td>
      <td>POLYGON ((540175 2111095, 538135 2111105, 5380...</td>
    </tr>
    <tr>
      <th>21</th>
      <td>24.0</td>
      <td>S</td>
      <td>Dordogne</td>
      <td>21585.0</td>
      <td>10237.0</td>
      <td>18.0</td>
      <td>4687.0</td>
      <td>21375.0</td>
      <td>36024.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>18.0</td>
      <td>79.0</td>
      <td>77.0</td>
      <td>44.0</td>
      <td>78.0</td>
      <td>3.0</td>
      <td>253.776</td>
      <td>9060.0</td>
      <td>482.75</td>
      <td>POLYGON ((527718 1988833, 528808 1988071, 5291...</td>
    </tr>
    <tr>
      <th>22</th>
      <td>25.0</td>
      <td>S</td>
      <td>Doubs</td>
      <td>11560.0</td>
      <td>5914.0</td>
      <td>73.0</td>
      <td>3436.0</td>
      <td>12512.0</td>
      <td>40690.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>25.0</td>
      <td>6.0</td>
      <td>18.0</td>
      <td>73.0</td>
      <td>2.0</td>
      <td>65.0</td>
      <td>202.065</td>
      <td>5234.0</td>
      <td>265.54</td>
      <td>POLYGON ((886630 2188665, 886948 2188898, 8879...</td>
    </tr>
    <tr>
      <th>23</th>
      <td>26.0</td>
      <td>S</td>
      <td>Drome</td>
      <td>13396.0</td>
      <td>7759.0</td>
      <td>42.0</td>
      <td>2829.0</td>
      <td>16348.0</td>
      <td>23816.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>13.0</td>
      <td>62.0</td>
      <td>54.0</td>
      <td>46.0</td>
      <td>38.0</td>
      <td>8.0</td>
      <td>295.543</td>
      <td>6530.0</td>
      <td>299.56</td>
      <td>POLYGON ((830803 2010472, 831288 2010361, 8315...</td>
    </tr>
    <tr>
      <th>24</th>
      <td>27.0</td>
      <td>S</td>
      <td>Eure</td>
      <td>14795.0</td>
      <td>4774.0</td>
      <td>51.0</td>
      <td>11712.0</td>
      <td>16039.0</td>
      <td>13493.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>45.0</td>
      <td>45.0</td>
      <td>47.0</td>
      <td>27.0</td>
      <td>23.0</td>
      <td>179.0</td>
      <td>61.863</td>
      <td>6040.0</td>
      <td>424.25</td>
      <td>POLYGON ((515046 2482676, 515755 2483384, 5160...</td>
    </tr>
    <tr>
      <th>25</th>
      <td>28.0</td>
      <td>S</td>
      <td>Eure-et-Loir</td>
      <td>21368.0</td>
      <td>4016.0</td>
      <td>54.0</td>
      <td>4553.0</td>
      <td>14475.0</td>
      <td>15015.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>62.0</td>
      <td>14.0</td>
      <td>48.0</td>
      <td>72.0</td>
      <td>18.0</td>
      <td>180.0</td>
      <td>54.558</td>
      <td>5880.0</td>
      <td>278.82</td>
      <td>POLYGON ((562860 2342515, 562499 2342577, 5602...</td>
    </tr>
    <tr>
      <th>26</th>
      <td>29.0</td>
      <td>S</td>
      <td>Finistere</td>
      <td>29872.0</td>
      <td>6842.0</td>
      <td>15.0</td>
      <td>23945.0</td>
      <td>28392.0</td>
      <td>25143.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>78.0</td>
      <td>25.0</td>
      <td>36.0</td>
      <td>77.0</td>
      <td>81.0</td>
      <td>42.0</td>
      <td>276.210</td>
      <td>6733.0</td>
      <td>524.40</td>
      <td>MULTIPOLYGON (((134794 2434061, 134532 2434541...</td>
    </tr>
    <tr>
      <th>27</th>
      <td>30.0</td>
      <td>S</td>
      <td>Gard</td>
      <td>13115.0</td>
      <td>7990.0</td>
      <td>40.0</td>
      <td>3048.0</td>
      <td>28726.0</td>
      <td>18292.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>39.0</td>
      <td>59.0</td>
      <td>20.0</td>
      <td>40.0</td>
      <td>40.0</td>
      <td>5.0</td>
      <td>323.004</td>
      <td>5853.0</td>
      <td>357.38</td>
      <td>POLYGON ((719592 1880745, 719924 1881419, 7194...</td>
    </tr>
    <tr>
      <th>28</th>
      <td>31.0</td>
      <td>S</td>
      <td>Haute-Garonne</td>
      <td>18642.0</td>
      <td>7204.0</td>
      <td>31.0</td>
      <td>2286.0</td>
      <td>15378.0</td>
      <td>56140.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>59.0</td>
      <td>13.0</td>
      <td>25.0</td>
      <td>15.0</td>
      <td>33.0</td>
      <td>8.0</td>
      <td>361.668</td>
      <td>6257.0</td>
      <td>427.86</td>
      <td>POLYGON ((491745 1820323, 491926 1820668, 4914...</td>
    </tr>
    <tr>
      <th>29</th>
      <td>32.0</td>
      <td>S</td>
      <td>Gers</td>
      <td>18642.0</td>
      <td>10486.0</td>
      <td>38.0</td>
      <td>2848.0</td>
      <td>15250.0</td>
      <td>61510.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>13.0</td>
      <td>32.0</td>
      <td>74.0</td>
      <td>30.0</td>
      <td>44.0</td>
      <td>1.0</td>
      <td>343.569</td>
      <td>6309.0</td>
      <td>312.16</td>
      <td>POLYGON ((447673 1816738, 447362 1816893, 4463...</td>
    </tr>
    <tr>
      <th>30</th>
      <td>33.0</td>
      <td>S</td>
      <td>Gironde</td>
      <td>24096.0</td>
      <td>7423.0</td>
      <td>40.0</td>
      <td>5076.0</td>
      <td>10676.0</td>
      <td>19220.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>80.0</td>
      <td>48.0</td>
      <td>4.0</td>
      <td>13.0</td>
      <td>41.0</td>
      <td>39.0</td>
      <td>291.624</td>
      <td>10000.0</td>
      <td>554.23</td>
      <td>MULTIPOLYGON (((332874 1966651, 332777 1966980...</td>
    </tr>
    <tr>
      <th>31</th>
      <td>34.0</td>
      <td>S</td>
      <td>Herault</td>
      <td>12814.0</td>
      <td>10954.0</td>
      <td>45.0</td>
      <td>1680.0</td>
      <td>21346.0</td>
      <td>30869.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>51.0</td>
      <td>28.0</td>
      <td>19.0</td>
      <td>43.0</td>
      <td>32.0</td>
      <td>9.0</td>
      <td>344.030</td>
      <td>6101.0</td>
      <td>346.30</td>
      <td>POLYGON ((739523 1864067, 740853 1864454, 7414...</td>
    </tr>
    <tr>
      <th>32</th>
      <td>35.0</td>
      <td>S</td>
      <td>Ille-et-Vilaine</td>
      <td>22138.0</td>
      <td>6524.0</td>
      <td>25.0</td>
      <td>7686.0</td>
      <td>40736.0</td>
      <td>45180.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>31.0</td>
      <td>22.0</td>
      <td>37.0</td>
      <td>50.0</td>
      <td>66.0</td>
      <td>77.0</td>
      <td>179.379</td>
      <td>6775.0</td>
      <td>547.05</td>
      <td>MULTIPOLYGON (((271910 2322460, 272047 2322795...</td>
    </tr>
    <tr>
      <th>33</th>
      <td>36.0</td>
      <td>S</td>
      <td>Indre</td>
      <td>32404.0</td>
      <td>7624.0</td>
      <td>17.0</td>
      <td>11315.0</td>
      <td>20046.0</td>
      <td>25014.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>19.0</td>
      <td>83.0</td>
      <td>69.0</td>
      <td>29.0</td>
      <td>79.0</td>
      <td>14.0</td>
      <td>139.587</td>
      <td>6791.0</td>
      <td>245.29</td>
      <td>POLYGON ((573430 2159520, 573109 2159583, 5726...</td>
    </tr>
    <tr>
      <th>34</th>
      <td>37.0</td>
      <td>S</td>
      <td>Indre-et-Loire</td>
      <td>19131.0</td>
      <td>6909.0</td>
      <td>27.0</td>
      <td>7254.0</td>
      <td>16601.0</td>
      <td>15272.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>3.0</td>
      <td>41.0</td>
      <td>15.0</td>
      <td>49.0</td>
      <td>63.0</td>
      <td>59.0</td>
      <td>126.468</td>
      <td>6127.0</td>
      <td>297.02</td>
      <td>POLYGON ((505590 2270755, 507478 2268385, 5076...</td>
    </tr>
    <tr>
      <th>35</th>
      <td>38.0</td>
      <td>S</td>
      <td>Isere</td>
      <td>18785.0</td>
      <td>8326.0</td>
      <td>29.0</td>
      <td>4077.0</td>
      <td>12236.0</td>
      <td>36275.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>27.0</td>
      <td>73.0</td>
      <td>23.0</td>
      <td>26.0</td>
      <td>57.0</td>
      <td>12.0</td>
      <td>268.661</td>
      <td>7431.0</td>
      <td>550.26</td>
      <td>POLYGON ((839825 2094355, 840895 2093318, 8411...</td>
    </tr>
    <tr>
      <th>36</th>
      <td>39.0</td>
      <td>S</td>
      <td>Jura</td>
      <td>26221.0</td>
      <td>8059.0</td>
      <td>73.0</td>
      <td>3012.0</td>
      <td>20384.0</td>
      <td>34476.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>66.0</td>
      <td>43.0</td>
      <td>39.0</td>
      <td>71.0</td>
      <td>3.0</td>
      <td>32.0</td>
      <td>197.155</td>
      <td>4999.0</td>
      <td>312.50</td>
      <td>MULTIPOLYGON (((836965 2209730, 836855 2209785...</td>
    </tr>
    <tr>
      <th>37</th>
      <td>40.0</td>
      <td>S</td>
      <td>Landes</td>
      <td>17687.0</td>
      <td>6170.0</td>
      <td>28.0</td>
      <td>12059.0</td>
      <td>15302.0</td>
      <td>35375.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>43.0</td>
      <td>56.0</td>
      <td>73.0</td>
      <td>28.0</td>
      <td>58.0</td>
      <td>3.0</td>
      <td>344.676</td>
      <td>9243.0</td>
      <td>281.50</td>
      <td>POLYGON ((311864 1932711, 314132 1946872, 3141...</td>
    </tr>
    <tr>
      <th>38</th>
      <td>41.0</td>
      <td>S</td>
      <td>Loir-et-Cher</td>
      <td>21292.0</td>
      <td>6017.0</td>
      <td>27.0</td>
      <td>5626.0</td>
      <td>13364.0</td>
      <td>14417.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>37.0</td>
      <td>70.0</td>
      <td>46.0</td>
      <td>54.0</td>
      <td>61.0</td>
      <td>54.0</td>
      <td>90.735</td>
      <td>6343.0</td>
      <td>235.75</td>
      <td>POLYGON ((519655 2330465, 520005 2329830, 5225...</td>
    </tr>
    <tr>
      <th>39</th>
      <td>42.0</td>
      <td>S</td>
      <td>Loire</td>
      <td>27491.0</td>
      <td>12665.0</td>
      <td>29.0</td>
      <td>3446.0</td>
      <td>29605.0</td>
      <td>71364.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>77.0</td>
      <td>34.0</td>
      <td>42.0</td>
      <td>6.0</td>
      <td>56.0</td>
      <td>14.0</td>
      <td>215.598</td>
      <td>4781.0</td>
      <td>391.22</td>
      <td>POLYGON ((732285 2132610, 732782 2133196, 7330...</td>
    </tr>
    <tr>
      <th>40</th>
      <td>43.0</td>
      <td>S</td>
      <td>Haute-Loire</td>
      <td>16170.0</td>
      <td>18043.0</td>
      <td>21.0</td>
      <td>2746.0</td>
      <td>31017.0</td>
      <td>163241.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>17.0</td>
      <td>65.0</td>
      <td>62.0</td>
      <td>3.0</td>
      <td>72.0</td>
      <td>10.0</td>
      <td>248.877</td>
      <td>4977.0</td>
      <td>292.08</td>
      <td>POLYGON ((742975 2044820, 744433 2045165, 7460...</td>
    </tr>
    <tr>
      <th>41</th>
      <td>44.0</td>
      <td>S</td>
      <td>Loire-Inferieure</td>
      <td>19314.0</td>
      <td>9392.0</td>
      <td>24.0</td>
      <td>8310.0</td>
      <td>14097.0</td>
      <td>27289.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>52.0</td>
      <td>29.0</td>
      <td>12.0</td>
      <td>45.0</td>
      <td>67.0</td>
      <td>63.0</td>
      <td>199.167</td>
      <td>6815.0</td>
      <td>470.09</td>
      <td>POLYGON ((268705 2263645, 268976 2263891, 2710...</td>
    </tr>
    <tr>
      <th>42</th>
      <td>45.0</td>
      <td>S</td>
      <td>Loiret</td>
      <td>17722.0</td>
      <td>5042.0</td>
      <td>42.0</td>
      <td>4753.0</td>
      <td>9986.0</td>
      <td>11813.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>22.0</td>
      <td>16.0</td>
      <td>17.0</td>
      <td>60.0</td>
      <td>37.0</td>
      <td>256.0</td>
      <td>61.106</td>
      <td>6775.0</td>
      <td>305.28</td>
      <td>POLYGON ((557890 2341355, 558382 2341921, 5598...</td>
    </tr>
    <tr>
      <th>43</th>
      <td>46.0</td>
      <td>S</td>
      <td>Lot</td>
      <td>5883.0</td>
      <td>9049.0</td>
      <td>24.0</td>
      <td>5194.0</td>
      <td>20383.0</td>
      <td>48783.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>15.0</td>
      <td>68.0</td>
      <td>78.0</td>
      <td>24.0</td>
      <td>68.0</td>
      <td>1.0</td>
      <td>275.725</td>
      <td>5217.0</td>
      <td>283.83</td>
      <td>POLYGON ((503966 1958060, 505528 1959658, 5058...</td>
    </tr>
    <tr>
      <th>44</th>
      <td>47.0</td>
      <td>S</td>
      <td>Lot-et-Garonne</td>
      <td>22969.0</td>
      <td>8943.0</td>
      <td>31.0</td>
      <td>4432.0</td>
      <td>17681.0</td>
      <td>38501.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>32.0</td>
      <td>46.0</td>
      <td>52.0</td>
      <td>34.0</td>
      <td>50.0</td>
      <td>5.0</td>
      <td>302.345</td>
      <td>5361.0</td>
      <td>346.89</td>
      <td>POLYGON ((413714 1942691, 413362 1942587, 4128...</td>
    </tr>
    <tr>
      <th>45</th>
      <td>48.0</td>
      <td>S</td>
      <td>Lozere</td>
      <td>7710.0</td>
      <td>5990.0</td>
      <td>27.0</td>
      <td>2040.0</td>
      <td>25157.0</td>
      <td>11092.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>45.0</td>
      <td>42.0</td>
      <td>86.0</td>
      <td>5.0</td>
      <td>60.0</td>
      <td>0.0</td>
      <td>283.810</td>
      <td>5167.0</td>
      <td>140.35</td>
      <td>POLYGON ((702442 1987131, 703082 1987282, 7033...</td>
    </tr>
    <tr>
      <th>46</th>
      <td>49.0</td>
      <td>S</td>
      <td>Maine-et-Loire</td>
      <td>29692.0</td>
      <td>8520.0</td>
      <td>23.0</td>
      <td>4410.0</td>
      <td>18708.0</td>
      <td>33358.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>36.0</td>
      <td>20.0</td>
      <td>24.0</td>
      <td>76.0</td>
      <td>70.0</td>
      <td>35.0</td>
      <td>157.437</td>
      <td>7166.0</td>
      <td>467.87</td>
      <td>POLYGON ((409765 2298980, 409716 2297568, 4099...</td>
    </tr>
    <tr>
      <th>47</th>
      <td>50.0</td>
      <td>S</td>
      <td>Manche</td>
      <td>31078.0</td>
      <td>7424.0</td>
      <td>43.0</td>
      <td>5179.0</td>
      <td>14281.0</td>
      <td>55564.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>70.0</td>
      <td>3.0</td>
      <td>59.0</td>
      <td>21.0</td>
      <td>36.0</td>
      <td>98.0</td>
      <td>157.187</td>
      <td>5938.0</td>
      <td>591.28</td>
      <td>MULTIPOLYGON (((316425 2410987, 316287 2411065...</td>
    </tr>
    <tr>
      <th>48</th>
      <td>51.0</td>
      <td>S</td>
      <td>Marne</td>
      <td>15602.0</td>
      <td>4950.0</td>
      <td>63.0</td>
      <td>3963.0</td>
      <td>11267.0</td>
      <td>8334.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>58.0</td>
      <td>39.0</td>
      <td>22.0</td>
      <td>81.0</td>
      <td>10.0</td>
      <td>262.0</td>
      <td>77.364</td>
      <td>6211.0</td>
      <td>337.08</td>
      <td>POLYGON ((781920 2395187, 781562 2395133, 7809...</td>
    </tr>
    <tr>
      <th>49</th>
      <td>52.0</td>
      <td>S</td>
      <td>Haute-Marne</td>
      <td>26231.0</td>
      <td>9539.0</td>
      <td>72.0</td>
      <td>4013.0</td>
      <td>17507.0</td>
      <td>19586.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>55.0</td>
      <td>4.0</td>
      <td>56.0</td>
      <td>65.0</td>
      <td>4.0</td>
      <td>138.0</td>
      <td>129.765</td>
      <td>8162.0</td>
      <td>249.83</td>
      <td>POLYGON ((776565 2346640, 776344 2346943, 7780...</td>
    </tr>
    <tr>
      <th>50</th>
      <td>53.0</td>
      <td>S</td>
      <td>Mayenne</td>
      <td>28331.0</td>
      <td>9198.0</td>
      <td>19.0</td>
      <td>2107.0</td>
      <td>18544.0</td>
      <td>28331.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>40.0</td>
      <td>8.0</td>
      <td>61.0</td>
      <td>58.0</td>
      <td>75.0</td>
      <td>46.0</td>
      <td>139.999</td>
      <td>5175.0</td>
      <td>352.59</td>
      <td>POLYGON ((394355 2321180, 394249 2320876, 3943...</td>
    </tr>
    <tr>
      <th>51</th>
      <td>54.0</td>
      <td>S</td>
      <td>Meurthe</td>
      <td>26674.0</td>
      <td>6831.0</td>
      <td>68.0</td>
      <td>3912.0</td>
      <td>12355.0</td>
      <td>15652.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>71.0</td>
      <td>1.0</td>
      <td>21.0</td>
      <td>70.0</td>
      <td>8.0</td>
      <td>154.0</td>
      <td>159.648</td>
      <td>5241.0</td>
      <td>415.57</td>
      <td>MULTIPOLYGON (((826186 2502671, 825892 2502926...</td>
    </tr>
    <tr>
      <th>52</th>
      <td>55.0</td>
      <td>S</td>
      <td>Meuse</td>
      <td>24507.0</td>
      <td>9190.0</td>
      <td>74.0</td>
      <td>4196.0</td>
      <td>17333.0</td>
      <td>13463.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>65.0</td>
      <td>12.0</td>
      <td>58.0</td>
      <td>59.0</td>
      <td>1.0</td>
      <td>131.0</td>
      <td>126.378</td>
      <td>6216.0</td>
      <td>314.59</td>
      <td>POLYGON ((853530 2462643, 853898 2462654, 8542...</td>
    </tr>
    <tr>
      <th>53</th>
      <td>56.0</td>
      <td>S</td>
      <td>Morbihan</td>
      <td>23316.0</td>
      <td>7940.0</td>
      <td>14.0</td>
      <td>14739.0</td>
      <td>31754.0</td>
      <td>34196.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>29.0</td>
      <td>7.0</td>
      <td>32.0</td>
      <td>69.0</td>
      <td>82.0</td>
      <td>38.0</td>
      <td>230.531</td>
      <td>6823.0</td>
      <td>433.52</td>
      <td>MULTIPOLYGON (((167530 2307010, 167140 2307457...</td>
    </tr>
    <tr>
      <th>54</th>
      <td>57.0</td>
      <td>S</td>
      <td>Moselle</td>
      <td>12153.0</td>
      <td>4529.0</td>
      <td>57.0</td>
      <td>9515.0</td>
      <td>13877.0</td>
      <td>25572.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>9.0</td>
      <td>2.0</td>
      <td>16.0</td>
      <td>68.0</td>
      <td>16.0</td>
      <td>165.0</td>
      <td>180.462</td>
      <td>6216.0</td>
      <td>417.00</td>
      <td>POLYGON ((929062 2475639, 929093 2476415, 9280...</td>
    </tr>
    <tr>
      <th>55</th>
      <td>58.0</td>
      <td>S</td>
      <td>Nievre</td>
      <td>25087.0</td>
      <td>8236.0</td>
      <td>20.0</td>
      <td>10452.0</td>
      <td>19747.0</td>
      <td>29381.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>20.0</td>
      <td>80.0</td>
      <td>63.0</td>
      <td>37.0</td>
      <td>74.0</td>
      <td>39.0</td>
      <td>119.718</td>
      <td>6817.0</td>
      <td>282.52</td>
      <td>POLYGON ((715920 2264185, 717135 2264065, 7172...</td>
    </tr>
    <tr>
      <th>56</th>
      <td>59.0</td>
      <td>S</td>
      <td>Nord</td>
      <td>26740.0</td>
      <td>6175.0</td>
      <td>45.0</td>
      <td>6092.0</td>
      <td>8926.0</td>
      <td>13851.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>81.0</td>
      <td>38.0</td>
      <td>7.0</td>
      <td>64.0</td>
      <td>30.0</td>
      <td>308.0</td>
      <td>106.335</td>
      <td>5743.0</td>
      <td>989.94</td>
      <td>MULTIPOLYGON (((664166 2630647, 664342 2629299...</td>
    </tr>
    <tr>
      <th>57</th>
      <td>60.0</td>
      <td>S</td>
      <td>Oise</td>
      <td>28180.0</td>
      <td>6659.0</td>
      <td>54.0</td>
      <td>5501.0</td>
      <td>18021.0</td>
      <td>5994.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>86.0</td>
      <td>50.0</td>
      <td>43.0</td>
      <td>57.0</td>
      <td>20.0</td>
      <td>337.0</td>
      <td>33.768</td>
      <td>5860.0</td>
      <td>397.73</td>
      <td>MULTIPOLYGON (((647667 2468296, 647542 2468371...</td>
    </tr>
    <tr>
      <th>58</th>
      <td>61.0</td>
      <td>S</td>
      <td>Orne</td>
      <td>28329.0</td>
      <td>8248.0</td>
      <td>45.0</td>
      <td>9242.0</td>
      <td>20852.0</td>
      <td>34069.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>50.0</td>
      <td>31.0</td>
      <td>57.0</td>
      <td>25.0</td>
      <td>33.0</td>
      <td>117.0</td>
      <td>97.554</td>
      <td>6103.0</td>
      <td>441.88</td>
      <td>POLYGON ((469173 2432434, 470681 2434059, 4709...</td>
    </tr>
    <tr>
      <th>59</th>
      <td>62.0</td>
      <td>S</td>
      <td>Pas-de-Calais</td>
      <td>23101.0</td>
      <td>4040.0</td>
      <td>49.0</td>
      <td>5740.0</td>
      <td>10575.0</td>
      <td>15400.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>79.0</td>
      <td>10.0</td>
      <td>27.0</td>
      <td>48.0</td>
      <td>26.0</td>
      <td>163.0</td>
      <td>104.400</td>
      <td>6671.0</td>
      <td>655.22</td>
      <td>POLYGON ((629822 2560555, 629583 2560843, 6291...</td>
    </tr>
    <tr>
      <th>60</th>
      <td>63.0</td>
      <td>S</td>
      <td>Puy-de-Dome</td>
      <td>17256.0</td>
      <td>12141.0</td>
      <td>19.0</td>
      <td>5963.0</td>
      <td>22948.0</td>
      <td>78148.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>63.0</td>
      <td>61.0</td>
      <td>53.0</td>
      <td>8.0</td>
      <td>76.0</td>
      <td>62.0</td>
      <td>205.218</td>
      <td>7970.0</td>
      <td>573.11</td>
      <td>POLYGON ((615585 2050805, 615649 2051154, 6162...</td>
    </tr>
    <tr>
      <th>61</th>
      <td>64.0</td>
      <td>S</td>
      <td>Basses-Pyrenees</td>
      <td>16722.0</td>
      <td>8533.0</td>
      <td>47.0</td>
      <td>3299.0</td>
      <td>12393.0</td>
      <td>65995.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>72.0</td>
      <td>60.0</td>
      <td>34.0</td>
      <td>7.0</td>
      <td>28.0</td>
      <td>12.0</td>
      <td>387.935</td>
      <td>7645.0</td>
      <td>428.40</td>
      <td>POLYGON ((386095 1774604, 386085 1774237, 3855...</td>
    </tr>
    <tr>
      <th>62</th>
      <td>65.0</td>
      <td>S</td>
      <td>Hautes-Pyrenees</td>
      <td>12223.0</td>
      <td>9797.0</td>
      <td>53.0</td>
      <td>6001.0</td>
      <td>12125.0</td>
      <td>148039.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>75.0</td>
      <td>71.0</td>
      <td>76.0</td>
      <td>20.0</td>
      <td>21.0</td>
      <td>5.0</td>
      <td>386.559</td>
      <td>4464.0</td>
      <td>233.03</td>
      <td>MULTIPOLYGON (((406987 1826038, 405019 1826121...</td>
    </tr>
    <tr>
      <th>63</th>
      <td>66.0</td>
      <td>S</td>
      <td>Pyrenees-Orientales</td>
      <td>6728.0</td>
      <td>7632.0</td>
      <td>31.0</td>
      <td>11644.0</td>
      <td>15167.0</td>
      <td>37843.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>84.0</td>
      <td>77.0</td>
      <td>11.0</td>
      <td>18.0</td>
      <td>52.0</td>
      <td>5.0</td>
      <td>403.445</td>
      <td>4116.0</td>
      <td>157.05</td>
      <td>POLYGON ((658127 1733192, 658228 1732843, 6582...</td>
    </tr>
    <tr>
      <th>64</th>
      <td>67.0</td>
      <td>S</td>
      <td>Bas-Rhin</td>
      <td>12309.0</td>
      <td>4920.0</td>
      <td>62.0</td>
      <td>14472.0</td>
      <td>14356.0</td>
      <td>18623.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>48.0</td>
      <td>51.0</td>
      <td>5.0</td>
      <td>53.0</td>
      <td>12.0</td>
      <td>101.0</td>
      <td>217.752</td>
      <td>4755.0</td>
      <td>540.21</td>
      <td>POLYGON ((946663 2460717, 946292 2461188, 9461...</td>
    </tr>
    <tr>
      <th>65</th>
      <td>68.0</td>
      <td>S</td>
      <td>Haut-Rhin</td>
      <td>7343.0</td>
      <td>4915.0</td>
      <td>71.0</td>
      <td>6001.0</td>
      <td>14783.0</td>
      <td>21233.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>53.0</td>
      <td>17.0</td>
      <td>10.0</td>
      <td>56.0</td>
      <td>5.0</td>
      <td>26.0</td>
      <td>217.971</td>
      <td>3525.0</td>
      <td>424.26</td>
      <td>POLYGON ((989865 2319005, 990659 2316949, 9900...</td>
    </tr>
    <tr>
      <th>66</th>
      <td>69.0</td>
      <td>S</td>
      <td>Rhone</td>
      <td>18793.0</td>
      <td>4504.0</td>
      <td>45.0</td>
      <td>1983.0</td>
      <td>3910.0</td>
      <td>17003.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>33.0</td>
      <td>21.0</td>
      <td>2.0</td>
      <td>14.0</td>
      <td>31.0</td>
      <td>104.0</td>
      <td>213.032</td>
      <td>3249.0</td>
      <td>434.43</td>
      <td>POLYGON ((752410 2115380, 752067 2115294, 7510...</td>
    </tr>
    <tr>
      <th>67</th>
      <td>70.0</td>
      <td>S</td>
      <td>Haute-Saone</td>
      <td>22339.0</td>
      <td>7770.0</td>
      <td>59.0</td>
      <td>11701.0</td>
      <td>11850.0</td>
      <td>39714.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>68.0</td>
      <td>57.0</td>
      <td>65.0</td>
      <td>83.0</td>
      <td>14.0</td>
      <td>99.0</td>
      <td>176.135</td>
      <td>5360.0</td>
      <td>338.91</td>
      <td>POLYGON ((933555 2291420, 933269 2291556, 9326...</td>
    </tr>
    <tr>
      <th>68</th>
      <td>71.0</td>
      <td>S</td>
      <td>Saone-et-Loire</td>
      <td>28391.0</td>
      <td>10708.0</td>
      <td>32.0</td>
      <td>3710.0</td>
      <td>20442.0</td>
      <td>22184.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>10.0</td>
      <td>58.0</td>
      <td>45.0</td>
      <td>31.0</td>
      <td>49.0</td>
      <td>40.0</td>
      <td>168.713</td>
      <td>8575.0</td>
      <td>523.97</td>
      <td>POLYGON ((834930 2207585, 834681 2207740, 8344...</td>
    </tr>
    <tr>
      <th>69</th>
      <td>72.0</td>
      <td>S</td>
      <td>Sarthe</td>
      <td>33913.0</td>
      <td>8294.0</td>
      <td>30.0</td>
      <td>3357.0</td>
      <td>10779.0</td>
      <td>29280.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>57.0</td>
      <td>19.0</td>
      <td>49.0</td>
      <td>75.0</td>
      <td>35.0</td>
      <td>79.0</td>
      <td>108.294</td>
      <td>6206.0</td>
      <td>457.37</td>
      <td>POLYGON ((470543 2362046, 471980 2361813, 4726...</td>
    </tr>
    <tr>
      <th>70</th>
      <td>75.0</td>
      <td>S</td>
      <td>Seine</td>
      <td>13945.0</td>
      <td>1368.0</td>
      <td>71.0</td>
      <td>4204.0</td>
      <td>2660.0</td>
      <td>3632.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>67.0</td>
      <td>53.0</td>
      <td>1.0</td>
      <td>33.0</td>
      <td>6.0</td>
      <td>4744.0</td>
      <td>0.000</td>
      <td>762.0</td>
      <td>935.11</td>
      <td>POLYGON ((615302 2411120, 615000 2411180, 6143...</td>
    </tr>
    <tr>
      <th>71</th>
      <td>76.0</td>
      <td>S</td>
      <td>Seine-Inferieure</td>
      <td>18355.0</td>
      <td>2906.0</td>
      <td>43.0</td>
      <td>7245.0</td>
      <td>7506.0</td>
      <td>9523.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>61.0</td>
      <td>74.0</td>
      <td>9.0</td>
      <td>36.0</td>
      <td>35.0</td>
      <td>546.0</td>
      <td>75.658</td>
      <td>6278.0</td>
      <td>693.68</td>
      <td>POLYGON ((438965 2512493, 440124 2514448, 4402...</td>
    </tr>
    <tr>
      <th>72</th>
      <td>77.0</td>
      <td>S</td>
      <td>Seine-et-Marne</td>
      <td>22201.0</td>
      <td>5786.0</td>
      <td>54.0</td>
      <td>5303.0</td>
      <td>16324.0</td>
      <td>7315.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>73.0</td>
      <td>26.0</td>
      <td>29.0</td>
      <td>67.0</td>
      <td>37.0</td>
      <td>453.0</td>
      <td>27.647</td>
      <td>5915.0</td>
      <td>323.89</td>
      <td>POLYGON ((675580 2375994, 675218 2376008, 6748...</td>
    </tr>
    <tr>
      <th>73</th>
      <td>78.0</td>
      <td>S</td>
      <td>Seine-et-Oise</td>
      <td>12477.0</td>
      <td>3879.0</td>
      <td>56.0</td>
      <td>4007.0</td>
      <td>16303.0</td>
      <td>3460.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>30.0</td>
      <td>24.0</td>
      <td>6.0</td>
      <td>42.0</td>
      <td>17.0</td>
      <td>874.0</td>
      <td>16.888</td>
      <td>5334.0</td>
      <td>448.18</td>
      <td>POLYGON ((546799 2453567, 547588 2454258, 5478...</td>
    </tr>
    <tr>
      <th>74</th>
      <td>79.0</td>
      <td>S</td>
      <td>Deux-Sevres</td>
      <td>18400.0</td>
      <td>6863.0</td>
      <td>41.0</td>
      <td>16956.0</td>
      <td>25461.0</td>
      <td>24533.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>4.0</td>
      <td>85.0</td>
      <td>71.0</td>
      <td>84.0</td>
      <td>39.0</td>
      <td>6.0</td>
      <td>188.474</td>
      <td>5999.0</td>
      <td>297.85</td>
      <td>POLYGON ((419808 2218480, 420449 2218054, 4209...</td>
    </tr>
    <tr>
      <th>75</th>
      <td>80.0</td>
      <td>S</td>
      <td>Somme</td>
      <td>33592.0</td>
      <td>7144.0</td>
      <td>44.0</td>
      <td>4964.0</td>
      <td>12447.0</td>
      <td>12836.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>64.0</td>
      <td>33.0</td>
      <td>30.0</td>
      <td>80.0</td>
      <td>34.0</td>
      <td>302.0</td>
      <td>69.520</td>
      <td>6170.0</td>
      <td>543.70</td>
      <td>POLYGON ((543667 2592806, 544247 2596216, 5451...</td>
    </tr>
    <tr>
      <th>76</th>
      <td>81.0</td>
      <td>S</td>
      <td>Tarn</td>
      <td>13019.0</td>
      <td>6241.0</td>
      <td>20.0</td>
      <td>3449.0</td>
      <td>29305.0</td>
      <td>68980.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>9.0</td>
      <td>47.0</td>
      <td>67.0</td>
      <td>17.0</td>
      <td>73.0</td>
      <td>3.0</td>
      <td>328.146</td>
      <td>5758.0</td>
      <td>333.84</td>
      <td>POLYGON ((548083 1858875, 547740 1858741, 5469...</td>
    </tr>
    <tr>
      <th>77</th>
      <td>82.0</td>
      <td>S</td>
      <td>Tarn-et-Garonne</td>
      <td>14790.0</td>
      <td>8680.0</td>
      <td>25.0</td>
      <td>4558.0</td>
      <td>23771.0</td>
      <td>48317.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>41.0</td>
      <td>52.0</td>
      <td>64.0</td>
      <td>39.0</td>
      <td>64.0</td>
      <td>4.0</td>
      <td>313.090</td>
      <td>3718.0</td>
      <td>242.51</td>
      <td>POLYGON ((572261 1905414, 571717 1905736, 5705...</td>
    </tr>
    <tr>
      <th>78</th>
      <td>83.0</td>
      <td>S</td>
      <td>Var</td>
      <td>13145.0</td>
      <td>9572.0</td>
      <td>23.0</td>
      <td>2449.0</td>
      <td>14800.0</td>
      <td>13380.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>49.0</td>
      <td>40.0</td>
      <td>26.0</td>
      <td>52.0</td>
      <td>69.0</td>
      <td>6.0</td>
      <td>389.512</td>
      <td>5973.0</td>
      <td>317.50</td>
      <td>MULTIPOLYGON (((937679 1788572, 937646 1788379...</td>
    </tr>
    <tr>
      <th>79</th>
      <td>84.0</td>
      <td>S</td>
      <td>Vaucluse</td>
      <td>13576.0</td>
      <td>5731.0</td>
      <td>37.0</td>
      <td>1246.0</td>
      <td>17239.0</td>
      <td>19024.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>76.0</td>
      <td>54.0</td>
      <td>8.0</td>
      <td>41.0</td>
      <td>45.0</td>
      <td>2.0</td>
      <td>337.215</td>
      <td>3567.0</td>
      <td>239.11</td>
      <td>MULTIPOLYGON (((811669 1924852, 811384 1925100...</td>
    </tr>
    <tr>
      <th>80</th>
      <td>85.0</td>
      <td>S</td>
      <td>Vendee</td>
      <td>20827.0</td>
      <td>7566.0</td>
      <td>28.0</td>
      <td>14035.0</td>
      <td>62486.0</td>
      <td>67963.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>44.0</td>
      <td>30.0</td>
      <td>68.0</td>
      <td>79.0</td>
      <td>59.0</td>
      <td>4.0</td>
      <td>212.459</td>
      <td>6720.0</td>
      <td>330.36</td>
      <td>MULTIPOLYGON (((243055 2197885, 243019 2198089...</td>
    </tr>
    <tr>
      <th>81</th>
      <td>86.0</td>
      <td>S</td>
      <td>Vienne</td>
      <td>15010.0</td>
      <td>4710.0</td>
      <td>25.0</td>
      <td>8922.0</td>
      <td>35224.0</td>
      <td>21851.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>1.0</td>
      <td>44.0</td>
      <td>40.0</td>
      <td>38.0</td>
      <td>65.0</td>
      <td>18.0</td>
      <td>170.523</td>
      <td>6990.0</td>
      <td>282.73</td>
      <td>POLYGON ((450395 2119945, 450065 2120124, 4494...</td>
    </tr>
    <tr>
      <th>82</th>
      <td>87.0</td>
      <td>S</td>
      <td>Haute-Vienne</td>
      <td>16256.0</td>
      <td>6402.0</td>
      <td>13.0</td>
      <td>13817.0</td>
      <td>19940.0</td>
      <td>33497.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>6.0</td>
      <td>78.0</td>
      <td>55.0</td>
      <td>11.0</td>
      <td>84.0</td>
      <td>7.0</td>
      <td>198.874</td>
      <td>5520.0</td>
      <td>285.13</td>
      <td>POLYGON ((515230 2049895, 514990 2049594, 5143...</td>
    </tr>
    <tr>
      <th>83</th>
      <td>88.0</td>
      <td>S</td>
      <td>Vosges</td>
      <td>18835.0</td>
      <td>9044.0</td>
      <td>62.0</td>
      <td>4040.0</td>
      <td>14978.0</td>
      <td>33029.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>34.0</td>
      <td>5.0</td>
      <td>14.0</td>
      <td>85.0</td>
      <td>11.0</td>
      <td>43.0</td>
      <td>174.477</td>
      <td>5874.0</td>
      <td>397.99</td>
      <td>POLYGON ((951144 2383215, 953082 2382491, 9534...</td>
    </tr>
    <tr>
      <th>84</th>
      <td>89.0</td>
      <td>S</td>
      <td>Yonne</td>
      <td>18006.0</td>
      <td>6516.0</td>
      <td>47.0</td>
      <td>4276.0</td>
      <td>16616.0</td>
      <td>12789.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>22.0</td>
      <td>35.0</td>
      <td>51.0</td>
      <td>66.0</td>
      <td>27.0</td>
      <td>272.0</td>
      <td>81.797</td>
      <td>7427.0</td>
      <td>352.49</td>
      <td>POLYGON ((650260 2358330, 651712 2361305, 6528...</td>
    </tr>
  </tbody>
</table>
<p>85 rows × 24 columns</p>
</div>



> **NB** такое назначение системы координат не влечет за собой их пересчет, они в этом случае остаются неизменными

> Метод `set_crs` предназначен только для назначения системы координат тем объектам, в которых ее нет или она неверна.

> **NB!!!** не является перепроецированием 


```python
guerry.set_crs(27572, allow_override=True)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>dept</th>
      <th>Region</th>
      <th>Dprtmnt</th>
      <th>Crm_prs</th>
      <th>Crm_prp</th>
      <th>Litercy</th>
      <th>Donatns</th>
      <th>Infants</th>
      <th>Suicids</th>
      <th>MainCty</th>
      <th>...</th>
      <th>Infntcd</th>
      <th>Dntn_cl</th>
      <th>Lottery</th>
      <th>Desertn</th>
      <th>Instrct</th>
      <th>Prsttts</th>
      <th>Distanc</th>
      <th>Area</th>
      <th>Pop1831</th>
      <th>geometry</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>S</td>
      <td>Ain</td>
      <td>28870.0</td>
      <td>15890.0</td>
      <td>37.0</td>
      <td>5098.0</td>
      <td>33120.0</td>
      <td>35039.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>60.0</td>
      <td>69.0</td>
      <td>41.0</td>
      <td>55.0</td>
      <td>46.0</td>
      <td>13.0</td>
      <td>218.372</td>
      <td>5762.0</td>
      <td>346.03</td>
      <td>POLYGON ((801150 2092615, 800669 2093190, 8006...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2.0</td>
      <td>S</td>
      <td>Aisne</td>
      <td>26226.0</td>
      <td>5521.0</td>
      <td>51.0</td>
      <td>8901.0</td>
      <td>14572.0</td>
      <td>12831.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>82.0</td>
      <td>36.0</td>
      <td>38.0</td>
      <td>82.0</td>
      <td>24.0</td>
      <td>327.0</td>
      <td>65.945</td>
      <td>7369.0</td>
      <td>513.00</td>
      <td>POLYGON ((729326 2521619, 729320 2521230, 7292...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3.0</td>
      <td>S</td>
      <td>Allier</td>
      <td>26747.0</td>
      <td>7925.0</td>
      <td>13.0</td>
      <td>10973.0</td>
      <td>17044.0</td>
      <td>114121.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>42.0</td>
      <td>76.0</td>
      <td>66.0</td>
      <td>16.0</td>
      <td>85.0</td>
      <td>34.0</td>
      <td>161.927</td>
      <td>7340.0</td>
      <td>298.26</td>
      <td>POLYGON ((710830 2137350, 711746 2136617, 7124...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.0</td>
      <td>S</td>
      <td>Basses-Alpes</td>
      <td>12935.0</td>
      <td>7289.0</td>
      <td>46.0</td>
      <td>2733.0</td>
      <td>23018.0</td>
      <td>14238.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>12.0</td>
      <td>37.0</td>
      <td>80.0</td>
      <td>32.0</td>
      <td>29.0</td>
      <td>2.0</td>
      <td>351.399</td>
      <td>6925.0</td>
      <td>155.90</td>
      <td>POLYGON ((882701 1920024, 882408 1920733, 8817...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>S</td>
      <td>Hautes-Alpes</td>
      <td>17488.0</td>
      <td>8174.0</td>
      <td>69.0</td>
      <td>6962.0</td>
      <td>23076.0</td>
      <td>16171.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>23.0</td>
      <td>64.0</td>
      <td>79.0</td>
      <td>35.0</td>
      <td>7.0</td>
      <td>1.0</td>
      <td>320.280</td>
      <td>5549.0</td>
      <td>129.10</td>
      <td>POLYGON ((886504 1922890, 885733 1922978, 8854...</td>
    </tr>
    <tr>
      <th>5</th>
      <td>7.0</td>
      <td>S</td>
      <td>Ardeche</td>
      <td>9474.0</td>
      <td>10263.0</td>
      <td>27.0</td>
      <td>3188.0</td>
      <td>42117.0</td>
      <td>52547.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>47.0</td>
      <td>67.0</td>
      <td>70.0</td>
      <td>19.0</td>
      <td>62.0</td>
      <td>1.0</td>
      <td>279.413</td>
      <td>5529.0</td>
      <td>340.73</td>
      <td>POLYGON ((747008 1925789, 746630 1925762, 7457...</td>
    </tr>
    <tr>
      <th>6</th>
      <td>8.0</td>
      <td>S</td>
      <td>Ardennes</td>
      <td>35203.0</td>
      <td>8847.0</td>
      <td>67.0</td>
      <td>6400.0</td>
      <td>16106.0</td>
      <td>26198.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>85.0</td>
      <td>49.0</td>
      <td>31.0</td>
      <td>62.0</td>
      <td>9.0</td>
      <td>83.0</td>
      <td>105.694</td>
      <td>5229.0</td>
      <td>289.62</td>
      <td>POLYGON ((818893 2514767, 818614 2514515, 8179...</td>
    </tr>
    <tr>
      <th>7</th>
      <td>9.0</td>
      <td>S</td>
      <td>Ariege</td>
      <td>6173.0</td>
      <td>9597.0</td>
      <td>18.0</td>
      <td>3542.0</td>
      <td>22916.0</td>
      <td>123625.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>28.0</td>
      <td>63.0</td>
      <td>75.0</td>
      <td>22.0</td>
      <td>77.0</td>
      <td>3.0</td>
      <td>385.313</td>
      <td>4890.0</td>
      <td>253.12</td>
      <td>POLYGON ((509103 1747787, 508820 1747513, 5081...</td>
    </tr>
    <tr>
      <th>8</th>
      <td>10.0</td>
      <td>S</td>
      <td>Aube</td>
      <td>19602.0</td>
      <td>4086.0</td>
      <td>59.0</td>
      <td>3608.0</td>
      <td>18642.0</td>
      <td>10989.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>54.0</td>
      <td>9.0</td>
      <td>28.0</td>
      <td>86.0</td>
      <td>15.0</td>
      <td>207.0</td>
      <td>83.244</td>
      <td>6004.0</td>
      <td>246.36</td>
      <td>POLYGON ((775400 2345600, 775068 2345397, 7735...</td>
    </tr>
    <tr>
      <th>9</th>
      <td>11.0</td>
      <td>S</td>
      <td>Aude</td>
      <td>15647.0</td>
      <td>10431.0</td>
      <td>34.0</td>
      <td>2582.0</td>
      <td>20225.0</td>
      <td>66498.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>35.0</td>
      <td>27.0</td>
      <td>50.0</td>
      <td>63.0</td>
      <td>48.0</td>
      <td>1.0</td>
      <td>370.949</td>
      <td>6139.0</td>
      <td>270.13</td>
      <td>POLYGON ((626230 1810121, 626269 1810496, 6274...</td>
    </tr>
    <tr>
      <th>10</th>
      <td>12.0</td>
      <td>S</td>
      <td>Aveyron</td>
      <td>8236.0</td>
      <td>6731.0</td>
      <td>31.0</td>
      <td>3211.0</td>
      <td>21981.0</td>
      <td>116671.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>5.0</td>
      <td>23.0</td>
      <td>81.0</td>
      <td>10.0</td>
      <td>44.0</td>
      <td>4.0</td>
      <td>296.089</td>
      <td>8735.0</td>
      <td>359.06</td>
      <td>POLYGON ((642972 1978185, 643791 1976549, 6444...</td>
    </tr>
    <tr>
      <th>11</th>
      <td>13.0</td>
      <td>S</td>
      <td>Bouches-du-Rhone</td>
      <td>13409.0</td>
      <td>5291.0</td>
      <td>38.0</td>
      <td>2314.0</td>
      <td>9325.0</td>
      <td>8107.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>74.0</td>
      <td>55.0</td>
      <td>3.0</td>
      <td>23.0</td>
      <td>43.0</td>
      <td>25.0</td>
      <td>362.568</td>
      <td>5087.0</td>
      <td>359.47</td>
      <td>POLYGON ((824692 1865875, 825615 1865409, 8259...</td>
    </tr>
    <tr>
      <th>12</th>
      <td>14.0</td>
      <td>S</td>
      <td>Calvados</td>
      <td>17577.0</td>
      <td>4500.0</td>
      <td>52.0</td>
      <td>27830.0</td>
      <td>8983.0</td>
      <td>31807.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>56.0</td>
      <td>11.0</td>
      <td>13.0</td>
      <td>12.0</td>
      <td>22.0</td>
      <td>194.0</td>
      <td>117.487</td>
      <td>5548.0</td>
      <td>494.70</td>
      <td>POLYGON ((345476 2429914, 345299 2430235, 3436...</td>
    </tr>
    <tr>
      <th>13</th>
      <td>15.0</td>
      <td>S</td>
      <td>Cantal</td>
      <td>18070.0</td>
      <td>11645.0</td>
      <td>31.0</td>
      <td>4093.0</td>
      <td>15335.0</td>
      <td>87338.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>83.0</td>
      <td>66.0</td>
      <td>82.0</td>
      <td>1.0</td>
      <td>51.0</td>
      <td>20.0</td>
      <td>245.849</td>
      <td>5726.0</td>
      <td>258.59</td>
      <td>POLYGON ((591653 2017934, 591727 2018244, 5918...</td>
    </tr>
    <tr>
      <th>14</th>
      <td>16.0</td>
      <td>S</td>
      <td>Charente</td>
      <td>24964.0</td>
      <td>13018.0</td>
      <td>36.0</td>
      <td>13602.0</td>
      <td>19454.0</td>
      <td>25720.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>7.0</td>
      <td>81.0</td>
      <td>60.0</td>
      <td>61.0</td>
      <td>47.0</td>
      <td>8.0</td>
      <td>224.339</td>
      <td>5956.0</td>
      <td>362.53</td>
      <td>POLYGON ((456425 2120055, 456229 2120382, 4559...</td>
    </tr>
    <tr>
      <th>15</th>
      <td>17.0</td>
      <td>S</td>
      <td>Charente-Inferieure</td>
      <td>18712.0</td>
      <td>5357.0</td>
      <td>39.0</td>
      <td>13254.0</td>
      <td>23999.0</td>
      <td>16798.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>38.0</td>
      <td>72.0</td>
      <td>35.0</td>
      <td>74.0</td>
      <td>42.0</td>
      <td>27.0</td>
      <td>238.538</td>
      <td>6864.0</td>
      <td>445.25</td>
      <td>MULTIPOLYGON (((328075 2118055, 327916 2118168...</td>
    </tr>
    <tr>
      <th>16</th>
      <td>18.0</td>
      <td>S</td>
      <td>Cher</td>
      <td>21934.0</td>
      <td>10503.0</td>
      <td>13.0</td>
      <td>9561.0</td>
      <td>23574.0</td>
      <td>19497.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>11.0</td>
      <td>86.0</td>
      <td>44.0</td>
      <td>51.0</td>
      <td>83.0</td>
      <td>26.0</td>
      <td>116.257</td>
      <td>7235.0</td>
      <td>256.06</td>
      <td>POLYGON ((572720 2252955, 574278 2251834, 5753...</td>
    </tr>
    <tr>
      <th>17</th>
      <td>19.0</td>
      <td>S</td>
      <td>Correze</td>
      <td>15262.0</td>
      <td>12949.0</td>
      <td>12.0</td>
      <td>14993.0</td>
      <td>19330.0</td>
      <td>47480.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>16.0</td>
      <td>82.0</td>
      <td>84.0</td>
      <td>2.0</td>
      <td>86.0</td>
      <td>3.0</td>
      <td>227.899</td>
      <td>5857.0</td>
      <td>294.83</td>
      <td>POLYGON ((608225 2042680, 608101 2042880, 6079...</td>
    </tr>
    <tr>
      <th>18</th>
      <td>21.0</td>
      <td>S</td>
      <td>Cote-d'Or</td>
      <td>32256.0</td>
      <td>9159.0</td>
      <td>60.0</td>
      <td>2540.0</td>
      <td>15599.0</td>
      <td>16128.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>27.0</td>
      <td>18.0</td>
      <td>33.0</td>
      <td>78.0</td>
      <td>13.0</td>
      <td>206.0</td>
      <td>136.109</td>
      <td>8763.0</td>
      <td>375.88</td>
      <td>MULTIPOLYGON (((738935 2236890, 738359 2237343...</td>
    </tr>
    <tr>
      <th>19</th>
      <td>22.0</td>
      <td>S</td>
      <td>Cotes-du-Nord</td>
      <td>28607.0</td>
      <td>7050.0</td>
      <td>16.0</td>
      <td>10387.0</td>
      <td>36098.0</td>
      <td>75056.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>69.0</td>
      <td>15.0</td>
      <td>72.0</td>
      <td>47.0</td>
      <td>80.0</td>
      <td>16.0</td>
      <td>225.161</td>
      <td>6878.0</td>
      <td>598.87</td>
      <td>MULTIPOLYGON (((208165 2439753, 208131 2439949...</td>
    </tr>
    <tr>
      <th>20</th>
      <td>23.0</td>
      <td>S</td>
      <td>Creuse</td>
      <td>37014.0</td>
      <td>20235.0</td>
      <td>23.0</td>
      <td>10997.0</td>
      <td>14363.0</td>
      <td>77823.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>24.0</td>
      <td>75.0</td>
      <td>85.0</td>
      <td>4.0</td>
      <td>71.0</td>
      <td>12.0</td>
      <td>180.846</td>
      <td>5565.0</td>
      <td>265.38</td>
      <td>POLYGON ((540175 2111095, 538135 2111105, 5380...</td>
    </tr>
    <tr>
      <th>21</th>
      <td>24.0</td>
      <td>S</td>
      <td>Dordogne</td>
      <td>21585.0</td>
      <td>10237.0</td>
      <td>18.0</td>
      <td>4687.0</td>
      <td>21375.0</td>
      <td>36024.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>18.0</td>
      <td>79.0</td>
      <td>77.0</td>
      <td>44.0</td>
      <td>78.0</td>
      <td>3.0</td>
      <td>253.776</td>
      <td>9060.0</td>
      <td>482.75</td>
      <td>POLYGON ((527718 1988833, 528808 1988071, 5291...</td>
    </tr>
    <tr>
      <th>22</th>
      <td>25.0</td>
      <td>S</td>
      <td>Doubs</td>
      <td>11560.0</td>
      <td>5914.0</td>
      <td>73.0</td>
      <td>3436.0</td>
      <td>12512.0</td>
      <td>40690.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>25.0</td>
      <td>6.0</td>
      <td>18.0</td>
      <td>73.0</td>
      <td>2.0</td>
      <td>65.0</td>
      <td>202.065</td>
      <td>5234.0</td>
      <td>265.54</td>
      <td>POLYGON ((886630 2188665, 886948 2188898, 8879...</td>
    </tr>
    <tr>
      <th>23</th>
      <td>26.0</td>
      <td>S</td>
      <td>Drome</td>
      <td>13396.0</td>
      <td>7759.0</td>
      <td>42.0</td>
      <td>2829.0</td>
      <td>16348.0</td>
      <td>23816.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>13.0</td>
      <td>62.0</td>
      <td>54.0</td>
      <td>46.0</td>
      <td>38.0</td>
      <td>8.0</td>
      <td>295.543</td>
      <td>6530.0</td>
      <td>299.56</td>
      <td>POLYGON ((830803 2010472, 831288 2010361, 8315...</td>
    </tr>
    <tr>
      <th>24</th>
      <td>27.0</td>
      <td>S</td>
      <td>Eure</td>
      <td>14795.0</td>
      <td>4774.0</td>
      <td>51.0</td>
      <td>11712.0</td>
      <td>16039.0</td>
      <td>13493.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>45.0</td>
      <td>45.0</td>
      <td>47.0</td>
      <td>27.0</td>
      <td>23.0</td>
      <td>179.0</td>
      <td>61.863</td>
      <td>6040.0</td>
      <td>424.25</td>
      <td>POLYGON ((515046 2482676, 515755 2483384, 5160...</td>
    </tr>
    <tr>
      <th>25</th>
      <td>28.0</td>
      <td>S</td>
      <td>Eure-et-Loir</td>
      <td>21368.0</td>
      <td>4016.0</td>
      <td>54.0</td>
      <td>4553.0</td>
      <td>14475.0</td>
      <td>15015.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>62.0</td>
      <td>14.0</td>
      <td>48.0</td>
      <td>72.0</td>
      <td>18.0</td>
      <td>180.0</td>
      <td>54.558</td>
      <td>5880.0</td>
      <td>278.82</td>
      <td>POLYGON ((562860 2342515, 562499 2342577, 5602...</td>
    </tr>
    <tr>
      <th>26</th>
      <td>29.0</td>
      <td>S</td>
      <td>Finistere</td>
      <td>29872.0</td>
      <td>6842.0</td>
      <td>15.0</td>
      <td>23945.0</td>
      <td>28392.0</td>
      <td>25143.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>78.0</td>
      <td>25.0</td>
      <td>36.0</td>
      <td>77.0</td>
      <td>81.0</td>
      <td>42.0</td>
      <td>276.210</td>
      <td>6733.0</td>
      <td>524.40</td>
      <td>MULTIPOLYGON (((134794 2434061, 134532 2434541...</td>
    </tr>
    <tr>
      <th>27</th>
      <td>30.0</td>
      <td>S</td>
      <td>Gard</td>
      <td>13115.0</td>
      <td>7990.0</td>
      <td>40.0</td>
      <td>3048.0</td>
      <td>28726.0</td>
      <td>18292.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>39.0</td>
      <td>59.0</td>
      <td>20.0</td>
      <td>40.0</td>
      <td>40.0</td>
      <td>5.0</td>
      <td>323.004</td>
      <td>5853.0</td>
      <td>357.38</td>
      <td>POLYGON ((719592 1880745, 719924 1881419, 7194...</td>
    </tr>
    <tr>
      <th>28</th>
      <td>31.0</td>
      <td>S</td>
      <td>Haute-Garonne</td>
      <td>18642.0</td>
      <td>7204.0</td>
      <td>31.0</td>
      <td>2286.0</td>
      <td>15378.0</td>
      <td>56140.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>59.0</td>
      <td>13.0</td>
      <td>25.0</td>
      <td>15.0</td>
      <td>33.0</td>
      <td>8.0</td>
      <td>361.668</td>
      <td>6257.0</td>
      <td>427.86</td>
      <td>POLYGON ((491745 1820323, 491926 1820668, 4914...</td>
    </tr>
    <tr>
      <th>29</th>
      <td>32.0</td>
      <td>S</td>
      <td>Gers</td>
      <td>18642.0</td>
      <td>10486.0</td>
      <td>38.0</td>
      <td>2848.0</td>
      <td>15250.0</td>
      <td>61510.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>13.0</td>
      <td>32.0</td>
      <td>74.0</td>
      <td>30.0</td>
      <td>44.0</td>
      <td>1.0</td>
      <td>343.569</td>
      <td>6309.0</td>
      <td>312.16</td>
      <td>POLYGON ((447673 1816738, 447362 1816893, 4463...</td>
    </tr>
    <tr>
      <th>30</th>
      <td>33.0</td>
      <td>S</td>
      <td>Gironde</td>
      <td>24096.0</td>
      <td>7423.0</td>
      <td>40.0</td>
      <td>5076.0</td>
      <td>10676.0</td>
      <td>19220.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>80.0</td>
      <td>48.0</td>
      <td>4.0</td>
      <td>13.0</td>
      <td>41.0</td>
      <td>39.0</td>
      <td>291.624</td>
      <td>10000.0</td>
      <td>554.23</td>
      <td>MULTIPOLYGON (((332874 1966651, 332777 1966980...</td>
    </tr>
    <tr>
      <th>31</th>
      <td>34.0</td>
      <td>S</td>
      <td>Herault</td>
      <td>12814.0</td>
      <td>10954.0</td>
      <td>45.0</td>
      <td>1680.0</td>
      <td>21346.0</td>
      <td>30869.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>51.0</td>
      <td>28.0</td>
      <td>19.0</td>
      <td>43.0</td>
      <td>32.0</td>
      <td>9.0</td>
      <td>344.030</td>
      <td>6101.0</td>
      <td>346.30</td>
      <td>POLYGON ((739523 1864067, 740853 1864454, 7414...</td>
    </tr>
    <tr>
      <th>32</th>
      <td>35.0</td>
      <td>S</td>
      <td>Ille-et-Vilaine</td>
      <td>22138.0</td>
      <td>6524.0</td>
      <td>25.0</td>
      <td>7686.0</td>
      <td>40736.0</td>
      <td>45180.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>31.0</td>
      <td>22.0</td>
      <td>37.0</td>
      <td>50.0</td>
      <td>66.0</td>
      <td>77.0</td>
      <td>179.379</td>
      <td>6775.0</td>
      <td>547.05</td>
      <td>MULTIPOLYGON (((271910 2322460, 272047 2322795...</td>
    </tr>
    <tr>
      <th>33</th>
      <td>36.0</td>
      <td>S</td>
      <td>Indre</td>
      <td>32404.0</td>
      <td>7624.0</td>
      <td>17.0</td>
      <td>11315.0</td>
      <td>20046.0</td>
      <td>25014.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>19.0</td>
      <td>83.0</td>
      <td>69.0</td>
      <td>29.0</td>
      <td>79.0</td>
      <td>14.0</td>
      <td>139.587</td>
      <td>6791.0</td>
      <td>245.29</td>
      <td>POLYGON ((573430 2159520, 573109 2159583, 5726...</td>
    </tr>
    <tr>
      <th>34</th>
      <td>37.0</td>
      <td>S</td>
      <td>Indre-et-Loire</td>
      <td>19131.0</td>
      <td>6909.0</td>
      <td>27.0</td>
      <td>7254.0</td>
      <td>16601.0</td>
      <td>15272.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>3.0</td>
      <td>41.0</td>
      <td>15.0</td>
      <td>49.0</td>
      <td>63.0</td>
      <td>59.0</td>
      <td>126.468</td>
      <td>6127.0</td>
      <td>297.02</td>
      <td>POLYGON ((505590 2270755, 507478 2268385, 5076...</td>
    </tr>
    <tr>
      <th>35</th>
      <td>38.0</td>
      <td>S</td>
      <td>Isere</td>
      <td>18785.0</td>
      <td>8326.0</td>
      <td>29.0</td>
      <td>4077.0</td>
      <td>12236.0</td>
      <td>36275.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>27.0</td>
      <td>73.0</td>
      <td>23.0</td>
      <td>26.0</td>
      <td>57.0</td>
      <td>12.0</td>
      <td>268.661</td>
      <td>7431.0</td>
      <td>550.26</td>
      <td>POLYGON ((839825 2094355, 840895 2093318, 8411...</td>
    </tr>
    <tr>
      <th>36</th>
      <td>39.0</td>
      <td>S</td>
      <td>Jura</td>
      <td>26221.0</td>
      <td>8059.0</td>
      <td>73.0</td>
      <td>3012.0</td>
      <td>20384.0</td>
      <td>34476.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>66.0</td>
      <td>43.0</td>
      <td>39.0</td>
      <td>71.0</td>
      <td>3.0</td>
      <td>32.0</td>
      <td>197.155</td>
      <td>4999.0</td>
      <td>312.50</td>
      <td>MULTIPOLYGON (((836965 2209730, 836855 2209785...</td>
    </tr>
    <tr>
      <th>37</th>
      <td>40.0</td>
      <td>S</td>
      <td>Landes</td>
      <td>17687.0</td>
      <td>6170.0</td>
      <td>28.0</td>
      <td>12059.0</td>
      <td>15302.0</td>
      <td>35375.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>43.0</td>
      <td>56.0</td>
      <td>73.0</td>
      <td>28.0</td>
      <td>58.0</td>
      <td>3.0</td>
      <td>344.676</td>
      <td>9243.0</td>
      <td>281.50</td>
      <td>POLYGON ((311864 1932711, 314132 1946872, 3141...</td>
    </tr>
    <tr>
      <th>38</th>
      <td>41.0</td>
      <td>S</td>
      <td>Loir-et-Cher</td>
      <td>21292.0</td>
      <td>6017.0</td>
      <td>27.0</td>
      <td>5626.0</td>
      <td>13364.0</td>
      <td>14417.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>37.0</td>
      <td>70.0</td>
      <td>46.0</td>
      <td>54.0</td>
      <td>61.0</td>
      <td>54.0</td>
      <td>90.735</td>
      <td>6343.0</td>
      <td>235.75</td>
      <td>POLYGON ((519655 2330465, 520005 2329830, 5225...</td>
    </tr>
    <tr>
      <th>39</th>
      <td>42.0</td>
      <td>S</td>
      <td>Loire</td>
      <td>27491.0</td>
      <td>12665.0</td>
      <td>29.0</td>
      <td>3446.0</td>
      <td>29605.0</td>
      <td>71364.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>77.0</td>
      <td>34.0</td>
      <td>42.0</td>
      <td>6.0</td>
      <td>56.0</td>
      <td>14.0</td>
      <td>215.598</td>
      <td>4781.0</td>
      <td>391.22</td>
      <td>POLYGON ((732285 2132610, 732782 2133196, 7330...</td>
    </tr>
    <tr>
      <th>40</th>
      <td>43.0</td>
      <td>S</td>
      <td>Haute-Loire</td>
      <td>16170.0</td>
      <td>18043.0</td>
      <td>21.0</td>
      <td>2746.0</td>
      <td>31017.0</td>
      <td>163241.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>17.0</td>
      <td>65.0</td>
      <td>62.0</td>
      <td>3.0</td>
      <td>72.0</td>
      <td>10.0</td>
      <td>248.877</td>
      <td>4977.0</td>
      <td>292.08</td>
      <td>POLYGON ((742975 2044820, 744433 2045165, 7460...</td>
    </tr>
    <tr>
      <th>41</th>
      <td>44.0</td>
      <td>S</td>
      <td>Loire-Inferieure</td>
      <td>19314.0</td>
      <td>9392.0</td>
      <td>24.0</td>
      <td>8310.0</td>
      <td>14097.0</td>
      <td>27289.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>52.0</td>
      <td>29.0</td>
      <td>12.0</td>
      <td>45.0</td>
      <td>67.0</td>
      <td>63.0</td>
      <td>199.167</td>
      <td>6815.0</td>
      <td>470.09</td>
      <td>POLYGON ((268705 2263645, 268976 2263891, 2710...</td>
    </tr>
    <tr>
      <th>42</th>
      <td>45.0</td>
      <td>S</td>
      <td>Loiret</td>
      <td>17722.0</td>
      <td>5042.0</td>
      <td>42.0</td>
      <td>4753.0</td>
      <td>9986.0</td>
      <td>11813.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>22.0</td>
      <td>16.0</td>
      <td>17.0</td>
      <td>60.0</td>
      <td>37.0</td>
      <td>256.0</td>
      <td>61.106</td>
      <td>6775.0</td>
      <td>305.28</td>
      <td>POLYGON ((557890 2341355, 558382 2341921, 5598...</td>
    </tr>
    <tr>
      <th>43</th>
      <td>46.0</td>
      <td>S</td>
      <td>Lot</td>
      <td>5883.0</td>
      <td>9049.0</td>
      <td>24.0</td>
      <td>5194.0</td>
      <td>20383.0</td>
      <td>48783.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>15.0</td>
      <td>68.0</td>
      <td>78.0</td>
      <td>24.0</td>
      <td>68.0</td>
      <td>1.0</td>
      <td>275.725</td>
      <td>5217.0</td>
      <td>283.83</td>
      <td>POLYGON ((503966 1958060, 505528 1959658, 5058...</td>
    </tr>
    <tr>
      <th>44</th>
      <td>47.0</td>
      <td>S</td>
      <td>Lot-et-Garonne</td>
      <td>22969.0</td>
      <td>8943.0</td>
      <td>31.0</td>
      <td>4432.0</td>
      <td>17681.0</td>
      <td>38501.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>32.0</td>
      <td>46.0</td>
      <td>52.0</td>
      <td>34.0</td>
      <td>50.0</td>
      <td>5.0</td>
      <td>302.345</td>
      <td>5361.0</td>
      <td>346.89</td>
      <td>POLYGON ((413714 1942691, 413362 1942587, 4128...</td>
    </tr>
    <tr>
      <th>45</th>
      <td>48.0</td>
      <td>S</td>
      <td>Lozere</td>
      <td>7710.0</td>
      <td>5990.0</td>
      <td>27.0</td>
      <td>2040.0</td>
      <td>25157.0</td>
      <td>11092.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>45.0</td>
      <td>42.0</td>
      <td>86.0</td>
      <td>5.0</td>
      <td>60.0</td>
      <td>0.0</td>
      <td>283.810</td>
      <td>5167.0</td>
      <td>140.35</td>
      <td>POLYGON ((702442 1987131, 703082 1987282, 7033...</td>
    </tr>
    <tr>
      <th>46</th>
      <td>49.0</td>
      <td>S</td>
      <td>Maine-et-Loire</td>
      <td>29692.0</td>
      <td>8520.0</td>
      <td>23.0</td>
      <td>4410.0</td>
      <td>18708.0</td>
      <td>33358.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>36.0</td>
      <td>20.0</td>
      <td>24.0</td>
      <td>76.0</td>
      <td>70.0</td>
      <td>35.0</td>
      <td>157.437</td>
      <td>7166.0</td>
      <td>467.87</td>
      <td>POLYGON ((409765 2298980, 409716 2297568, 4099...</td>
    </tr>
    <tr>
      <th>47</th>
      <td>50.0</td>
      <td>S</td>
      <td>Manche</td>
      <td>31078.0</td>
      <td>7424.0</td>
      <td>43.0</td>
      <td>5179.0</td>
      <td>14281.0</td>
      <td>55564.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>70.0</td>
      <td>3.0</td>
      <td>59.0</td>
      <td>21.0</td>
      <td>36.0</td>
      <td>98.0</td>
      <td>157.187</td>
      <td>5938.0</td>
      <td>591.28</td>
      <td>MULTIPOLYGON (((316425 2410987, 316287 2411065...</td>
    </tr>
    <tr>
      <th>48</th>
      <td>51.0</td>
      <td>S</td>
      <td>Marne</td>
      <td>15602.0</td>
      <td>4950.0</td>
      <td>63.0</td>
      <td>3963.0</td>
      <td>11267.0</td>
      <td>8334.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>58.0</td>
      <td>39.0</td>
      <td>22.0</td>
      <td>81.0</td>
      <td>10.0</td>
      <td>262.0</td>
      <td>77.364</td>
      <td>6211.0</td>
      <td>337.08</td>
      <td>POLYGON ((781920 2395187, 781562 2395133, 7809...</td>
    </tr>
    <tr>
      <th>49</th>
      <td>52.0</td>
      <td>S</td>
      <td>Haute-Marne</td>
      <td>26231.0</td>
      <td>9539.0</td>
      <td>72.0</td>
      <td>4013.0</td>
      <td>17507.0</td>
      <td>19586.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>55.0</td>
      <td>4.0</td>
      <td>56.0</td>
      <td>65.0</td>
      <td>4.0</td>
      <td>138.0</td>
      <td>129.765</td>
      <td>8162.0</td>
      <td>249.83</td>
      <td>POLYGON ((776565 2346640, 776344 2346943, 7780...</td>
    </tr>
    <tr>
      <th>50</th>
      <td>53.0</td>
      <td>S</td>
      <td>Mayenne</td>
      <td>28331.0</td>
      <td>9198.0</td>
      <td>19.0</td>
      <td>2107.0</td>
      <td>18544.0</td>
      <td>28331.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>40.0</td>
      <td>8.0</td>
      <td>61.0</td>
      <td>58.0</td>
      <td>75.0</td>
      <td>46.0</td>
      <td>139.999</td>
      <td>5175.0</td>
      <td>352.59</td>
      <td>POLYGON ((394355 2321180, 394249 2320876, 3943...</td>
    </tr>
    <tr>
      <th>51</th>
      <td>54.0</td>
      <td>S</td>
      <td>Meurthe</td>
      <td>26674.0</td>
      <td>6831.0</td>
      <td>68.0</td>
      <td>3912.0</td>
      <td>12355.0</td>
      <td>15652.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>71.0</td>
      <td>1.0</td>
      <td>21.0</td>
      <td>70.0</td>
      <td>8.0</td>
      <td>154.0</td>
      <td>159.648</td>
      <td>5241.0</td>
      <td>415.57</td>
      <td>MULTIPOLYGON (((826186 2502671, 825892 2502926...</td>
    </tr>
    <tr>
      <th>52</th>
      <td>55.0</td>
      <td>S</td>
      <td>Meuse</td>
      <td>24507.0</td>
      <td>9190.0</td>
      <td>74.0</td>
      <td>4196.0</td>
      <td>17333.0</td>
      <td>13463.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>65.0</td>
      <td>12.0</td>
      <td>58.0</td>
      <td>59.0</td>
      <td>1.0</td>
      <td>131.0</td>
      <td>126.378</td>
      <td>6216.0</td>
      <td>314.59</td>
      <td>POLYGON ((853530 2462643, 853898 2462654, 8542...</td>
    </tr>
    <tr>
      <th>53</th>
      <td>56.0</td>
      <td>S</td>
      <td>Morbihan</td>
      <td>23316.0</td>
      <td>7940.0</td>
      <td>14.0</td>
      <td>14739.0</td>
      <td>31754.0</td>
      <td>34196.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>29.0</td>
      <td>7.0</td>
      <td>32.0</td>
      <td>69.0</td>
      <td>82.0</td>
      <td>38.0</td>
      <td>230.531</td>
      <td>6823.0</td>
      <td>433.52</td>
      <td>MULTIPOLYGON (((167530 2307010, 167140 2307457...</td>
    </tr>
    <tr>
      <th>54</th>
      <td>57.0</td>
      <td>S</td>
      <td>Moselle</td>
      <td>12153.0</td>
      <td>4529.0</td>
      <td>57.0</td>
      <td>9515.0</td>
      <td>13877.0</td>
      <td>25572.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>9.0</td>
      <td>2.0</td>
      <td>16.0</td>
      <td>68.0</td>
      <td>16.0</td>
      <td>165.0</td>
      <td>180.462</td>
      <td>6216.0</td>
      <td>417.00</td>
      <td>POLYGON ((929062 2475639, 929093 2476415, 9280...</td>
    </tr>
    <tr>
      <th>55</th>
      <td>58.0</td>
      <td>S</td>
      <td>Nievre</td>
      <td>25087.0</td>
      <td>8236.0</td>
      <td>20.0</td>
      <td>10452.0</td>
      <td>19747.0</td>
      <td>29381.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>20.0</td>
      <td>80.0</td>
      <td>63.0</td>
      <td>37.0</td>
      <td>74.0</td>
      <td>39.0</td>
      <td>119.718</td>
      <td>6817.0</td>
      <td>282.52</td>
      <td>POLYGON ((715920 2264185, 717135 2264065, 7172...</td>
    </tr>
    <tr>
      <th>56</th>
      <td>59.0</td>
      <td>S</td>
      <td>Nord</td>
      <td>26740.0</td>
      <td>6175.0</td>
      <td>45.0</td>
      <td>6092.0</td>
      <td>8926.0</td>
      <td>13851.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>81.0</td>
      <td>38.0</td>
      <td>7.0</td>
      <td>64.0</td>
      <td>30.0</td>
      <td>308.0</td>
      <td>106.335</td>
      <td>5743.0</td>
      <td>989.94</td>
      <td>MULTIPOLYGON (((664166 2630647, 664342 2629299...</td>
    </tr>
    <tr>
      <th>57</th>
      <td>60.0</td>
      <td>S</td>
      <td>Oise</td>
      <td>28180.0</td>
      <td>6659.0</td>
      <td>54.0</td>
      <td>5501.0</td>
      <td>18021.0</td>
      <td>5994.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>86.0</td>
      <td>50.0</td>
      <td>43.0</td>
      <td>57.0</td>
      <td>20.0</td>
      <td>337.0</td>
      <td>33.768</td>
      <td>5860.0</td>
      <td>397.73</td>
      <td>MULTIPOLYGON (((647667 2468296, 647542 2468371...</td>
    </tr>
    <tr>
      <th>58</th>
      <td>61.0</td>
      <td>S</td>
      <td>Orne</td>
      <td>28329.0</td>
      <td>8248.0</td>
      <td>45.0</td>
      <td>9242.0</td>
      <td>20852.0</td>
      <td>34069.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>50.0</td>
      <td>31.0</td>
      <td>57.0</td>
      <td>25.0</td>
      <td>33.0</td>
      <td>117.0</td>
      <td>97.554</td>
      <td>6103.0</td>
      <td>441.88</td>
      <td>POLYGON ((469173 2432434, 470681 2434059, 4709...</td>
    </tr>
    <tr>
      <th>59</th>
      <td>62.0</td>
      <td>S</td>
      <td>Pas-de-Calais</td>
      <td>23101.0</td>
      <td>4040.0</td>
      <td>49.0</td>
      <td>5740.0</td>
      <td>10575.0</td>
      <td>15400.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>79.0</td>
      <td>10.0</td>
      <td>27.0</td>
      <td>48.0</td>
      <td>26.0</td>
      <td>163.0</td>
      <td>104.400</td>
      <td>6671.0</td>
      <td>655.22</td>
      <td>POLYGON ((629822 2560555, 629583 2560843, 6291...</td>
    </tr>
    <tr>
      <th>60</th>
      <td>63.0</td>
      <td>S</td>
      <td>Puy-de-Dome</td>
      <td>17256.0</td>
      <td>12141.0</td>
      <td>19.0</td>
      <td>5963.0</td>
      <td>22948.0</td>
      <td>78148.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>63.0</td>
      <td>61.0</td>
      <td>53.0</td>
      <td>8.0</td>
      <td>76.0</td>
      <td>62.0</td>
      <td>205.218</td>
      <td>7970.0</td>
      <td>573.11</td>
      <td>POLYGON ((615585 2050805, 615649 2051154, 6162...</td>
    </tr>
    <tr>
      <th>61</th>
      <td>64.0</td>
      <td>S</td>
      <td>Basses-Pyrenees</td>
      <td>16722.0</td>
      <td>8533.0</td>
      <td>47.0</td>
      <td>3299.0</td>
      <td>12393.0</td>
      <td>65995.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>72.0</td>
      <td>60.0</td>
      <td>34.0</td>
      <td>7.0</td>
      <td>28.0</td>
      <td>12.0</td>
      <td>387.935</td>
      <td>7645.0</td>
      <td>428.40</td>
      <td>POLYGON ((386095 1774604, 386085 1774237, 3855...</td>
    </tr>
    <tr>
      <th>62</th>
      <td>65.0</td>
      <td>S</td>
      <td>Hautes-Pyrenees</td>
      <td>12223.0</td>
      <td>9797.0</td>
      <td>53.0</td>
      <td>6001.0</td>
      <td>12125.0</td>
      <td>148039.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>75.0</td>
      <td>71.0</td>
      <td>76.0</td>
      <td>20.0</td>
      <td>21.0</td>
      <td>5.0</td>
      <td>386.559</td>
      <td>4464.0</td>
      <td>233.03</td>
      <td>MULTIPOLYGON (((406987 1826038, 405019 1826121...</td>
    </tr>
    <tr>
      <th>63</th>
      <td>66.0</td>
      <td>S</td>
      <td>Pyrenees-Orientales</td>
      <td>6728.0</td>
      <td>7632.0</td>
      <td>31.0</td>
      <td>11644.0</td>
      <td>15167.0</td>
      <td>37843.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>84.0</td>
      <td>77.0</td>
      <td>11.0</td>
      <td>18.0</td>
      <td>52.0</td>
      <td>5.0</td>
      <td>403.445</td>
      <td>4116.0</td>
      <td>157.05</td>
      <td>POLYGON ((658127 1733192, 658228 1732843, 6582...</td>
    </tr>
    <tr>
      <th>64</th>
      <td>67.0</td>
      <td>S</td>
      <td>Bas-Rhin</td>
      <td>12309.0</td>
      <td>4920.0</td>
      <td>62.0</td>
      <td>14472.0</td>
      <td>14356.0</td>
      <td>18623.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>48.0</td>
      <td>51.0</td>
      <td>5.0</td>
      <td>53.0</td>
      <td>12.0</td>
      <td>101.0</td>
      <td>217.752</td>
      <td>4755.0</td>
      <td>540.21</td>
      <td>POLYGON ((946663 2460717, 946292 2461188, 9461...</td>
    </tr>
    <tr>
      <th>65</th>
      <td>68.0</td>
      <td>S</td>
      <td>Haut-Rhin</td>
      <td>7343.0</td>
      <td>4915.0</td>
      <td>71.0</td>
      <td>6001.0</td>
      <td>14783.0</td>
      <td>21233.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>53.0</td>
      <td>17.0</td>
      <td>10.0</td>
      <td>56.0</td>
      <td>5.0</td>
      <td>26.0</td>
      <td>217.971</td>
      <td>3525.0</td>
      <td>424.26</td>
      <td>POLYGON ((989865 2319005, 990659 2316949, 9900...</td>
    </tr>
    <tr>
      <th>66</th>
      <td>69.0</td>
      <td>S</td>
      <td>Rhone</td>
      <td>18793.0</td>
      <td>4504.0</td>
      <td>45.0</td>
      <td>1983.0</td>
      <td>3910.0</td>
      <td>17003.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>33.0</td>
      <td>21.0</td>
      <td>2.0</td>
      <td>14.0</td>
      <td>31.0</td>
      <td>104.0</td>
      <td>213.032</td>
      <td>3249.0</td>
      <td>434.43</td>
      <td>POLYGON ((752410 2115380, 752067 2115294, 7510...</td>
    </tr>
    <tr>
      <th>67</th>
      <td>70.0</td>
      <td>S</td>
      <td>Haute-Saone</td>
      <td>22339.0</td>
      <td>7770.0</td>
      <td>59.0</td>
      <td>11701.0</td>
      <td>11850.0</td>
      <td>39714.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>68.0</td>
      <td>57.0</td>
      <td>65.0</td>
      <td>83.0</td>
      <td>14.0</td>
      <td>99.0</td>
      <td>176.135</td>
      <td>5360.0</td>
      <td>338.91</td>
      <td>POLYGON ((933555 2291420, 933269 2291556, 9326...</td>
    </tr>
    <tr>
      <th>68</th>
      <td>71.0</td>
      <td>S</td>
      <td>Saone-et-Loire</td>
      <td>28391.0</td>
      <td>10708.0</td>
      <td>32.0</td>
      <td>3710.0</td>
      <td>20442.0</td>
      <td>22184.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>10.0</td>
      <td>58.0</td>
      <td>45.0</td>
      <td>31.0</td>
      <td>49.0</td>
      <td>40.0</td>
      <td>168.713</td>
      <td>8575.0</td>
      <td>523.97</td>
      <td>POLYGON ((834930 2207585, 834681 2207740, 8344...</td>
    </tr>
    <tr>
      <th>69</th>
      <td>72.0</td>
      <td>S</td>
      <td>Sarthe</td>
      <td>33913.0</td>
      <td>8294.0</td>
      <td>30.0</td>
      <td>3357.0</td>
      <td>10779.0</td>
      <td>29280.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>57.0</td>
      <td>19.0</td>
      <td>49.0</td>
      <td>75.0</td>
      <td>35.0</td>
      <td>79.0</td>
      <td>108.294</td>
      <td>6206.0</td>
      <td>457.37</td>
      <td>POLYGON ((470543 2362046, 471980 2361813, 4726...</td>
    </tr>
    <tr>
      <th>70</th>
      <td>75.0</td>
      <td>S</td>
      <td>Seine</td>
      <td>13945.0</td>
      <td>1368.0</td>
      <td>71.0</td>
      <td>4204.0</td>
      <td>2660.0</td>
      <td>3632.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>67.0</td>
      <td>53.0</td>
      <td>1.0</td>
      <td>33.0</td>
      <td>6.0</td>
      <td>4744.0</td>
      <td>0.000</td>
      <td>762.0</td>
      <td>935.11</td>
      <td>POLYGON ((615302 2411120, 615000 2411180, 6143...</td>
    </tr>
    <tr>
      <th>71</th>
      <td>76.0</td>
      <td>S</td>
      <td>Seine-Inferieure</td>
      <td>18355.0</td>
      <td>2906.0</td>
      <td>43.0</td>
      <td>7245.0</td>
      <td>7506.0</td>
      <td>9523.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>61.0</td>
      <td>74.0</td>
      <td>9.0</td>
      <td>36.0</td>
      <td>35.0</td>
      <td>546.0</td>
      <td>75.658</td>
      <td>6278.0</td>
      <td>693.68</td>
      <td>POLYGON ((438965 2512493, 440124 2514448, 4402...</td>
    </tr>
    <tr>
      <th>72</th>
      <td>77.0</td>
      <td>S</td>
      <td>Seine-et-Marne</td>
      <td>22201.0</td>
      <td>5786.0</td>
      <td>54.0</td>
      <td>5303.0</td>
      <td>16324.0</td>
      <td>7315.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>73.0</td>
      <td>26.0</td>
      <td>29.0</td>
      <td>67.0</td>
      <td>37.0</td>
      <td>453.0</td>
      <td>27.647</td>
      <td>5915.0</td>
      <td>323.89</td>
      <td>POLYGON ((675580 2375994, 675218 2376008, 6748...</td>
    </tr>
    <tr>
      <th>73</th>
      <td>78.0</td>
      <td>S</td>
      <td>Seine-et-Oise</td>
      <td>12477.0</td>
      <td>3879.0</td>
      <td>56.0</td>
      <td>4007.0</td>
      <td>16303.0</td>
      <td>3460.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>30.0</td>
      <td>24.0</td>
      <td>6.0</td>
      <td>42.0</td>
      <td>17.0</td>
      <td>874.0</td>
      <td>16.888</td>
      <td>5334.0</td>
      <td>448.18</td>
      <td>POLYGON ((546799 2453567, 547588 2454258, 5478...</td>
    </tr>
    <tr>
      <th>74</th>
      <td>79.0</td>
      <td>S</td>
      <td>Deux-Sevres</td>
      <td>18400.0</td>
      <td>6863.0</td>
      <td>41.0</td>
      <td>16956.0</td>
      <td>25461.0</td>
      <td>24533.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>4.0</td>
      <td>85.0</td>
      <td>71.0</td>
      <td>84.0</td>
      <td>39.0</td>
      <td>6.0</td>
      <td>188.474</td>
      <td>5999.0</td>
      <td>297.85</td>
      <td>POLYGON ((419808 2218480, 420449 2218054, 4209...</td>
    </tr>
    <tr>
      <th>75</th>
      <td>80.0</td>
      <td>S</td>
      <td>Somme</td>
      <td>33592.0</td>
      <td>7144.0</td>
      <td>44.0</td>
      <td>4964.0</td>
      <td>12447.0</td>
      <td>12836.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>64.0</td>
      <td>33.0</td>
      <td>30.0</td>
      <td>80.0</td>
      <td>34.0</td>
      <td>302.0</td>
      <td>69.520</td>
      <td>6170.0</td>
      <td>543.70</td>
      <td>POLYGON ((543667 2592806, 544247 2596216, 5451...</td>
    </tr>
    <tr>
      <th>76</th>
      <td>81.0</td>
      <td>S</td>
      <td>Tarn</td>
      <td>13019.0</td>
      <td>6241.0</td>
      <td>20.0</td>
      <td>3449.0</td>
      <td>29305.0</td>
      <td>68980.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>9.0</td>
      <td>47.0</td>
      <td>67.0</td>
      <td>17.0</td>
      <td>73.0</td>
      <td>3.0</td>
      <td>328.146</td>
      <td>5758.0</td>
      <td>333.84</td>
      <td>POLYGON ((548083 1858875, 547740 1858741, 5469...</td>
    </tr>
    <tr>
      <th>77</th>
      <td>82.0</td>
      <td>S</td>
      <td>Tarn-et-Garonne</td>
      <td>14790.0</td>
      <td>8680.0</td>
      <td>25.0</td>
      <td>4558.0</td>
      <td>23771.0</td>
      <td>48317.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>41.0</td>
      <td>52.0</td>
      <td>64.0</td>
      <td>39.0</td>
      <td>64.0</td>
      <td>4.0</td>
      <td>313.090</td>
      <td>3718.0</td>
      <td>242.51</td>
      <td>POLYGON ((572261 1905414, 571717 1905736, 5705...</td>
    </tr>
    <tr>
      <th>78</th>
      <td>83.0</td>
      <td>S</td>
      <td>Var</td>
      <td>13145.0</td>
      <td>9572.0</td>
      <td>23.0</td>
      <td>2449.0</td>
      <td>14800.0</td>
      <td>13380.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>49.0</td>
      <td>40.0</td>
      <td>26.0</td>
      <td>52.0</td>
      <td>69.0</td>
      <td>6.0</td>
      <td>389.512</td>
      <td>5973.0</td>
      <td>317.50</td>
      <td>MULTIPOLYGON (((937679 1788572, 937646 1788379...</td>
    </tr>
    <tr>
      <th>79</th>
      <td>84.0</td>
      <td>S</td>
      <td>Vaucluse</td>
      <td>13576.0</td>
      <td>5731.0</td>
      <td>37.0</td>
      <td>1246.0</td>
      <td>17239.0</td>
      <td>19024.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>76.0</td>
      <td>54.0</td>
      <td>8.0</td>
      <td>41.0</td>
      <td>45.0</td>
      <td>2.0</td>
      <td>337.215</td>
      <td>3567.0</td>
      <td>239.11</td>
      <td>MULTIPOLYGON (((811669 1924852, 811384 1925100...</td>
    </tr>
    <tr>
      <th>80</th>
      <td>85.0</td>
      <td>S</td>
      <td>Vendee</td>
      <td>20827.0</td>
      <td>7566.0</td>
      <td>28.0</td>
      <td>14035.0</td>
      <td>62486.0</td>
      <td>67963.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>44.0</td>
      <td>30.0</td>
      <td>68.0</td>
      <td>79.0</td>
      <td>59.0</td>
      <td>4.0</td>
      <td>212.459</td>
      <td>6720.0</td>
      <td>330.36</td>
      <td>MULTIPOLYGON (((243055 2197885, 243019 2198089...</td>
    </tr>
    <tr>
      <th>81</th>
      <td>86.0</td>
      <td>S</td>
      <td>Vienne</td>
      <td>15010.0</td>
      <td>4710.0</td>
      <td>25.0</td>
      <td>8922.0</td>
      <td>35224.0</td>
      <td>21851.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>1.0</td>
      <td>44.0</td>
      <td>40.0</td>
      <td>38.0</td>
      <td>65.0</td>
      <td>18.0</td>
      <td>170.523</td>
      <td>6990.0</td>
      <td>282.73</td>
      <td>POLYGON ((450395 2119945, 450065 2120124, 4494...</td>
    </tr>
    <tr>
      <th>82</th>
      <td>87.0</td>
      <td>S</td>
      <td>Haute-Vienne</td>
      <td>16256.0</td>
      <td>6402.0</td>
      <td>13.0</td>
      <td>13817.0</td>
      <td>19940.0</td>
      <td>33497.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>6.0</td>
      <td>78.0</td>
      <td>55.0</td>
      <td>11.0</td>
      <td>84.0</td>
      <td>7.0</td>
      <td>198.874</td>
      <td>5520.0</td>
      <td>285.13</td>
      <td>POLYGON ((515230 2049895, 514990 2049594, 5143...</td>
    </tr>
    <tr>
      <th>83</th>
      <td>88.0</td>
      <td>S</td>
      <td>Vosges</td>
      <td>18835.0</td>
      <td>9044.0</td>
      <td>62.0</td>
      <td>4040.0</td>
      <td>14978.0</td>
      <td>33029.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>34.0</td>
      <td>5.0</td>
      <td>14.0</td>
      <td>85.0</td>
      <td>11.0</td>
      <td>43.0</td>
      <td>174.477</td>
      <td>5874.0</td>
      <td>397.99</td>
      <td>POLYGON ((951144 2383215, 953082 2382491, 9534...</td>
    </tr>
    <tr>
      <th>84</th>
      <td>89.0</td>
      <td>S</td>
      <td>Yonne</td>
      <td>18006.0</td>
      <td>6516.0</td>
      <td>47.0</td>
      <td>4276.0</td>
      <td>16616.0</td>
      <td>12789.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>22.0</td>
      <td>35.0</td>
      <td>51.0</td>
      <td>66.0</td>
      <td>27.0</td>
      <td>272.0</td>
      <td>81.797</td>
      <td>7427.0</td>
      <td>352.49</td>
      <td>POLYGON ((650260 2358330, 651712 2361305, 6528...</td>
    </tr>
  </tbody>
</table>
<p>85 rows × 24 columns</p>
</div>



Для перепроецирования объектов существует метод `to_crs`.


```python
guerry_wgs = guerry.to_crs(4326)

guerry_wgs.crs
```




    <Geographic 2D CRS: EPSG:4326>
    Name: WGS 84
    Axis Info [ellipsoidal]:
    - Lat[north]: Geodetic latitude (degree)
    - Lon[east]: Geodetic longitude (degree)
    Area of Use:
    - name: World.
    - bounds: (-180.0, -90.0, 180.0, 90.0)
    Datum: World Geodetic System 1984 ensemble
    - Ellipsoid: WGS 84
    - Prime Meridian: Greenwich




```python
guerry_wgs.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>dept</th>
      <th>Region</th>
      <th>Dprtmnt</th>
      <th>Crm_prs</th>
      <th>Crm_prp</th>
      <th>Litercy</th>
      <th>Donatns</th>
      <th>Infants</th>
      <th>Suicids</th>
      <th>MainCty</th>
      <th>...</th>
      <th>Infntcd</th>
      <th>Dntn_cl</th>
      <th>Lottery</th>
      <th>Desertn</th>
      <th>Instrct</th>
      <th>Prsttts</th>
      <th>Distanc</th>
      <th>Area</th>
      <th>Pop1831</th>
      <th>geometry</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>S</td>
      <td>Ain</td>
      <td>28870.0</td>
      <td>15890.0</td>
      <td>37.0</td>
      <td>5098.0</td>
      <td>33120.0</td>
      <td>35039.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>60.0</td>
      <td>69.0</td>
      <td>41.0</td>
      <td>55.0</td>
      <td>46.0</td>
      <td>13.0</td>
      <td>218.372</td>
      <td>5762.0</td>
      <td>346.03</td>
      <td>POLYGON ((4.92452 45.80404, 4.91858 45.80935, ...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2.0</td>
      <td>S</td>
      <td>Aisne</td>
      <td>26226.0</td>
      <td>5521.0</td>
      <td>51.0</td>
      <td>8901.0</td>
      <td>14572.0</td>
      <td>12831.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>82.0</td>
      <td>36.0</td>
      <td>38.0</td>
      <td>82.0</td>
      <td>24.0</td>
      <td>327.0</td>
      <td>65.945</td>
      <td>7369.0</td>
      <td>513.00</td>
      <td>POLYGON ((4.12644 49.67821, 4.12624 49.67472, ...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3.0</td>
      <td>S</td>
      <td>Allier</td>
      <td>26747.0</td>
      <td>7925.0</td>
      <td>13.0</td>
      <td>10973.0</td>
      <td>17044.0</td>
      <td>114121.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>42.0</td>
      <td>76.0</td>
      <td>66.0</td>
      <td>16.0</td>
      <td>85.0</td>
      <td>34.0</td>
      <td>161.927</td>
      <td>7340.0</td>
      <td>298.26</td>
      <td>POLYGON ((3.77335 46.22719, 3.78505 46.22045, ...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.0</td>
      <td>S</td>
      <td>Basses-Alpes</td>
      <td>12935.0</td>
      <td>7289.0</td>
      <td>46.0</td>
      <td>2733.0</td>
      <td>23018.0</td>
      <td>14238.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>12.0</td>
      <td>37.0</td>
      <td>80.0</td>
      <td>32.0</td>
      <td>29.0</td>
      <td>2.0</td>
      <td>351.399</td>
      <td>6925.0</td>
      <td>155.90</td>
      <td>POLYGON ((5.87269 44.22421, 5.86943 44.2307, 5...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>S</td>
      <td>Hautes-Alpes</td>
      <td>17488.0</td>
      <td>8174.0</td>
      <td>69.0</td>
      <td>6962.0</td>
      <td>23076.0</td>
      <td>16171.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>23.0</td>
      <td>64.0</td>
      <td>79.0</td>
      <td>35.0</td>
      <td>7.0</td>
      <td>1.0</td>
      <td>320.280</td>
      <td>5549.0</td>
      <td>129.10</td>
      <td>POLYGON ((5.92183 44.24841, 5.91224 44.24951, ...</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 24 columns</p>
</div>



> **NB** Перепроецирование и пересчет координат осуществляются методом `.to_crs`

# Операции с пространственными объектами типа `GeoDataFrame`


## Расчет геометрических параметров объектов

Аналогично объектам `shapely` мы можем использовать методы объектов для вычисления расстояния, периметра и площади объектов.

| **Метод** 	| **shapely** 	| **geopandas** 	|                                                 	|
|-----------	|-------------	|---------------	|-------------------------------------------------	|
| .length   	|    Length   	|     Length    	| Длина линейного объекта или периметр площадного 	|
| .area     	|    Area     	|      Area     	| Площадь                                         	|
| .distance 	|   Distance  	|    Distance   	| Расстояние                                      	|


> **NB** помните, что все вычисления осуществляются единицах системы координат вашего объекта.



```python
guerry.area
```




    0     5.784328e+09
    1     7.435863e+09
    2     7.378633e+09
    3     7.009832e+09
    4     5.696593e+09
    5     5.570000e+09
    6     5.255254e+09
    7     4.927863e+09
    8     6.028654e+09
    9     6.370164e+09
    10    8.787689e+09
    11    5.105167e+09
    12    5.613253e+09
    13    5.779975e+09
    14    5.974584e+09
    15    6.914309e+09
    16    7.307826e+09
    17    5.902357e+09
    18    8.799459e+09
    19    6.984510e+09
    20    5.598373e+09
    21    9.229190e+09
    22    5.253258e+09
    23    6.564463e+09
    24    6.043508e+09
    25    5.936494e+09
    26    6.745738e+09
    27    5.888648e+09
    28    6.379883e+09
    29    6.318447e+09
    30    1.016175e+10
    31    6.248432e+09
    32    6.845077e+09
    33    6.896581e+09
    34    6.158313e+09
    35    7.879230e+09
    36    5.049716e+09
    37    9.371348e+09
    38    6.418670e+09
    39    4.806874e+09
    40    5.008877e+09
    41    6.908492e+09
    42    6.815491e+09
    43    5.233360e+09
    44    5.394544e+09
    45    5.181948e+09
    46    7.230561e+09
    47    6.011881e+09
    48    8.199175e+09
    49    6.260489e+09
    50    5.213995e+09
    51    5.287834e+09
    52    6.244185e+09
    53    6.869995e+09
    54    6.258790e+09
    55    6.874093e+09
    56    5.772918e+09
    57    5.900796e+09
    58    6.149896e+09
    59    6.721377e+09
    60    8.013982e+09
    61    7.712213e+09
    62    4.539256e+09
    63    4.161572e+09
    64    4.798103e+09
    65    3.531393e+09
    66    3.260188e+09
    67    5.390470e+09
    68    8.612211e+09
    69    6.247666e+09
    70    7.637855e+08
    71    6.333464e+09
    72    5.932052e+09
    73    5.383685e+09
    74    6.039741e+09
    75    6.211940e+09
    76    5.794273e+09
    77    3.736182e+09
    78    6.050883e+09
    79    3.586428e+09
    80    6.770675e+09
    81    7.033789e+09
    82    5.560160e+09
    83    5.900610e+09
    84    7.460483e+09
    dtype: float64



> **NB** все вычисления в `geopandas` планарны, то есть осуществляются на плоскости, поэтому, если вы хотите получать адекватные результаты, сначала объект нужно перепроецировать в прямоугольную систему координат

При вычислении расстояний, они могут быть рассчитаны как между всеми возможными парами объектов внутри `GeoDataFrame`, так и между каким-то конкретным объектом и прочими.


```python
get_utm_zone(lon=guerry_wgs.centroid[1].y , lat=guerry_wgs.centroid[1].x)
```

    /var/folders/j9/9s_tg9t546d4q617w79_f05r0000gn/T/ipykernel_46626/3638807373.py:1: UserWarning: Geometry is in a geographic CRS. Results from 'centroid' are likely incorrect. Use 'GeoSeries.to_crs()' to re-project geometries to a projected CRS before this operation.
    
      get_utm_zone(lon=guerry_wgs.centroid[1].y , lat=guerry_wgs.centroid[1].x)





    'EPSG:32639'




```python
guerry_utm = guerry_wgs.to_crs(32639)
```


```python
guerry.area
```




    0     5.784328e+09
    1     7.435863e+09
    2     7.378633e+09
    3     7.009832e+09
    4     5.696593e+09
    5     5.570000e+09
    6     5.255254e+09
    7     4.927863e+09
    8     6.028654e+09
    9     6.370164e+09
    10    8.787689e+09
    11    5.105167e+09
    12    5.613253e+09
    13    5.779975e+09
    14    5.974584e+09
    15    6.914309e+09
    16    7.307826e+09
    17    5.902357e+09
    18    8.799459e+09
    19    6.984510e+09
    20    5.598373e+09
    21    9.229190e+09
    22    5.253258e+09
    23    6.564463e+09
    24    6.043508e+09
    25    5.936494e+09
    26    6.745738e+09
    27    5.888648e+09
    28    6.379883e+09
    29    6.318447e+09
    30    1.016175e+10
    31    6.248432e+09
    32    6.845077e+09
    33    6.896581e+09
    34    6.158313e+09
    35    7.879230e+09
    36    5.049716e+09
    37    9.371348e+09
    38    6.418670e+09
    39    4.806874e+09
    40    5.008877e+09
    41    6.908492e+09
    42    6.815491e+09
    43    5.233360e+09
    44    5.394544e+09
    45    5.181948e+09
    46    7.230561e+09
    47    6.011881e+09
    48    8.199175e+09
    49    6.260489e+09
    50    5.213995e+09
    51    5.287834e+09
    52    6.244185e+09
    53    6.869995e+09
    54    6.258790e+09
    55    6.874093e+09
    56    5.772918e+09
    57    5.900796e+09
    58    6.149896e+09
    59    6.721377e+09
    60    8.013982e+09
    61    7.712213e+09
    62    4.539256e+09
    63    4.161572e+09
    64    4.798103e+09
    65    3.531393e+09
    66    3.260188e+09
    67    5.390470e+09
    68    8.612211e+09
    69    6.247666e+09
    70    7.637855e+08
    71    6.333464e+09
    72    5.932052e+09
    73    5.383685e+09
    74    6.039741e+09
    75    6.211940e+09
    76    5.794273e+09
    77    3.736182e+09
    78    6.050883e+09
    79    3.586428e+09
    80    6.770675e+09
    81    7.033789e+09
    82    5.560160e+09
    83    5.900610e+09
    84    7.460483e+09
    dtype: float64




```python
guerry_utm.geometry.distance
```




    <bound method GeoPandasBase.distance of 0     POLYGON ((-3026192.3 6209436.047, -3026212.433...
    1     POLYGON ((-2776997.002 6640510.345, -2777288.1...
    2     POLYGON ((-3075229.75 6315383.997, -3074940.04...
    3     POLYGON ((-3075199.688 5993912.849, -3074966.8...
    4     POLYGON ((-3069679.173 5993852.909, -3070324.7...
    5     POLYGON ((-3195959.572 6096202.908, -3196327.6...
    6     POLYGON ((-2704824.954 6569151.284, -2705248.3...
    7     POLYGON ((-3548737.888 6103647.927, -3549209.7...
    8     POLYGON ((-2865745.841 6453586.868, -2866185.5...
    9     POLYGON ((-3392297.056 6076304.728, -3391986.4...
    10    POLYGON ((-3253639.983 6220191.013, -3254087.6...
    11    POLYGON ((-3167125.759 5985163.426, -3166603.0...
    12    POLYGON ((-3179528.078 6850745.081, -3179433.8...
    13    POLYGON ((-3271455.556 6294545.399, -3271158.0...
    14    POLYGON ((-3318369.669 6489155.883, -3318299.7...
    15    MULTIPOLYGON (((-3436753.363 6585630.06, -3436...
    16    POLYGON ((-3113561.52 6521197.762, -3113010.52...
    17    POLYGON ((-3237966.646 6304929.7, -3237932.016...
    18    MULTIPOLYGON (((-2977307.8 6384018.956, -29774...
    19    MULTIPOLYGON (((-3291961.093 6967012.501, -329...
    20    POLYGON ((-3249037.538 6417900.982, -3250882.4...
    21    POLYGON ((-3351889.603 6315354.539, -3351453.9...
    22    POLYGON ((-2880493.23 6234322.386, -2880042.97...
    23    POLYGON ((-3058291.332 6113597.845, -3057928.8...
    24    POLYGON ((-2991337.508 6766729.407, -2990186.1...
    25    POLYGON ((-3055190.645 6608033.193, -3055462.6...
    26    MULTIPOLYGON (((-3360734.382 7020484.584, -336...
    27    POLYGON ((-3253856.799 6074344.85, -3253061.46...
    28    POLYGON ((-3511221.163 6185167.439, -3510793.3...
    29    POLYGON ((-3555466.833 6214767.248, -3555644.0...
    30    MULTIPOLYGON (((-3549111.788 6442499.19, -3548...
    31    POLYGON ((-3247393.166 6044478.012, -3245879.1...
    32    MULTIPOLYGON (((-3328172.316 6813367.196, -332...
    33    POLYGON ((-3182742.193 6436865.209, -3182984.7...
    34    POLYGON ((-3160019.19 6587544.709, -3160127.67...
    35    POLYGON ((-2990013.117 6183200.695, -2989790.9...
    36    MULTIPOLYGON (((-2909670.701 6288734.736, -290...
    37    POLYGON ((-3594828.215 6427033.016, -3581796.2...
    38    POLYGON ((-3102424.321 6629918.432, -3102594.3...
    39    POLYGON ((-3059352.739 6295449.546, -3058477.7...
    40    POLYGON ((-3113514.693 6208166.619, -3111937.6...
    41    POLYGON ((-3377099.726 6763416.128, -3376664.4...
    42    POLYGON ((-3060447.211 6610741.515, -3059587.9...
    43    POLYGON ((-3396854.509 6304687.136, -3394211.5...
    44    POLYGON ((-3492217.18 6358455.173, -3492623.62...
    45    POLYGON ((-3192477.06 6184925.173, -3191780.14...
    46    POLYGON ((-3223832.492 6685631.081, -3224959.1...
    47    MULTIPOLYGON (((-3219700.531 6856748.99, -3219...
    48    POLYGON ((-2823903.012 6492291.466, -2824255.1...
    49    POLYGON ((-2863964.384 6453652.107, -2863937.8...
    50    POLYGON ((-3220468.039 6717184.33, -3220795.87...
    51    MULTIPOLYGON (((-2707317.995 6553428.12, -2707...
    52    POLYGON ((-2712658.008 6499025.905, -2712331.2...
    53    MULTIPOLYGON (((-3433270.828 6882045.325, -343...
    54    POLYGON ((-2637959.686 6455970.157, -2637377.7...
    55    POLYGON ((-2977800.219 6425134.741, -2976809.1...
    56    MULTIPOLYGON (((-2752236.846 6782039.87, -2753...
    57    MULTIPOLYGON (((-2887034.061 6654756.848, -288...
    58    POLYGON ((-3069441.408 6757837.194, -3066886.1...
    59    POLYGON ((-2833754.412 6747683.558, -2833744.8...
    60    POLYGON ((-3225236.999 6306908.094, -3224920.6...
    61    POLYGON ((-3645573.639 6221250.606, -3645860.8...
    62    MULTIPOLYGON (((-3586876.787 6254199.278, -358...
    63    POLYGON ((-3418208.286 5980634.178, -3418365.5...
    64    POLYGON ((-2633399.8 6430489.442, -2633384.749...
    65    POLYGON ((-2696442.47 6276259.939, -2697199.85...
    66    POLYGON ((-3053738.038 6265265.922, -3054110.0...
    67    POLYGON ((-2765560.519 6291967.051, -2765715.7...
    68    POLYGON ((-2913029.22 6288288.135, -2913139.57...
    69    POLYGON ((-3121840.059 6695029.94, -3120750.79...
    70    POLYGON ((-2957796.938 6629046.664, -2958016.2...
    71    POLYGON ((-3034536.108 6850508.015, -3032036.4...
    72    POLYGON ((-2931089.507 6553526.164, -2931396.7...
    73    POLYGON ((-2985734.274 6717441.105, -2984526.7...
    74    POLYGON ((-3276504.531 6605984.289, -3276254.3...
    75    POLYGON ((-2883395.518 6839972.222, -2880324.9...
    76    POLYGON ((-3429665.877 6179486.645, -3430086.1...
    77    POLYGON ((-3372660.967 6205001.521, -3372928.6...
    78    MULTIPOLYGON (((-3116819.537 5833816.201, -311...
    79    MULTIPOLYGON (((-3137066.991 6048889.025, -313...
    80    MULTIPOLYGON (((-3451740.222 6724364.167, -345...
    81    POLYGON ((-3323934.262 6493631.32, -3324098.36...
    82    POLYGON ((-3317649.164 6380800.118, -3318094.6...
    83    POLYGON ((-2684755.44 6359946.129, -2683579.85...
    84    POLYGON ((-2966405.702 6556757.691, -2962923.1...
    Name: geometry, dtype: geometry>



А в этом случае расстояние будет рассчитываться от первого объекта до всех остальных.


```python
guerry_utm.distance(guerry_wgs["geometry"].iloc[0])
```




    0     6.835347e+06
    1     7.185473e+06
    2     7.006666e+06
    3     6.629416e+06
    4     6.667971e+06
    5     6.840835e+06
    6     7.103103e+06
    7     6.971221e+06
    8     7.051614e+06
    9     6.900995e+06
    10    6.928219e+06
    11    6.688893e+06
    12    7.436426e+06
    13    6.987809e+06
    14    7.244042e+06
    15    7.286047e+06
    16    7.115173e+06
    17    7.080694e+06
    18    6.947727e+06
    19    7.596212e+06
    20    7.102264e+06
    21    7.147035e+06
    22    6.838789e+06
    23    6.748002e+06
    24    7.346251e+06
    25    7.274534e+06
    26    7.698620e+06
    27    6.808388e+06
    28    7.021167e+06
    29    7.103772e+06
    30    7.241625e+06
    31    6.843918e+06
    32    7.505692e+06
    33    7.165567e+06
    34    7.267687e+06
    35    6.736013e+06
    36    6.855229e+06
    37    7.222025e+06
    38    7.212337e+06
    39    6.895408e+06
    40    6.905480e+06
    41    7.469886e+06
    42    7.162887e+06
    43    7.066723e+06
    44    7.155093e+06
    45    6.891772e+06
    46    7.377343e+06
    47    7.512200e+06
    48    7.074754e+06
    49    6.960997e+06
    50    7.441911e+06
    51    6.910504e+06
    52    7.006788e+06
    53    7.574699e+06
    54    6.905583e+06
    55    7.033286e+06
    56    7.213651e+06
    57    7.239612e+06
    58    7.366623e+06
    59    7.294686e+06
    60    6.963811e+06
    61    7.200120e+06
    62    7.125267e+06
    63    6.868043e+06
    64    6.851865e+06
    65    6.815973e+06
    66    6.883082e+06
    67    6.871325e+06
    68    6.908869e+06
    69    7.351379e+06
    70    7.256373e+06
    71    7.359545e+06
    72    7.175345e+06
    73    7.242326e+06
    74    7.313965e+06
    75    7.272542e+06
    76    6.955561e+06
    77    7.062163e+06
    78    6.603414e+06
    79    6.716639e+06
    80    7.390514e+06
    81    7.244773e+06
    82    7.148111e+06
    83    6.881986e+06
    84    7.061782e+06
    dtype: float64



Полученные результаты не обязательно должны сохраняться в новый объект, мы можем создать новую колонку в `GeoDataFrame` и записать результат в нее.


```python
guerry_utm["distance"] = guerry_utm.distance(guerry_utm["geometry"].iloc[0])

guerry_utm.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>dept</th>
      <th>Region</th>
      <th>Dprtmnt</th>
      <th>Crm_prs</th>
      <th>Crm_prp</th>
      <th>Litercy</th>
      <th>Donatns</th>
      <th>Infants</th>
      <th>Suicids</th>
      <th>MainCty</th>
      <th>...</th>
      <th>Dntn_cl</th>
      <th>Lottery</th>
      <th>Desertn</th>
      <th>Instrct</th>
      <th>Prsttts</th>
      <th>Distanc</th>
      <th>Area</th>
      <th>Pop1831</th>
      <th>geometry</th>
      <th>distance</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>S</td>
      <td>Ain</td>
      <td>28870.0</td>
      <td>15890.0</td>
      <td>37.0</td>
      <td>5098.0</td>
      <td>33120.0</td>
      <td>35039.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>69.0</td>
      <td>41.0</td>
      <td>55.0</td>
      <td>46.0</td>
      <td>13.0</td>
      <td>218.372</td>
      <td>5762.0</td>
      <td>346.03</td>
      <td>POLYGON ((-3026192.3 6209436.047, -3026212.433...</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2.0</td>
      <td>S</td>
      <td>Aisne</td>
      <td>26226.0</td>
      <td>5521.0</td>
      <td>51.0</td>
      <td>8901.0</td>
      <td>14572.0</td>
      <td>12831.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>36.0</td>
      <td>38.0</td>
      <td>82.0</td>
      <td>24.0</td>
      <td>327.0</td>
      <td>65.945</td>
      <td>7369.0</td>
      <td>513.00</td>
      <td>POLYGON ((-2776997.002 6640510.345, -2777288.1...</td>
      <td>322581.635556</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3.0</td>
      <td>S</td>
      <td>Allier</td>
      <td>26747.0</td>
      <td>7925.0</td>
      <td>13.0</td>
      <td>10973.0</td>
      <td>17044.0</td>
      <td>114121.0</td>
      <td>2.0</td>
      <td>...</td>
      <td>76.0</td>
      <td>66.0</td>
      <td>16.0</td>
      <td>85.0</td>
      <td>34.0</td>
      <td>161.927</td>
      <td>7340.0</td>
      <td>298.26</td>
      <td>POLYGON ((-3075229.75 6315383.997, -3074940.04...</td>
      <td>71383.293810</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.0</td>
      <td>S</td>
      <td>Basses-Alpes</td>
      <td>12935.0</td>
      <td>7289.0</td>
      <td>46.0</td>
      <td>2733.0</td>
      <td>23018.0</td>
      <td>14238.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>37.0</td>
      <td>80.0</td>
      <td>32.0</td>
      <td>29.0</td>
      <td>2.0</td>
      <td>351.399</td>
      <td>6925.0</td>
      <td>155.90</td>
      <td>POLYGON ((-3075199.688 5993912.849, -3074966.8...</td>
      <td>151364.819076</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>S</td>
      <td>Hautes-Alpes</td>
      <td>17488.0</td>
      <td>8174.0</td>
      <td>69.0</td>
      <td>6962.0</td>
      <td>23076.0</td>
      <td>16171.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>64.0</td>
      <td>79.0</td>
      <td>35.0</td>
      <td>7.0</td>
      <td>1.0</td>
      <td>320.280</td>
      <td>5549.0</td>
      <td>129.10</td>
      <td>POLYGON ((-3069679.173 5993852.909, -3070324.7...</td>
      <td>83906.586121</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 25 columns</p>
</div>



## Создание новых объектов на основе имеющихся

Для создания новых объектов с использованием уже имеющихся также могут использоваться методы, реализованные для объектов `GeoDataFrame`.

| **Метод**                                    | **shapely**  	| **geopandas**             	|                              	|
|----------------------------------------------|--------------	|---------------------------	|-----------------------------	|
| `.centroid`                                  |   Centroids  	|         Centroids         	| Центроид (геометрический центр объекта)|
| `.buffer`                                    |    Buffers   	|          Buffers          	| Буферные зоны                 |
| `.intersection / .overlay (..., how="intersection")` 	| Intersection 	| Set operations (.overlay) 	| Пересечение           |
| `.union / .overlay (..., how="union")`               	|     Union    	| Set operations (.overlay) 	| Объединение                             	|
| `.difference / .overlay(..., how="difference")`      	|  Difference  	| Set operations (.overlay) 	| Разность                                	|

> Обратите внимание, что операции между парами объектов в `geopandas` реализованы через один метод `.overlay`, в котором нужно указывать, какого вида операцию вы осуществляете.

> в `shapely` эти операции же реализованы различными методами.


```python
ctr = guerry.centroid
```


```python
ctr
```




    0     POINT (832852.279 2126600.576)
    1     POINT (688485.627 2507622.044)
    2     POINT (665510.138 2155203.452)
    3     POINT (912995.751 1908303.142)
    4     POINT (911433.897 1970311.894)
    5      POINT (765421.342 1974521.21)
    6     POINT (766676.638 2515626.684)
    7     POINT (531866.418 1769020.126)
    8      POINT (735432.699 2368846.89)
    9     POINT (606309.985 1788959.109)
    10    POINT (627416.659 1919941.034)
    11    POINT (822471.117 1842079.559)
    12    POINT (402723.656 2459126.284)
    13    POINT (626174.212 2005646.903)
    14    POINT (433800.194 2082007.626)
    15    POINT (365909.867 2091205.198)
    16    POINT (611728.939 2229456.227)
    17    POINT (563991.198 2039719.576)
    18     POINT (783740.64 2272308.158)
    19    POINT (215377.395 2395187.094)
    20     POINT (575426.97 2121172.922)
    21    POINT (474413.294 2012783.542)
    22    POINT (905029.178 2248422.693)
    23    POINT (824554.192 1968848.768)
    24    POINT (502094.781 2458132.967)
    25    POINT (528405.557 2376945.354)
    26    POINT (125581.685 2381812.622)
    27    POINT (748026.671 1889741.898)
    28    POINT (505488.785 1818042.002)
    29    POINT (447993.543 1856380.414)
    30    POINT (369673.086 1984761.456)
    31    POINT (683371.223 1842508.203)
    32    POINT (304328.125 2358046.536)
    33    POINT (541918.644 2197819.649)
    34    POINT (475497.738 2252225.451)
    35    POINT (854236.996 2034425.879)
    36    POINT (856827.166 2197534.908)
    37    POINT (349357.363 1889851.263)
    38    POINT (531812.605 2291172.204)
    39    POINT (742381.226 2082384.235)
    40     POINT (715668.105 2015246.04)
    41     POINT (296599.069 2270179.55)
    42    POINT (600575.529 2323620.281)
    43    POINT (541891.819 1958418.895)
    44    POINT (450349.957 1931402.396)
    45    POINT (692574.008 1946904.144)
    46     POINT (381070.79 2269736.948)
    47    POINT (332231.343 2459771.541)
    48    POINT (739398.849 2440695.138)
    49      POINT (815193.6 2349544.093)
    50    POINT (377185.846 2353983.825)
    51    POINT (881341.646 2427826.564)
    52    POINT (822960.251 2447828.994)
    53    POINT (215056.369 2328979.336)
    54     POINT (916382.211 2457503.19)
    55    POINT (688652.182 2235714.397)
    56    POINT (662890.221 2606198.808)
    57    POINT (606444.169 2490314.728)
    58    POINT (437195.226 2405054.844)
    59    POINT (596599.687 2610979.723)
    60    POINT (662604.872 2080922.991)
    61    POINT (348100.169 1810981.794)
    62     POINT (422654.385 1785805.57)
    63     POINT (615264.814 1732959.66)
    64    POINT (983954.925 2420757.869)
    65    POINT (969245.817 2329306.369)
    66    POINT (778930.881 2099300.365)
    67    POINT (881647.835 2300228.263)
    68    POINT (768824.096 2185121.665)
    69    POINT (442206.509 2334919.466)
    70      POINT (604900.2 2427750.063)
    71    POINT (505316.913 2518345.223)
    72     POINT (644034.202 2403285.04)
    73    POINT (578580.888 2420049.764)
    74    POINT (396568.749 2176272.956)
    75     POINT (595756.54 2551328.207)
    76    POINT (586275.285 1864878.053)
    77    POINT (515446.222 1898849.022)
    78    POINT (916704.277 1834463.794)
    79    POINT (828068.904 1893623.709)
    80    POINT (322059.477 2192535.348)
    81    POINT (456183.284 2175488.824)
    82    POINT (514516.691 2099653.307)
    83    POINT (900562.832 2363005.197)
    84    POINT (691913.683 2316341.407)
    dtype: geometry




```python
ctr.plot()
```




    <Axes: >




    
![png](output_209_1.png)
    



```python
buffers = ctr.buffer(10000)

buffers
```




    0     POLYGON ((842852.279 2126600.576, 842804.126 2...
    1     POLYGON ((698485.627 2507622.044, 698437.475 2...
    2     POLYGON ((675510.138 2155203.452, 675461.986 2...
    3     POLYGON ((922995.751 1908303.142, 922947.598 1...
    4     POLYGON ((921433.897 1970311.894, 921385.745 1...
    5     POLYGON ((775421.342 1974521.21, 775373.189 19...
    6     POLYGON ((776676.638 2515626.684, 776628.486 2...
    7     POLYGON ((541866.418 1769020.126, 541818.265 1...
    8     POLYGON ((745432.699 2368846.89, 745384.546 23...
    9     POLYGON ((616309.985 1788959.109, 616261.832 1...
    10    POLYGON ((637416.659 1919941.034, 637368.507 1...
    11    POLYGON ((832471.117 1842079.559, 832422.964 1...
    12    POLYGON ((412723.656 2459126.284, 412675.503 2...
    13    POLYGON ((636174.212 2005646.903, 636126.059 2...
    14    POLYGON ((443800.194 2082007.626, 443752.041 2...
    15    POLYGON ((375909.867 2091205.198, 375861.714 2...
    16    POLYGON ((621728.939 2229456.227, 621680.786 2...
    17    POLYGON ((573991.198 2039719.576, 573943.045 2...
    18    POLYGON ((793740.64 2272308.158, 793692.487 22...
    19    POLYGON ((225377.395 2395187.094, 225329.243 2...
    20    POLYGON ((585426.97 2121172.922, 585378.817 21...
    21    POLYGON ((484413.294 2012783.542, 484365.141 2...
    22    POLYGON ((915029.178 2248422.693, 914981.025 2...
    23    POLYGON ((834554.192 1968848.768, 834506.039 1...
    24    POLYGON ((512094.781 2458132.967, 512046.629 2...
    25    POLYGON ((538405.557 2376945.354, 538357.405 2...
    26    POLYGON ((135581.685 2381812.622, 135533.532 2...
    27    POLYGON ((758026.671 1889741.898, 757978.519 1...
    28    POLYGON ((515488.785 1818042.002, 515440.632 1...
    29    POLYGON ((457993.543 1856380.414, 457945.391 1...
    30    POLYGON ((379673.086 1984761.456, 379624.933 1...
    31    POLYGON ((693371.223 1842508.203, 693323.07 18...
    32    POLYGON ((314328.125 2358046.536, 314279.973 2...
    33    POLYGON ((551918.644 2197819.649, 551870.492 2...
    34    POLYGON ((485497.738 2252225.451, 485449.585 2...
    35    POLYGON ((864236.996 2034425.879, 864188.843 2...
    36    POLYGON ((866827.166 2197534.908, 866779.013 2...
    37    POLYGON ((359357.363 1889851.263, 359309.211 1...
    38    POLYGON ((541812.605 2291172.204, 541764.452 2...
    39    POLYGON ((752381.226 2082384.235, 752333.073 2...
    40    POLYGON ((725668.105 2015246.04, 725619.952 20...
    41    POLYGON ((306599.069 2270179.55, 306550.916 22...
    42    POLYGON ((610575.529 2323620.281, 610527.377 2...
    43    POLYGON ((551891.819 1958418.895, 551843.667 1...
    44    POLYGON ((460349.957 1931402.396, 460301.804 1...
    45    POLYGON ((702574.008 1946904.144, 702525.855 1...
    46    POLYGON ((391070.79 2269736.948, 391022.637 22...
    47    POLYGON ((342231.343 2459771.541, 342183.19 24...
    48    POLYGON ((749398.849 2440695.138, 749350.696 2...
    49    POLYGON ((825193.6 2349544.093, 825145.447 234...
    50    POLYGON ((387185.846 2353983.825, 387137.693 2...
    51    POLYGON ((891341.646 2427826.564, 891293.494 2...
    52    POLYGON ((832960.251 2447828.994, 832912.098 2...
    53    POLYGON ((225056.369 2328979.336, 225008.216 2...
    54    POLYGON ((926382.211 2457503.19, 926334.058 24...
    55    POLYGON ((698652.182 2235714.397, 698604.029 2...
    56    POLYGON ((672890.221 2606198.808, 672842.068 2...
    57    POLYGON ((616444.169 2490314.728, 616396.017 2...
    58    POLYGON ((447195.226 2405054.844, 447147.073 2...
    59    POLYGON ((606599.687 2610979.723, 606551.534 2...
    60    POLYGON ((672604.872 2080922.991, 672556.72 20...
    61    POLYGON ((358100.169 1810981.794, 358052.016 1...
    62    POLYGON ((432654.385 1785805.57, 432606.232 17...
    63    POLYGON ((625264.814 1732959.66, 625216.661 17...
    64    POLYGON ((993954.925 2420757.869, 993906.772 2...
    65    POLYGON ((979245.817 2329306.369, 979197.665 2...
    66    POLYGON ((788930.881 2099300.365, 788882.728 2...
    67    POLYGON ((891647.835 2300228.263, 891599.682 2...
    68    POLYGON ((778824.096 2185121.665, 778775.943 2...
    69    POLYGON ((452206.509 2334919.466, 452158.357 2...
    70    POLYGON ((614900.2 2427750.063, 614852.047 242...
    71    POLYGON ((515316.913 2518345.223, 515268.76 25...
    72    POLYGON ((654034.202 2403285.04, 653986.049 24...
    73    POLYGON ((588580.888 2420049.764, 588532.735 2...
    74    POLYGON ((406568.749 2176272.956, 406520.597 2...
    75    POLYGON ((605756.54 2551328.207, 605708.387 25...
    76    POLYGON ((596275.285 1864878.053, 596227.132 1...
    77    POLYGON ((525446.222 1898849.022, 525398.069 1...
    78    POLYGON ((926704.277 1834463.794, 926656.124 1...
    79    POLYGON ((838068.904 1893623.709, 838020.751 1...
    80    POLYGON ((332059.477 2192535.348, 332011.324 2...
    81    POLYGON ((466183.284 2175488.824, 466135.131 2...
    82    POLYGON ((524516.691 2099653.307, 524468.538 2...
    83    POLYGON ((910562.832 2363005.197, 910514.68 23...
    84    POLYGON ((701913.683 2316341.407, 701865.53 23...
    dtype: geometry




```python
buffers.plot()
```




    <Axes: >




    
![png](output_211_1.png)
    

